"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.acmeDns = exports.acmeChallenge = exports.acmeRenew = exports.acmeDomain = void 0;
exports.getAcmeSettings = getAcmeSettings;
exports.setAcmeSettings = setAcmeSettings;
const config_1 = require("./config");
const cross_const_1 = require("./cross-const");
const github_1 = require("./github");
const acmeDns_1 = require("./acmeDns");
exports.acmeDomain = (0, config_1.defineConfig)(cross_const_1.CFG.acme_domain, '');
exports.acmeRenew = (0, config_1.defineConfig)(cross_const_1.CFG.acme_renew, false);
exports.acmeChallenge = (0, config_1.defineConfig)(cross_const_1.CFG.acme_challenge, 'http-01');
exports.acmeDns = (0, config_1.defineConfig)(cross_const_1.CFG.acme_dns, []);
async function getAcmeSettings() {
    return {
        domain: exports.acmeDomain.get(), renew: exports.acmeRenew.get(), challenge: exports.acmeChallenge.get(),
        dns: exports.acmeDns.get(), providers: (0, acmeDns_1.dnsProviderInfo)((await (0, github_1.getProjectInfo)()).acmeDns),
    };
}
async function setAcmeSettings(settings) {
    if (typeof settings.domain !== 'string' || typeof settings.renew !== 'boolean'
        || !['http-01', 'dns-01'].includes(settings.challenge) || !Array.isArray(settings.dns) || settings.dns.length > 1)
        throw Error("Invalid certificate settings");
    const providers = (0, acmeDns_1.dnsProviderInfo)((await (0, github_1.getProjectInfo)()).acmeDns);
    const configs = settings.dns.map(config => {
        if (!config || typeof config.id !== 'string' || !config.id || !config.credentials || typeof config.credentials !== 'object'
            || Object.values(config.credentials).some(value => typeof value !== 'string'))
            throw Error("Invalid DNS configuration");
        const previous = exports.acmeDns.get().find(c => c.id === config.id && c.provider === config.provider && c.config_version === config.config_version);
        const provider = providers.find(p => p.id === config.provider && p.config_version === config.config_version);
        // retain unavailable credentials so switching back to HTTP doesn't require discarding them
        if (!provider && previous)
            return config;
        if (!provider || Object.keys(config.credentials).some(key => !(key in provider.fields)))
            throw Error("Invalid DNS configuration; select a supported provider");
        return { id: config.id, provider: config.provider, config_version: config.config_version, credentials: config.credentials };
    });
    await (0, config_1.setConfig)({
        [cross_const_1.CFG.acme_domain]: settings.domain, [cross_const_1.CFG.acme_renew]: settings.renew,
        [cross_const_1.CFG.acme_challenge]: settings.challenge, [cross_const_1.CFG.acme_dns]: configs,
    });
    return getAcmeSettings();
}
