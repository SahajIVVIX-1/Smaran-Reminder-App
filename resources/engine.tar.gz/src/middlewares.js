"use strict";
// This file is part of HFS - Copyright 2021-2023, Massimo Melina <a@rejetto.com> - License https://www.gnu.org/licenses/gpl-3.0.txt
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sessionMiddleware = exports.paramsDecoder = exports.prepareState = exports.blockFilter = exports.prepareConnection = exports.someSecurity = exports.cloudflareDetected = exports.gzipper = exports.sessionDuration = void 0;
exports.getProxyDetected = getProxyDetected;
exports.failAllowNet = failAllowNet;
const koa_compress_1 = __importDefault(require("koa-compress"));
const const_1 = require("./const");
const misc_1 = require("./misc");
const block_1 = require("./block");
const perm_1 = require("./perm");
const connections_1 = require("./connections");
const auth_1 = require("./auth");
const sessionStamp_1 = require("./sessionStamp");
const zlib_1 = require("zlib");
const listen_1 = require("./listen");
const roots_1 = require("./roots");
const node_net_1 = require("node:net");
const config_1 = require("./config");
const koa_session_1 = __importDefault(require("koa-session"));
const index_1 = require("./index");
const events_1 = __importDefault(require("./events"));
const node_crypto_1 = require("node:crypto");
const lang_1 = require("./lang");
const i18n_1 = require("./i18n");
const forceHttps = (0, config_1.defineConfig)(misc_1.CFG.force_https, true);
(0, config_1.defineConfig)(misc_1.CFG.ignore_proxies, false);
const allowAuthorizationHeader = (0, config_1.defineConfig)(misc_1.CFG.authorization_header, true);
exports.sessionDuration = (0, config_1.defineConfig)(misc_1.CFG.session_duration, Number(process.env.SESSION_DURATION) || misc_1.DAY / 1000, v => v * 1000);
// plugins can use ctx.compress: false disables compression, true bypasses the MIME filter, an object overrides per-response options; object overrides still use the MIME filter and replace each encoding's options, so preserve flush for SSE
exports.gzipper = (0, koa_compress_1.default)({
    threshold: 2048,
    gzip: { flush: zlib_1.constants.Z_SYNC_FLUSH }, // flush is necessary for SSE, at least in Chrome145
    deflate: { flush: zlib_1.constants.Z_SYNC_FLUSH },
    zstd: { flush: zlib_1.constants.Z_SYNC_FLUSH },
    br: false, // disable brotli
    filter: type => /^text|javascript$|wasm$|xml$|json$|ttf$|otf$/i.test(type),
});
let proxyDetected;
const someSecurity = (ctx, next) => {
    enforceSessionIp(ctx);
    const decodedPath = (0, misc_1.try_)(() => decodeURI(ctx.path));
    if (!decodedPath || (0, misc_1.hasDirTraversal)(decodedPath))
        return;
    if (ctx.get('cf-ray'))
        exports.cloudflareDetected = new Date();
    if (!ctx.secure && forceHttps.get() && (0, listen_1.getHttpsWorkingPort)() && !(0, misc_1.isLocalHost)(ctx)) {
        const { URL } = ctx;
        URL.protocol = 'https';
        URL.port = (0, listen_1.getHttpsWorkingPort)();
        ctx.status = const_1.HTTP_TEMPORARY_REDIRECT_KEEP_METHOD; // this ensures the client doesn't switch to a simpler GET request
        return ctx.redirect(URL.href);
    }
    const page = ctx.state.urlLoginPage;
    if (page)
        return sendUrlLoginPage(page.cleanUrl, page.username);
    return next();
    function sendUrlLoginPage(cleanUrl, username) {
        return sendPage(ctx, username === undefined ? 'login_bad_credentials' : 'Confirm', t => {
            if (username === undefined)
                return `<script>history.replaceState(null,'',location.pathname)</script>
                    <p><a href="${(0, misc_1.escapeHTML)(cleanUrl)}">${(0, misc_1.escapeHTML)(t('Continue'))}</a></p>`;
            const token = (0, node_crypto_1.randomUUID)();
            (ctx.session ??= {}).urlLoginConfirmation = {
                token,
                username,
                expires: Date.now() + 5 * 60_000,
            };
            return `<p>${(0, misc_1.escapeHTML)(t('confirm_url_login', { username }))}</p>
                <p><strong><a class="confirm" href="${(0, misc_1.escapeHTML)(cleanUrl)}">${(0, misc_1.escapeHTML)(t('Continue'))}</a></strong>
                <a href="${(0, misc_1.escapeHTML)(cleanUrl)}">${(0, misc_1.escapeHTML)(t('Cancel'))}</a></p>
                <script>
                    const loginUrl=new URL(location.href);
                    history.replaceState(null,'',loginUrl.pathname);
                    document.querySelector('.confirm').onclick=ev=>{ev.preventDefault();loginUrl.searchParams.set('login_confirm','${token}');location.replace(loginUrl)}
                </script>`;
        });
    }
};
exports.someSecurity = someSecurity;
async function sendPage(ctx, titleKey, content) {
    const { t } = (0, i18n_1.i18nFromTranslations)(await (0, lang_1.getLangData)(ctx));
    const title = t(titleKey);
    ctx.status = 200;
    ctx.type = 'html';
    ctx.set('cache-control', 'no-store');
    ctx.set('referrer-policy', 'no-referrer');
    ctx.set('content-security-policy', "frame-ancestors 'none'");
    ctx.set('x-frame-options', 'DENY');
    ctx.body = `<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
        <title>${(0, misc_1.escapeHTML)(title)}</title><style>
        body{margin-top:30vh;text-align:center;font-family:sans-serif}a{margin:1em}
        </style></head><body><h1>${(0, misc_1.escapeHTML)(title)}</h1>${content(t)}</body></html>`;
}
const prepareConnection = (ctx, next) => {
    // normalize once so auth, filters and logging agree on the same client address
    ctx.request.ip = (0, misc_1.normalizeIp)(ctx.ip);
    ctx.state.connection = (0, connections_1.socket2connection)(ctx.socket);
    (0, connections_1.updateConnectionForCtx)(ctx);
    return next();
};
exports.prepareConnection = prepareConnection;
const blockFilter = (ctx, next) => !ctx.state.skipFilters && (0, block_1.applyBlock)(ctx.socket, ctx.ip) || next();
exports.blockFilter = blockFilter;
function enforceSessionIp(ctx) {
    const s = ctx.session;
    if (!s?.username || s[misc_1.ALLOW_SESSION_IP_CHANGE])
        return;
    if (!s.ip)
        s.ip = ctx.ip;
    else if (s.ip !== ctx.ip) {
        delete s.username;
        s.ip = ctx.ip;
    }
}
// limited to http proxies
function getProxyDetected() {
    if (Number(proxyDetected?.state.whenProxyDetected) < Date.now() - misc_1.DAY) // detection is reset after a day
        proxyDetected = undefined;
    return proxyDetected && { from: proxyDetected.socket.remoteAddress, for: proxyDetected.get('X-Forwarded-For') };
}
const prepareState = async (ctx, next) => {
    ctx.state.getOrHead = ctx.method === 'GET' || ctx.method === 'HEAD';
    // invalidate before account resolution; someSecurity calls again to bind logins made below
    enforceSessionIp(ctx);
    // rootsMiddleware consults proxy-aware admin access before someSecurity runs
    if (ctx.get('X-Forwarded-For')
        // we have some dev-proxies to ignore
        && !(const_1.DEV && [process.env.FRONTEND_PROXY, process.env.ADMIN_PROXY].includes(ctx.get('X-Forwarded-port')))) {
        proxyDetected = ctx;
        ctx.state.whenProxyDetected = new Date();
    }
    ctx.state.safeUrl = ctx.originalUrl;
    if (ctx.query.login) {
        const query = new URLSearchParams(ctx.querystring);
        query.set('login', '...');
        ctx.state.safeUrl = `${ctx.path}?${query}`;
    }
    const s = ctx.session;
    if (s?.username) {
        const account = (0, perm_1.getAccount)(s.username, false);
        if (!account || !s.stamp || s.stamp !== (0, sessionStamp_1.getSessionStamp)(s.username)) {
            delete s.username;
            delete s.stamp;
        }
        s.maxAge = exports.sessionDuration.compiled();
    }
    // explicit credentials and existing sessions must take precedence, so a matching IP cannot override a chosen account
    let via;
    const urlAccount = await urlLogin();
    let a = ctx.state.urlLoginPage ? undefined
        : urlAccount || await getHttpAccount() || !s?.username && autoLogin();
    const loggedInNotBySession = a;
    ctx.state.account = a ||= (0, perm_1.getAccount)(s?.username, false); // with least precedence, we consider session
    if (a)
        if (!(0, perm_1.accountCanLogin)(a) || failAllowNet(ctx, a)) { // enforce allow_net also after login
            await (0, auth_1.setLoggedIn)(ctx, false);
            ctx.session = {}; // downstream handlers still need an anonymous session after the rejected identity is cleared
        }
        else if (loggedInNotBySession) {
            try {
                if (a.username)
                    await (0, auth_1.setLoggedIn)(ctx, a.username, via);
            }
            catch (e) {
                events_1.default.emit('failedLogin', { ctx, username: a.username, via: ctx.query.login ? 'url' : ctx.get('authorization') ? 'header' : undefined });
                ctx.status = const_1.HTTP_UNAUTHORIZED;
                ctx.body = e instanceof Error ? e.message : String(e);
                return;
            }
            ctx.headers['x-username'] = a.username; // give an easier way to determine if the login was successful
        }
    ctx.state.revProxyPath = ctx.get('x-forwarded-prefix');
    (0, connections_1.updateConnectionForCtx)(ctx); // publish the resolved account after the initial pre-auth connection update
    await next();
    async function urlLogin() {
        via = 'url';
        const { login } = ctx.query;
        if (!login)
            return;
        const [u, p] = (0, misc_1.splitAt)(':', String(login));
        const cleanUrl = ctx.originalUrl.slice(0, -ctx.querystring.length - 1);
        const token = String(ctx.query.login_confirm || '');
        const pending = s?.urlLoginConfirmation;
        const confirmed = Boolean(token && pending?.token === token && pending.username === u
            && pending.expires > Date.now());
        if (token && s)
            delete s.urlLoginConfirmation; // confirmation tokens are single-use, including failed attempts
        if (!confirmed && needsConfirmation(u)) {
            ctx.state.urlLoginPage = { username: u, cleanUrl };
            return;
        }
        if (s)
            delete s.urlLoginConfirmation;
        const account = u && await (0, auth_1.clearTextLogin)(ctx, u, p, 'url');
        if (!account && confirmed)
            ctx.state.urlLoginPage = { cleanUrl };
        else
            ctx.redirect(cleanUrl); // redirect to hide credentials
        return account;
        function needsConfirmation(username) {
            if (ctx.get('sec-fetch-mode') !== 'navigate' && !/^Mozilla\//.test(ctx.get('user-agent')))
                return false;
            const current = s?.username;
            if (current)
                return (0, perm_1.getAccount)(username)?.username !== (0, perm_1.getAccount)(current)?.username;
            const fetchSite = ctx.get('sec-fetch-site');
            if (fetchSite)
                return fetchSite === 'same-site' || fetchSite === 'cross-site';
            const referer = ctx.get('referer');
            return !referer || (0, misc_1.try_)(() => new URL(referer).host.toLowerCase() !== ctx.host.toLowerCase(), () => true);
        }
    }
    function getHttpAccount() {
        via = 'header';
        const b64 = allowAuthorizationHeader.get() && ctx.get('authorization')?.split(' ')[1];
        if (!b64)
            return;
        try {
            const [u, p] = atob(b64).split(':');
            if (!u || u === s?.username)
                return; // providing credentials, but not needed
            return (0, auth_1.clearTextLogin)(ctx, u, p || '', 'header');
        }
        catch { }
    }
    function autoLogin() {
        const host = ctx.host.toLowerCase();
        const hostname = (0, misc_1.normalizeHost)(host);
        // a rebinding page uses the victim's real IP, but retains the attacker's hostname
        if (hostname !== 'localhost' && !(0, node_net_1.isIP)(hostname)
            // URL normalization matches browsers' default-port removal and internationalized domain names
            && host !== (listen_1.baseUrl.get() && (0, misc_1.try_)(() => new URL(listen_1.baseUrl.get()).host.toLowerCase()))
            && roots_1.roots.compiled()(host) === undefined)
            return;
        via = 'net';
        // keep the mask direct so group inheritance cannot make identity depend on account order
        return Object.values(perm_1.accounts.get()).find(a => (0, perm_1.accountCanLogin)(a) && a.auto_login_net && (0, misc_1.netMatches)(ctx.ip, a.auto_login_net, true));
    }
};
exports.prepareState = prepareState;
function failAllowNet(ctx, a) {
    const mask = (0, perm_1.getFromAccount)(a || '', a => a.allow_net);
    const ret = mask && !(0, misc_1.netMatches)(ctx.ip, mask, true);
    if (ret)
        console.debug("Login failed: allow_net");
    return ret;
}
const paramsDecoder = async (ctx, next) => {
    if (ctx.method !== 'POST' || !ctx.originalUrl.startsWith(const_1.API_URI))
        return next();
    const body = await (0, misc_1.readRequestBodyLimited)(ctx, 10 * 1024 * 1024);
    if (!body)
        return;
    ctx.state.params = (0, misc_1.tryJson)(body.text) || {};
    await next();
};
exports.paramsDecoder = paramsDecoder;
// once https cookie is created, http cannot do the same. The solution is to use 2 different cookies.
// But koa-session doesn't support 2 cookies, so I made this hacky solution: keep track of the options object, to modify the key at run-time.
let internalSessionMw;
let options;
events_1.default.once('app', () => // wait for app to be defined
 internalSessionMw = (0, koa_session_1.default)(options = { signed: true, renew: true, sameSite: 'lax' }, index_1.app));
const sessionMiddleware = (ctx, next) => {
    options.key = 'hfs_' + ctx.protocol;
    return internalSessionMw(ctx, next);
};
exports.sessionMiddleware = sessionMiddleware;
