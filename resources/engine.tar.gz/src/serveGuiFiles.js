"use strict";
// This file is part of HFS - Copyright 2021-2023, Massimo Melina <a@rejetto.com> - License https://www.gnu.org/licenses/gpl-3.0.txt
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.logGui = void 0;
exports.serveGuiFiles = serveGuiFiles;
const const_1 = require("./const");
const serveFile_1 = require("./serveFile");
const plugins_1 = require("./plugins");
const api_auth_1 = require("./api.auth");
const apiMiddleware_1 = require("./apiMiddleware");
const path_1 = require("path");
const promises_1 = require("fs/promises");
const misc_1 = require("./misc");
const adminApis_1 = require("./adminApis");
const customHtml_1 = require("./customHtml");
const lodash_1 = __importDefault(require("lodash"));
const config_1 = require("./config");
const lang_1 = require("./lang");
const adminLang_1 = require("./adminLang");
const upload_1 = require("./upload");
const icons_1 = require("./icons");
const middlewares_1 = require("./middlewares");
const size1024 = (0, config_1.defineConfig)(misc_1.CFG.size_1024, false, x => misc_1.formatBytes.k = x ? 1024 : 1000); // we both configure formatBytes, and also provide a compiled version (number instead of boolean)
const splitUploads = (0, config_1.defineConfig)(misc_1.CFG.split_uploads, 0);
exports.logGui = (0, config_1.defineConfig)(misc_1.CFG.log_gui, false);
const frontendOptions = (0, misc_1.newObj)(misc_1.FRONTEND_OPTIONS, (v, k) => (0, config_1.defineConfig)(k, v)); // define default values
frontendOptions[misc_1.CFG.menu_at_top].sub((v, { version, set }) => {
    if (!v && version?.olderThan('3.3.0-alpha1')) // preserve the layout used before this option existed for upgraded installations
        set(true);
});
function serveStatic(uri) {
    const folder = (const_1.DEV ? 'dist/' : '') + uri.slice(2, -1);
    const root = (0, path_1.join)(__dirname, '..', folder);
    prewarmGuiAssets(root) // keep pkg snapshot files in memory before the reported runtime access loss can happen
        .catch(e => console.error(`GUI asset prewarm failed: ${e?.code || e}`));
    return async (ctx) => {
        if (!exports.logGui.get())
            ctx.state.dontLog = true;
        if (ctx.method === 'OPTIONS') {
            ctx.status = const_1.HTTP_NO_CONTENT;
            ctx.set({ Allow: 'OPTIONS, GET, HEAD' });
            return;
        }
        if (!ctx.state.getOrHead)
            return ctx.status = const_1.HTTP_METHOD_NOT_ALLOWED;
        const serveApp = shouldServeApp(ctx);
        const fullPath = (0, path_1.join)(root, serveApp ? '/index.html' : ctx.path);
        const cached = await parseGuiFile(fullPath)
            .catch(e => {
            if (!/^(?:ENOENT|EISDIR)$/.test(e?.code)) // not supposed to happen, and yet a user reported a strange behavior
                console.error(`serveStatic/parseFile: ${String(e)}`);
            return null;
        });
        if (cached === null)
            return ctx.status = const_1.HTTP_NOT_FOUND;
        if (!serveApp) {
            const c = cached.content;
            return (0, serveFile_1.serveFile)(ctx, fullPath, const_1.MIME_AUTO, { ...cached, content: !c.length ? c : adjustBundlerLinks(ctx, uri, c) });
        }
        // we don't cache the index as it's small and may prevent plugins change to apply
        ctx.body = await treatIndex(ctx, uri, String(cached.content));
    };
    async function prewarmGuiAssets(dir) {
        for (const entry of await (0, promises_1.readdir)(dir, { withFileTypes: true })) {
            const fullPath = (0, path_1.join)(dir, entry.name);
            if (entry.isDirectory()) {
                await prewarmGuiAssets(fullPath);
                continue;
            }
            if (!entry.isFile())
                continue;
            await parseGuiFile(fullPath);
        }
    }
    function parseGuiFile(fullPath) {
        return (0, misc_1.parseFile)(fullPath, x => x, const_1.DEV ? 1000 : Infinity); // cache raw bytes so reverse-proxy URL rewriting can still use the current request context
    }
}
function shouldServeApp(ctx) {
    return ctx.state.serveApp ||= ctx.path.endsWith('/') && !ctx.headers.upgrade; // skip websockets
}
function adjustBundlerLinks(ctx, uri, data) {
    const ext = (0, path_1.extname)(ctx.path);
    const filesUri = ctx.state.revProxyPath + uri;
    return ext && !ext.match(/\.(css|html|js|ts|scss)/) ? data
        : String(data).replace(/((?:import[ (]| from )['"])\//g, `$1${filesUri}`)
            .replace(/(=function\(([\w$]+)\)\{return)[`'"]\/[`'"]\+\2\}/g, `$1${JSON.stringify(filesUri)}+$2}`); // vite's preload helper uses the configured absolute base for dynamic dependency hints
}
const getFaviconTimestamp = (0, misc_1.debounceAsync)(async () => {
    const f = adminApis_1.favicon.get();
    return !f ? 0 : (0, misc_1.statWithTimeout)(f).then(x => x?.mtimeMs || 0, () => 0);
}, { retain: 5_000 });
async function treatIndex(ctx, filesUri, body) {
    const session = await api_auth_1.authApis.refresh_session({}, ctx);
    ctx.set('etag', '');
    ctx.set('Cache-Control', 'no-store, no-cache, must-revalidate');
    ctx.type = 'html';
    const isFrontend = filesUri === const_1.FRONTEND_URI ? ' ' : ''; // as a string will allow neater code later
    const pub = ctx.state.revProxyPath + const_1.PLUGINS_PUB_URI;
    // expose plugins' configs that are declared with 'frontend' attribute
    const plugins = Object.fromEntries((0, misc_1.onlyTruthy)((0, plugins_1.mapPlugins)((pl, name) => {
        let configs = (0, misc_1.newObj)((0, plugins_1.getPluginConfigFields)(name), (v, k, skip) => !v.frontend ? skip() :
            adjustValueByConfig(plugins_1.pluginsConfig.get()?.[name]?.[k], pl.getData().config?.[k]));
        configs = (0, plugins_1.getPluginInfo)(name).onFrontendConfig?.(configs) || configs;
        return !lodash_1.default.isEmpty(configs) && [name, configs];
    })));
    const timestamp = await getFaviconTimestamp();
    const adminLangs = isFrontend ? [] : await (0, adminLang_1.getAdminLangs)();
    const lang = isFrontend ? await (0, lang_1.getLangData)(ctx) : await (0, adminLang_1.getAdminLangData)(ctx, adminLangs);
    let group = 0; // this represents the loading-group: all plugins with the same group can be loaded concurrently
    const loadScripts = (0, misc_1.onlyTruthy)((0, plugins_1.mapPlugins)((p, id) => {
        const js = p.frontend_js?.map(f => f.includes('//') ? f : pub + id + '/' + f);
        if (!js?.length)
            return;
        if (p.afterPlugin) // an afterPlugin constraint needs a loading barrier before this plugin's scripts
            group++;
        const ret = { id, group, js };
        if (p.beforePlugin) // a beforePlugin constraint creates a loading barrier after this plugin's scripts
            group++;
        return ret;
    }));
    return body
        .replace(/((?:src|href) *= *['"])\/?(?!([a-z]+:\/)?\/)(?!\?)/g, '$1' + ctx.state.revProxyPath + filesUri)
        .replace(/<(\/)?(head|body)>/g, (all, isClose, name) => {
        const isHead = name === 'head';
        const isBody = !isHead;
        const isOpen = !isClose;
        if (isHead && isOpen)
            return all + `
                    <script>
                    HFS = ${JSON.stringify({
                VERSION: const_1.VERSION,
                API_VERSION: const_1.API_VERSION,
                SPECIAL_URI: const_1.SPECIAL_URI, PLUGINS_PUB_URI: const_1.PLUGINS_PUB_URI, FRONTEND_URI: const_1.FRONTEND_URI,
                pathSeparator: path_1.sep,
                platform: isFrontend ? undefined : process.platform,
                session: session instanceof apiMiddleware_1.ApiError ? null : session,
                plugins,
                loadScripts,
                prefixUrl: ctx.state.revProxyPath || '',
                proxyDetected: Boolean((0, middlewares_1.getProxyDetected)()),
                dontOverwriteUploading: upload_1.dontOverwriteUploading.get(),
                splitUploads: splitUploads.get(),
                disableDefaultStyle: (0, plugins_1.mapPlugins)(p => p.disableDefaultStyle).some(Boolean),
                kb: size1024.compiled(),
                forceTheme: (0, plugins_1.mapPlugins)(p => lodash_1.default.isString(p.isTheme) ? p.isTheme : undefined).find(Boolean),
                customHtml: lodash_1.default.omit((0, customHtml_1.getAllSections)(), ['top', 'bottom', 'htmlHead', 'style']), // exclude the sections we already apply in this phase
                ...(0, misc_1.newObj)(misc_1.FRONTEND_OPTIONS, (v, k) => (0, config_1.getConfig)(k)),
                icons: Object.assign({}, ...(0, plugins_1.mapPlugins)(p => iconsToObj(p.icons, p.id + '/')), iconsToObj(icons_1.customizedIcons)), // name-to-uri 
                lang,
                ...(isFrontend ? {} : { adminLangs, adminLang: adminLang_1.adminLang.get() })
            }, null, 4).replace(/<(\/script)/g, '<"+"$1') /*avoid breaking our script container*/}
                    document.documentElement.setAttribute('ver', HFS.VERSION.split('-')[0])
                    document.documentElement.setAttribute('browser', ${JSON.stringify((0, misc_1.shortenAgent)(ctx.get('user-agent')))})
                    </script>
                    ${isFrontend && `
                        <title>${adminApis_1.title.get()}</title>
                        <link rel="icon" type="image/svg+xml" href="${ctx.state.revProxyPath}/hfs-logo-icon.svg" />
                        <link rel="alternate icon" href="${ctx.state.revProxyPath}/favicon.ico?${timestamp}" />
                        <link rel="shortcut icon" href="${ctx.state.revProxyPath}/favicon.ico?${timestamp}" />
                    ${(0, customHtml_1.getSection)('htmlHead')}`}
                `;
        function iconsToObj(icons, pre = '') {
            return icons && lodash_1.default.mapValues(icons, (v, k) => ctx.state.revProxyPath + const_1.ICONS_URI + pre + k);
        }
        if (isBody && isOpen)
            return `${all}
                    ${isFrontend && (0, customHtml_1.getSection)('top')}
                    <style>
                    :root {
                        ${lodash_1.default.map(plugins, (configs, pluginName) => // make plugin configs accessible via css
             lodash_1.default.map(configs, (v, k) => {
                v = serializeCss(v);
                return typeof v === 'string' && `\n--${pluginName}-${k}: ${v};`;
            }).filter(Boolean).join('')).join('')}
                    }
                    ${isFrontend && (0, customHtml_1.getSection)('style')}
                    </style>
                    ${isFrontend && (0, plugins_1.mapPlugins)((plug, id) => plug.frontend_css?.map(f => `<link rel='stylesheet' type='text/css' href='${f.includes('//') ? f : pub + id + '/' + f}' plugin=${JSON.stringify(id)}/>`))
                .flat().filter(Boolean).join('\n')}
                `;
        if (isBody && isClose)
            return (0, customHtml_1.getSection)('bottom') + all;
        return all; // unchanged
    });
    function adjustValueByConfig(v, cfg) {
        v ??= cfg.defaultValue;
        const { type } = cfg;
        if (v && type === 'vfs_path') {
            v = (0, misc_1.enforceStarting)('/', v);
            const { root } = ctx.state;
            if (root)
                if (v.startsWith(root))
                    v = v.slice(root.length - 1);
                else
                    return;
            if (ctx.state.revProxyPath)
                v = ctx.state.revProxyPath + v;
        }
        else if (type === 'array' && Array.isArray(v))
            v = v.map(x => lodash_1.default.mapValues(x, (xv, xk) => adjustValueByConfig(xv, cfg.fields[xk])));
        return v;
    }
}
function serializeCss(v) {
    return typeof v === 'string' && /^#[0-9a-fA-F]{3,8}|rgba?\(.+\)$/.test(v) ? v // colors
        : (0, misc_1.isPrimitive)(v) ? JSON.stringify(v)?.replace(/</g, '&lt;') : undefined;
}
function serveProxied(port, uri) {
    if (!port)
        return;
    console.debug('Proxied on port', port);
    let proxy;
    import('koa-better-http-proxy').then(lib => // dynamic import to avoid having this in final distribution
     proxy = lib.default('127.0.0.1:' + port, {
        parseReqBody: false, // the dev GUI proxy serves app/assets, so avoid koa-better-http-proxy trying to reread ctx.req
        proxyReqPathResolver: (ctx) => shouldServeApp(ctx) ? '/' : ctx.url,
        userResDecorator(_res, data, ctx) {
            return shouldServeApp(ctx) ? treatIndex(ctx, uri, String(data))
                : adjustBundlerLinks(ctx, uri, data);
        }
    }));
    return function (ctx, _next) {
        if (!exports.logGui.get())
            ctx.state.dontLog = true;
        return proxy(ctx, async () => { });
    };
}
function serveGuiFiles(proxyPort, uri) {
    return serveProxied(proxyPort, uri) || serveStatic(uri);
}
