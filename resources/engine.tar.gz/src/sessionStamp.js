"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sessionStampsReady = void 0;
exports.getSessionStamp = getSessionStamp;
exports.renewSessionStamp = renewSessionStamp;
exports.syncSessionStamps = syncSessionStamps;
const persistence_1 = require("./persistence");
const node_crypto_1 = require("node:crypto");
const stamps = new Map();
const prefix = 'sessionStamp:';
// random signing keys already invalidate all cookies on restart
const persistent = process.env.COOKIE_SIGN_KEYS !== undefined;
exports.sessionStampsReady = load();
function getSessionStamp(username) {
    return stamps.get(username)?.stamp;
}
function renewSessionStamp(username) {
    const current = stamps.get(username);
    if (current)
        setStamp(username, current.credentials);
}
function syncSessionStamps(accounts) {
    for (const username of stamps.keys())
        if (!(username in accounts)) {
            stamps.delete(username);
            if (persistent)
                void persistence_1.storedMap.del(prefix + username);
        }
    for (const [username, account] of Object.entries(accounts)) {
        // compare values across reloads and restarts without duplicating credentials in data.kv
        const credentials = (0, node_crypto_1.createHash)('sha256').update(JSON.stringify([
            account?.srp, account?.password, account?.plugin,
        ])).digest('hex');
        if (stamps.get(username)?.credentials !== credentials)
            setStamp(username, credentials);
    }
}
function setStamp(username, credentials) {
    const stamp = `${Date.now()}.${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`;
    const record = { stamp, credentials };
    stamps.set(username, record);
    // accepted tradeoff: with fixed signing keys, a crash before this delayed write may lose a revocation
    if (persistent)
        void persistence_1.storedMap.put(prefix + username, record);
}
async function load() {
    for await (const [key, record] of persistence_1.storedMap.iterator({ startsWith: prefix })) {
        if (persistent)
            stamps.set(key.slice(prefix.length), record);
        else // re-enabling the same signing keys later must not revive cookies revoked during this run
            void persistence_1.storedMap.del(key);
    }
}
