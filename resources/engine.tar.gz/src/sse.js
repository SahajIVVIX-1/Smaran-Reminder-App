"use strict";
// This file is part of HFS - Copyright 2021-2023, Massimo Melina <a@rejetto.com> - License https://www.gnu.org/licenses/gpl-3.0.txt
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = createSSE;
const stream_1 = require("stream");
const const_1 = require("./const");
function createSSE(ctx) {
    const { socket } = ctx.req;
    socket.setTimeout(0);
    socket.setNoDelay(true);
    socket.setKeepAlive(true);
    ctx.set({
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'X-Accel-Buffering': 'no', // avoid buffering when reverse-proxied through nginx
    });
    ctx.status = const_1.HTTP_OK;
    return ctx.body = new stream_1.Transform({
        objectMode: true,
        transform(chunk, encoding, cb) {
            this.push(`data: ${JSON.stringify(chunk)}\n\n`);
            cb();
        },
        flush(cb) {
            this.push('data:\n\n');
            cb();
        }
    });
}
