"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleAdminReset = handleAdminReset;
const fs_1 = __importDefault(require("fs"));
const config_1 = require("./config");
const auth_1 = require("./auth");
const perm_1 = require("./perm");
const adminApis_1 = require("./adminApis");
const misc_1 = require("./misc");
const vfs_1 = require("./vfs");
async function handleAdminReset(ctx) {
    if (ctx.method === 'GET') {
        ctx.type = 'html';
        ctx.body = renderResetPage();
        return;
    }
    if (ctx.method === 'POST') {
        const body = await (0, misc_1.readRequestBodyLimited)(ctx, 1024 * 1024);
        let username = '';
        let password = '';
        if (body?.text) {
            try {
                const json = JSON.parse(body.text);
                username = json.username || '';
                password = json.password || '';
            }
            catch {
                const params = new URLSearchParams(body.text);
                username = params.get('username') || '';
                password = params.get('password') || '';
            }
        }
        let authorized = false;
        // 1. Check if user credentials match an admin
        if (username && password) {
            const account = await (0, auth_1.clearTextLogin)(ctx, username, password, 'admin_reset');
            if (account && (0, perm_1.accountCanLoginAdmin)(account)) {
                authorized = true;
            }
        }
        // 2. Also allow if already authenticated in this session as admin and password confirmed
        if (!authorized && (0, adminApis_1.ctxAdminAccess)(ctx) && password) {
            const currentU = ctx.state.account?.username;
            if (currentU) {
                const account = await (0, auth_1.clearTextLogin)(ctx, currentU, password, 'admin_reset');
                if (account && (0, perm_1.accountCanLoginAdmin)(account)) {
                    authorized = true;
                }
            }
        }
        if (!authorized) {
            ctx.status = 401;
            ctx.type = 'html';
            ctx.body = renderResetPage('Invalid admin credentials. Please enter the correct administrator username and password.');
            return;
        }
        // Preserve existing VFS storage root directory if present
        let currentRootDir = '';
        try {
            const curVfs = vfs_1.vfs.get();
            if (curVfs && typeof curVfs === 'object' && 'source' in curVfs && typeof curVfs.source === 'string') {
                currentRootDir = curVfs.source;
            }
        }
        catch { }
        const vfsBlock = currentRootDir
            ? `vfs:\n  source: "${currentRootDir.replace(/\\/g, '/')}"\n  can_see: "*"\n  can_read: "*"\n  can_list: "*"`
            : `vfs:\n  can_see: "*"\n  can_read: "*"\n  can_list: "*"`;
        const defaultYaml = `# Restored by Smaran HFS Reset
title: Smaran HFS
port: 5901
localhost_admin: false
force_theme: dark
open_browser: false
accept_cors: true
accounts:
  smaran:
    password: "smaran"
    admin: true
    ignore_limits: true
    belongs:
      - admistrators
  admistrators:
    ignore_limits: true
    admin: true
${vfsBlock}
enable_plugins:
  - antibrute
  - download-counter
  - server-info
  - list-uploader
  - share-links
  - sharp
  - thumbnails
  - chat-plus
  - auto-refresh
  - password-rules
  - video-player
  - mini-player
  - url-shortener
  - show-any
  - tls-tunnel
  - trashbin
  - copy-files
  - Hide-file
  - shared
plugins_config:
  share-links:
    onlyFor:
      - smaran
  thumbnails:
    log: true
    videos: true
  chat-plus:
    anonWrite: true
    anonRead: true
  password-rules:
    minLength: 4
  url-shortener:
    linkPrefix: /smaran
    managementAPI: true
    linkSlashAllowed: true
    linkEditAllowed: true
  copy-files:
    onlyFor:
      - admistrators
      - smaran
  Hide-file:
    hideFiles: ""
    hideExactFiles: ""
    hideFolders: ""
  trashbin:
    trashbin_verboseLogging: true
`;
        try {
            fs_1.default.writeFileSync(config_1.filePath, defaultYaml, 'utf8');
        }
        catch (writeErr) {
            console.error('Failed to reset config.yaml:', writeErr);
            ctx.status = 500;
            ctx.type = 'html';
            ctx.body = renderResetPage('Failed to write default configuration: ' + String(writeErr));
            return;
        }
        ctx.type = 'html';
        ctx.body = renderSuccessPage(ctx.hostname);
        // Trigger clean exit so process supervisor reloads with default config
        setTimeout(() => {
            process.exit(100);
        }, 1200);
    }
}
function renderResetPage(error) {
    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Smaran HFS - Reset to Defaults</title>
  <link rel="icon" type="image/svg+xml" href="/hfs-logo-icon.svg">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background-color: #0d0d10;
      color: #e4e4e7;
      font-family: 'Inter', system-ui, -apple-system, sans-serif;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 1.5rem;
    }
    .card {
      background-color: #141418;
      border: 1px solid #27272a;
      border-radius: 1rem;
      max-width: 460px;
      width: 100%;
      padding: 2.25rem 2rem;
      box-shadow: 0 20px 40px rgba(0, 0, 0, 0.6);
    }
    .header {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      margin-bottom: 1.5rem;
    }
    .logo {
      width: 36px;
      height: 36px;
    }
    .brand-title {
      font-size: 1.35rem;
      font-weight: 700;
      color: #fafafa;
      letter-spacing: -0.02em;
    }
    .badge {
      display: inline-block;
      font-size: 0.75rem;
      font-weight: 600;
      background-color: rgba(224, 108, 67, 0.15);
      color: #e06c43;
      border: 1px solid rgba(224, 108, 67, 0.3);
      padding: 0.2rem 0.6rem;
      border-radius: 9999px;
      margin-bottom: 1rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }
    h1 {
      font-size: 1.25rem;
      font-weight: 600;
      color: #f4f4f5;
      margin-bottom: 0.6rem;
    }
    p.desc {
      font-size: 0.875rem;
      line-height: 1.5;
      color: #a1a1aa;
      margin-bottom: 1.5rem;
    }
    .notice {
      background-color: #1a1615;
      border-left: 3px solid #e06c43;
      padding: 0.75rem 1rem;
      border-radius: 0.375rem;
      margin-bottom: 1.5rem;
      font-size: 0.8125rem;
      color: #d4d4d8;
      line-height: 1.45;
    }
    .error-box {
      background-color: rgba(239, 68, 68, 0.1);
      border: 1px solid rgba(239, 68, 68, 0.3);
      color: #f87171;
      padding: 0.75rem 1rem;
      border-radius: 0.5rem;
      font-size: 0.85rem;
      margin-bottom: 1.25rem;
    }
    .field {
      margin-bottom: 1.25rem;
    }
    label {
      display: block;
      font-size: 0.8125rem;
      font-weight: 500;
      color: #d4d4d8;
      margin-bottom: 0.4rem;
    }
    input {
      width: 100%;
      background-color: #1c1c22;
      border: 1px solid #3f3f46;
      border-radius: 0.5rem;
      padding: 0.65rem 0.875rem;
      color: #fafafa;
      font-size: 0.9rem;
      font-family: inherit;
      outline: none;
      transition: border-color 0.15s, box-shadow 0.15s;
    }
    input:focus {
      border-color: #e06c43;
      box-shadow: 0 0 0 2px rgba(224, 108, 67, 0.2);
    }
    .btn-reset {
      width: 100%;
      background-color: #dc2626;
      color: #ffffff;
      border: none;
      border-radius: 0.5rem;
      padding: 0.75rem 1rem;
      font-size: 0.925rem;
      font-weight: 600;
      font-family: inherit;
      cursor: pointer;
      transition: background-color 0.15s, transform 0.05s;
      margin-top: 0.5rem;
    }
    .btn-reset:hover {
      background-color: #b91c1c;
    }
    .btn-reset:active {
      transform: scale(0.99);
    }
    .footer-link {
      display: block;
      text-align: center;
      margin-top: 1.25rem;
      color: #71717a;
      text-decoration: none;
      font-size: 0.8125rem;
      transition: color 0.15s;
    }
    .footer-link:hover {
      color: #e06c43;
    }
  </style>
</head>
<body>
  <div class="card">
    <div class="header">
      <img src="/hfs-logo-icon.svg" alt="Smaran Logo" class="logo">
      <span class="brand-title">Smaran HFS</span>
    </div>
    <div class="badge">Factory Reset</div>
    <h1>Reset Server to Defaults</h1>
    <p class="desc">Resetting will restore all server configurations, admin credentials (<strong>smaran</strong> / <strong>smaran</strong>), default port (<strong>5901</strong>), and bundled plugin settings back to factory defaults.</p>
    
    <div class="notice">
      Shared and uploaded files on disk will <strong>not</strong> be deleted.
    </div>

    ${error ? `<div class="error-box">${error}</div>` : ''}

    <form method="POST" action="/~/admin/reset">
      <div class="field">
        <label for="username">Administrator Username</label>
        <input type="text" id="username" name="username" value="smaran" required autocomplete="username">
      </div>
      <div class="field">
        <label for="password">Administrator Password</label>
        <input type="password" id="password" name="password" placeholder="Enter current admin password" required autocomplete="current-password" autofocus>
      </div>
      <button type="submit" class="btn-reset">Confirm & Reset to Defaults</button>
    </form>

    <a href="/~/admin/" class="footer-link">← Cancel and Return to Admin Panel</a>
  </div>
</body>
</html>`;
}
function renderSuccessPage(hostname) {
    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Smaran HFS - Reset Complete</title>
  <link rel="icon" type="image/svg+xml" href="/hfs-logo-icon.svg">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background-color: #0d0d10;
      color: #e4e4e7;
      font-family: 'Inter', system-ui, -apple-system, sans-serif;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 1.5rem;
    }
    .card {
      background-color: #141418;
      border: 1px solid #27272a;
      border-radius: 1rem;
      max-width: 460px;
      width: 100%;
      padding: 2.25rem 2rem;
      text-align: center;
      box-shadow: 0 20px 40px rgba(0, 0, 0, 0.6);
    }
    .icon-success {
      width: 56px;
      height: 56px;
      border-radius: 50%;
      background-color: rgba(34, 197, 94, 0.15);
      border: 2px solid #22c55e;
      color: #22c55e;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.75rem;
      font-weight: bold;
      margin: 0 auto 1.25rem;
    }
    h1 {
      font-size: 1.35rem;
      font-weight: 700;
      color: #fafafa;
      margin-bottom: 0.6rem;
    }
    p.desc {
      font-size: 0.875rem;
      color: #a1a1aa;
      line-height: 1.5;
      margin-bottom: 1.5rem;
    }
    .creds-box {
      background-color: #1c1c22;
      border: 1px solid #3f3f46;
      border-radius: 0.5rem;
      padding: 1rem;
      text-align: left;
      font-size: 0.875rem;
      line-height: 1.6;
      margin-bottom: 1.5rem;
    }
    .creds-row {
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #27272a;
      padding-bottom: 0.35rem;
      margin-bottom: 0.35rem;
    }
    .creds-row:last-child {
      border-bottom: none;
      padding-bottom: 0;
      margin-bottom: 0;
    }
    .label {
      color: #a1a1aa;
    }
    .val {
      font-family: monospace;
      color: #e06c43;
      font-weight: 600;
    }
    .redirect {
      font-size: 0.8125rem;
      color: #71717a;
    }
    .countdown {
      color: #e06c43;
      font-weight: bold;
    }
  </style>
</head>
<body>
  <div class="card">
    <div class="icon-success">✓</div>
    <h1>Settings Restored to Defaults</h1>
    <p class="desc">Smaran HFS has successfully reset to default settings and all bundled plugins are enabled.</p>
    
    <div class="creds-box">
      <div class="creds-row">
        <span class="label">Admin Username:</span>
        <span class="val">smaran</span>
      </div>
      <div class="creds-row">
        <span class="label">Admin Password:</span>
        <span class="val">smaran</span>
      </div>
      <div class="creds-row">
        <span class="label">Port:</span>
        <span class="val">5901</span>
      </div>
    </div>

    <p class="redirect">Server restarting with default configuration... Redirecting to admin panel in <span id="sec" class="countdown">3</span> seconds.</p>
  </div>
  <script>
    let s = 3;
    const dest = 'http://' + window.location.hostname + ':5901/~/admin/';
    const timer = setInterval(() => {
      s--;
      const el = document.getElementById('sec');
      if (el) el.innerText = s;
      if (s <= 0) {
        clearInterval(timer);
        window.location.href = dest;
      }
    }, 1000);
  </script>
</body>
</html>`;
}
