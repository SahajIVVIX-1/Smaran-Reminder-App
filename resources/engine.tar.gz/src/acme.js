"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.acmeRenewError = exports.acmeMiddleware = void 0;
exports.getAcmeStatus = getAcmeStatus;
exports.getAcmeStatusEvents = getAcmeStatusEvents;
exports.makeCert = makeCert;
const misc_1 = require("./misc");
const http_1 = require("http");
const nat_1 = require("./nat");
const listen_1 = require("./listen");
const apiMiddleware_1 = require("./apiMiddleware");
const acme_client_1 = __importDefault(require("acme-client"));
const debounceAsync_1 = require("./debounceAsync");
const promises_1 = __importDefault(require("fs/promises"));
const acmeConfig_1 = require("./acmeConfig");
const acmeDns_1 = require("./acmeDns");
const github_1 = require("./github");
const promises_2 = require("node:dns/promises");
const node_stream_1 = require("node:stream");
const events_1 = __importDefault(require("./events"));
const selfCheck_1 = require("./selfCheck");
const net_1 = require("net");
let acmeOngoing = false;
const acmeTokens = {};
const acmeListener = (req, res) => {
    const BASE = '/.well-known/acme-challenge/';
    if (!req.url?.startsWith(BASE))
        return;
    const token = req.url.slice(BASE.length);
    console.debug("Got http challenge", token);
    res.statusCode = misc_1.HTTP_OK;
    res.end(acmeTokens[token]);
    return true; // true = responded
};
const acmeMiddleware = (ctx, next) => {
    if (!acmeOngoing || !acmeListener(ctx.req, ctx.res))
        return next();
};
exports.acmeMiddleware = acmeMiddleware;
const TEMP_MAP = (0, nat_1.upnpMappingParam)(80, 80, 'hfs temporary', 5000); // from my tests (zyxel VMG8825), lower values won't make a working mapping
// remove temporary port mapping, if any is left from previous execution
(0, misc_1.repeat)(misc_1.MINUTE, async (stop) => {
    if (!await nat_1.upnpEnabled.getWhenReady())
        return stop();
    const client = (0, nat_1.getUpnpClient)();
    await client.getGateway(); // without this, the next call will break upnp support
    const res = await client.getMappings();
    const leftover = res.find(x => x.description === TEMP_MAP.description); // in case the process is interrupted
    if (!leftover)
        return void stop(); // we are good
    if (acmeOngoing)
        return; // it doesn't count, as we are in the middle of something. Retry later
    stop();
    return client.removeMapping(TEMP_MAP);
});
async function generateSSLCert(names, email) {
    const domain = names[0];
    const method = acmeConfig_1.acmeChallenge.get();
    const ipCertificate = names.some(net_1.isIP);
    if (!['http-01', 'dns-01'].includes(method))
        throw Error("Invalid certificate validation method");
    if (method === 'http-01' && names.some(n => n.startsWith('*.')))
        throw Error("Select a DNS provider for wildcard certificates");
    if (method === 'dns-01' && ipCertificate)
        throw Error("DNS validation cannot be used for IP addresses");
    const config = structuredClone(acmeConfig_1.acmeDns.get()[0]);
    const info = method === 'dns-01' ? await (0, github_1.getProjectInfo)() : undefined;
    const provider = info && config && (0, acmeDns_1.getDnsProviders)(info.acmeDns).get(config.provider);
    if (method === 'dns-01') {
        if (!provider?.available || config?.config_version !== provider.config_version)
            throw Error("DNS provider unavailable or incompatible; update HFS or reconfigure the provider");
        if (Object.keys(provider.fields).some(k => !config.credentials?.[k]))
            throw Error("Enter the DNS provider credentials");
    }
    const resolver = new promises_2.Resolver({ timeout: 3000, tries: 2 });
    if (info)
        resolver.setServers(info.dnsServers);
    const cleanups = new Map();
    const cleanupErrors = [];
    let tempSrv;
    let tempMap;
    acmeOngoing = true;
    try {
        if (method === 'http-01') {
            progress("Checking port 80");
            const nat = await (0, nat_1.getNatInfo)();
            const { http } = await (0, listen_1.getServerStatus)();
            if (!(nat.externalPort === 80 || http.listening && http.port === 80)) {
                tempSrv = (0, http_1.createServer)((req, res) => acmeListener(req, res) || res.end('HFS'));
                await new Promise(resolve => tempSrv.listen(80, resolve).on('error', () => resolve()));
            }
            const checkUrl = `http://${(0, misc_1.ipForUrl)(domain)}`;
            let check = await (0, selfCheck_1.selfCheck)(checkUrl);
            if (check?.success === false && nat.upnp && !nat.mapped80) {
                tempMap = await (0, misc_1.haveTimeout)(10_000, (0, nat_1.getUpnpClient)().createMapping(TEMP_MAP)).catch(() => undefined);
                check = await (0, selfCheck_1.selfCheck)(checkUrl);
            }
            if (check?.success === false)
                throw new apiMiddleware_1.ApiError(misc_1.HTTP_FAILED_DEPENDENCY, "port 80 is not working on the specified domain");
        }
        progress("Requesting certificate");
        const acmeClient = new acme_client_1.default.Client({
            accountKey: await acme_client_1.default.crypto.createPrivateKey(),
            directoryUrl: acme_client_1.default.directory.letsencrypt.production
        });
        if (ipCertificate) {
            const original = acmeClient.createOrder.bind(acmeClient);
            acmeClient.createOrder = order => original({
                ...order, // acme-client auto() hardcodes every order identifier as DNS and cannot select the profile required for IP certificates
                profile: 'shortlived',
                identifiers: order.identifiers.map(({ value }) => ({ value, type: (0, net_1.isIP)(value) ? 'ip' : 'dns' }))
            }); // profile key is not declared in types, but is needed for letsencrypt
        }
        acme_client_1.default.setLogger(console.debug);
        const [key, csr] = await acme_client_1.default.crypto.createCsr({
            commonName: (0, net_1.isIP)(domain) ? undefined : domain, // rejected because Boulder doesn't accept IP addresses in the Common Name
            altNames: names,
        });
        const cert = await acmeClient.auto({
            csr,
            email,
            challengePriority: [method],
            skipChallengeVerification: true, // on NAT, trying to connect to your external ip will likely get your modem instead of the challenge server
            termsOfServiceAgreed: true,
            async challengeCreateFn(auth, challenge, value) {
                if (challenge.type !== method)
                    throw Error("Unsupported ACME challenge");
                if (method === 'http-01') {
                    acmeTokens[challenge.token] = value;
                }
                else {
                    progress("Creating DNS TXT record", auth.identifier.value);
                    const record = await (0, acmeDns_1.dnsChallengeRecord)(auth.identifier.value, value, resolver);
                    cleanups.set(challenge.token, await provider.present(record, config.credentials));
                    progress("Waiting for DNS propagation", auth.identifier.value);
                    await (0, acmeDns_1.waitForDnsRecord)(record, resolver, provider.propagation_timeout === undefined ? undefined : provider.propagation_timeout * 1000);
                }
                progress("Validating domain", auth.identifier.value);
            },
            async challengeRemoveFn(_, challenge) {
                delete acmeTokens[challenge.token];
                const cleanup = cleanups.get(challenge.token);
                if (cleanup) {
                    cleanups.delete(challenge.token);
                    // acme-client suppresses cleanup errors, so keep them visible in the final status
                    try {
                        await cleanup();
                    }
                    catch {
                        cleanupErrors.push("Could not remove a DNS challenge TXT record");
                    }
                }
            },
        });
        console.log("ACME certificate generated");
        return { key, cert, warning: cleanupErrors.join("; ") || undefined };
    }
    catch (error) {
        if (method === 'http-01' && error instanceof Error) {
            if (error.message.includes('Timeout'))
                error = Error("ensure your router is forwarding port 80 correctly");
            else if (error.message.includes('not match this challenge'))
                error = Error("a different server is responding on port 80 of your domain(s)");
        }
        if (cleanupErrors.length)
            throw Error(`${error instanceof Error ? error.message : error}; ${cleanupErrors.join('; ')}`);
        throw error;
    }
    finally {
        if (tempMap && nat_1.upnpEnabled.get()) {
            console.debug("Removing temporary port forward");
            (0, nat_1.getUpnpClient)().removeMapping(TEMP_MAP).catch(() => { }); // clean after ourselves
        }
        acmeOngoing = false;
        if (tempSrv?.listening)
            await new Promise(res => tempSrv.close(() => res()));
        console.debug('ACME terminated');
    }
}
let acmeStatus = { id: 0, state: 'idle', message: '' };
function getAcmeStatus() { return acmeStatus; }
function progress(message, domain) {
    acmeStatus = { ...acmeStatus, message, domain };
    events_1.default.emit('acmeStatus', acmeStatus);
}
function getAcmeStatusEvents() {
    let off;
    return new node_stream_1.Readable({
        objectMode: true,
        read() {
            if (off)
                return;
            off = events_1.default.on('acmeStatus', status => this.push(status));
            this.once('close', off);
            this.push(acmeStatus);
        },
    });
}
async function makeCert(domain, email, altNames = []) {
    if (acmeStatus.state === 'running')
        throw Error("Certificate request already running");
    acmeStatus = { id: acmeStatus.id + 1, state: 'running', message: '' };
    progress("Starting certificate request");
    try {
        const names = (0, acmeDns_1.certificateNames)([domain, ...altNames]);
        const res = await generateSSLCert(names, email);
        progress("Installing certificate");
        const CERT_FILE = 'acme.cer';
        const KEY_FILE = 'acme.key';
        await promises_1.default.writeFile(KEY_FILE, res.key, { mode: 0o600 });
        await promises_1.default.writeFile(CERT_FILE, res.cert);
        listen_1.cert.set(CERT_FILE);
        listen_1.privateKey.set(KEY_FILE);
        exports.acmeRenewError = '';
        acmeStatus = { ...acmeStatus, state: 'done', warning: res.warning };
        progress("Certificate created");
    }
    catch (error) {
        acmeStatus = { ...acmeStatus, state: 'error' };
        progress(error instanceof Error ? error.message : String(error));
        throw error;
    }
}
exports.acmeRenewError = '';
events_1.default.once('httpsReady', () => (0, misc_1.repeat)(misc_1.HOUR, renewCert));
// checks if the cert is near expiration date, and if so renews it
const renewCert = (0, debounceAsync_1.debounceAsync)(async () => {
    const [domain, ...altNames] = acmeConfig_1.acmeDomain.get().split(',');
    if (!acmeConfig_1.acmeRenew.get() || !domain)
        return;
    const cert = (0, listen_1.getCertObject)();
    if (!cert)
        return;
    const now = new Date();
    const validFrom = new Date(cert.validFrom);
    const validTo = new Date(cert.validTo);
    // renew during the final third, adapting automatically to short-lived certificates
    const renewBefore = (validTo.getTime() - validFrom.getTime()) / 3;
    if (now > validFrom && now < validTo && validTo.getTime() - now.getTime() >= renewBefore)
        return console.log("Certificate still good");
    await makeCert(domain, undefined, altNames)
        .catch(e => console.log(exports.acmeRenewError = `Error renewing certificate, expiring ${(0, misc_1.formatDate)(validTo)}: ${String(e.message || e)}`));
}, { retain: misc_1.HOUR }); // short-lived certificates leave a renew window of just 2 days, and a failed renew is retained as a success here
