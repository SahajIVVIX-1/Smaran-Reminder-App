"use strict";
// This file is part of HFS - Copyright 2021-2023, Massimo Melina <a@rejetto.com> - License https://www.gnu.org/licenses/gpl-3.0.txt
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const apiMiddleware_1 = require("./apiMiddleware");
const lodash_1 = __importDefault(require("lodash"));
const fast_glob_1 = __importDefault(require("fast-glob"));
const promises_1 = require("fs/promises");
const const_1 = require("./const");
const misc_1 = require("./misc");
const lang_1 = require("./lang");
const embedded_1 = __importDefault(require("./langs/embedded"));
const embedded_2 = __importDefault(require("./admin-langs/embedded"));
const adminLang_1 = require("./adminLang");
const SendList_1 = require("./SendList");
const apis = {
    get_langs() {
        return new SendList_1.SendListReadable({
            doAtStart: async (list) => {
                for (const admin of [false, true]) {
                    for await (const name of fast_glob_1.default.stream((0, lang_1.code2file)('*', admin))) {
                        const code = (0, lang_1.file2code)(String(name), admin);
                        try {
                            const data = JSON.parse(await (0, promises_1.readFile)(String(name), 'utf8'));
                            list.add({ ...lodash_1.default.omit(data, 'translate'), code, admin, embedded: false });
                        }
                        catch { }
                    }
                    for (const [code, data] of Object.entries(admin ? embedded_2.default : embedded_1.default))
                        list.add({ ...lodash_1.default.omit(data, 'translate'), code, admin, embedded: true });
                }
                list.close();
            }
        });
    },
    async del_lang({ code, admin = false }) {
        (0, misc_1.apiAssertTypes)({ string: { code }, boolean: { admin } });
        validateCode(code);
        try {
            await (0, promises_1.rm)((0, lang_1.code2file)(code, admin));
            if (admin)
                (0, adminLang_1.invalidateAdminLang)(code.toLowerCase());
            return {};
        }
        catch (e) {
            return new apiMiddleware_1.ApiError(const_1.HTTP_SERVER_ERROR, e);
        }
    },
    async add_langs({ langs }) {
        (0, misc_1.apiAssertTypes)({ object: { langs } });
        for (let [code, content] of Object.entries(langs)) {
            const admin = code.startsWith('hfs-admin-lang-');
            code = (0, lang_1.file2code)(code, admin);
            validateCode(code);
            const fn = (0, lang_1.code2file)(code, admin);
            const s = String(content);
            const o = (0, misc_1.tryJson)(s);
            if (!o?.translate)
                return new apiMiddleware_1.ApiError(const_1.HTTP_NOT_ACCEPTABLE, "bad content for file " + fn);
            await (0, promises_1.writeFile)(fn, s, 'utf8');
            if (admin)
                (0, adminLang_1.invalidateAdminLang)(code.toLowerCase());
        }
        return {};
    }
};
exports.default = apis;
function validateCode(code) {
    if ((0, lang_1.normalizeLangCode)(code) !== code.toLowerCase())
        throw new apiMiddleware_1.ApiError(const_1.HTTP_BAD_REQUEST, 'bad code/filename');
}
