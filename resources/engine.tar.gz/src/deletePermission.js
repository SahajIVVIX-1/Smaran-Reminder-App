"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkDeletePermission = checkDeletePermission;
const promises_1 = __importDefault(require("node:fs/promises"));
const node_path_1 = require("node:path");
const cross_1 = require("./cross");
const const_1 = require("./const");
const events_1 = __importDefault(require("./events"));
const uploadOwners_1 = require("./uploadOwners");
const vfs_1 = require("./vfs");
// unlike a listing, deletion affects hidden entries and must fail if any directory cannot be read
async function checkDeletePermission(node, ctx) {
    if ((0, vfs_1.statusCodeForMissingPerm)(node, 'can_delete', ctx))
        return false;
    if (!node.source || !(await promises_1.default.lstat(node.source)).isDirectory())
        return true;
    return recur(node, []);
    async function recur(parent, scopes) {
        // explicit VFS entries are not deletable, even when their source is several levels below this directory
        for (const child of explicitNodes(parent)) {
            if (!child.source)
                continue;
            const path = (0, node_path_1.relative)((0, node_path_1.resolve)(parent.source), (0, node_path_1.resolve)(child.source));
            if (path === '..' || path.startsWith('..' + node_path_1.sep) || (0, node_path_1.isAbsolute)(path))
                continue;
            try {
                await promises_1.default.lstat(child.source);
            }
            catch (error) {
                if (error.code === 'ENOENT')
                    continue;
                throw error;
            }
            ctx.status = const_1.HTTP_FORBIDDEN;
            await reportBlocked(child);
            return false;
        }
        const inherited = (0, vfs_1.permsFromParent)(parent, {}) || {};
        const keys = new Set(['can_delete']);
        for (const key of keys) {
            addReferences(parent[key] ?? cross_1.defaultPerms[key]);
            addReferences(inherited[key] ?? cross_1.defaultPerms[key]);
        }
        // skip scanning descendants only when inherited permissions guarantee deletion and no deeper rule or plugin can override them
        if (!scopes.some(scope => hasRules(scope.node, keys)) && !hasRules(parent, keys)
            && !cross_1.PERM_KEYS.some(key => (0, cross_1.isWhoObject)(inherited[key]))
            && !events_1.default.hasOtherListeners('checkVfsPermission', uploadOwners_1.grantUploadOwnerDelete)
            && !(0, vfs_1.statusCodeForMissingPerm)(inherited, 'can_delete', ctx, false, false))
            return true;
        // only literal path prefixes can be exhausted by inheritMasks; other patterns may match again deeper down
        const persistentMasks = Object.fromEntries(Object.entries(parent.masks || {}).filter(([mask, mods]) => mods && (cross_1.PERM_KEYS.some(key => mods[key] !== undefined) || hasRules(mods, new Set(cross_1.PERM_KEYS)))
            && (!mask.includes('/') || /[!*?\[\]{}()|\\]/.test(mask.split('/')[0]))));
        if (Object.keys(persistentMasks).length)
            scopes = [...scopes, { node: { masks: persistentMasks }, path: '' }];
        for await (const entry of await promises_1.default.opendir(parent.source)) {
            if (ctx.isAborted())
                throw Error("Deletion cancelled");
            const source = (0, node_path_1.join)(parent.source, entry.name);
            const name = (0, vfs_1.getVirtualName)(entry.name, parent, source);
            const explicit = (0, vfs_1.getChildBySource)(parent, source);
            // permission masks use the target type, but deletion must never recurse through the link
            const isFolder = entry.isSymbolicLink()
                ? await promises_1.default.stat(source).then(stats => stats.isDirectory(), error => {
                    if (error.code === 'ENOENT')
                        return false;
                    throw error;
                }) : entry.isDirectory();
            const child = {
                ...explicit, original: explicit, source, isFolder,
                rename: explicit?.rename || (0, vfs_1.renameUnderPath)(parent.rename, entry.name),
            };
            const nextScopes = scopes.map(scope => ({ node: scope.node, path: scope.path + name }));
            for (const scope of [...nextScopes].reverse()) {
                (0, vfs_1.parentMaskApplier)(scope.node, true)(child, scope.path);
                (0, vfs_1.parentMaskApplier)(scope.node)(child, name);
            }
            const evaluated = (0, vfs_1.applyParentToChild)(child, parent, name);
            if ((0, vfs_1.statusCodeForMissingPerm)(evaluated, 'can_delete', ctx)) {
                await reportBlocked(evaluated);
                return false;
            }
            // dirents do not follow symlinks, including dangling links
            if (entry.isDirectory() && !await recur(evaluated, nextScopes.map(scope => ({ ...scope, path: scope.path + '/' }))))
                return false;
        }
        return true;
        function addReferences(who) {
            if ((0, cross_1.isWhoObject)(who)) {
                if (who.this !== undefined)
                    addReferences(who.this);
                if (who.children !== undefined)
                    addReferences(who.children);
            }
            else if (typeof who === 'string' && cross_1.PERM_KEYS.includes(who))
                keys.add(who);
        }
    }
    async function reportBlocked(blocked) {
        // a deletion error must not disclose names hidden by access permissions
        let visible = blocked;
        for (let ancestor = blocked; ancestor && ancestor !== node; ancestor = ancestor.parent)
            if (!(0, vfs_1.hasPermission)(ancestor, 'can_see', ctx) || !await (0, vfs_1.urlToNode)(ancestor.vfsPath, ctx)
                || ancestor.parent && !(0, vfs_1.hasPermission)(ancestor.parent, 'can_list', ctx))
                visible = ancestor.parent || node;
        ctx.body = { uri: '/' + visible.vfsPath };
    }
    function* explicitNodes(parent) {
        for (const child of parent.children || []) {
            const evaluated = (0, vfs_1.applyParentToChild)(child, parent);
            yield evaluated;
            yield* explicitNodes(evaluated);
        }
    }
}
function hasRules(node, keys) {
    return Boolean(node.children?.length || Object.values(node.masks || {}).some(mods => mods && (Array.from(keys).some(key => mods[key] !== undefined) || hasRules(mods, keys))));
}
