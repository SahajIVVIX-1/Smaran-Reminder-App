"use strict";
// This file is part of HFS - Copyright 2021, Massimo Melina <a@rejetto.com> - License https://www.gnu.org/licenses/gpl-3.0.txt
Object.defineProperty(exports, "__esModule", { value: true });
exports.trackIpsMw = exports.ips = void 0;
const config_1 = require("./config");
const kvstorage_1 = require("@rejetto/kvstorage");
const misc_1 = require("./misc");
const first_1 = require("./first");
const trackIps = (0, config_1.defineConfig)(misc_1.CFG.track_ips, true);
exports.ips = new kvstorage_1.KvStorage({
    defaultPutDelay: misc_1.MINUTE,
    maxPutDelay: 10 * misc_1.MINUTE,
    maxPutDelayCreate: 0,
});
(0, first_1.onProcessExit)(() => exports.ips.close());
const trackIpsMw = async (ctx, next) => {
    const tracking = exports.ips.isOpen() && !(0, misc_1.isLocalHost)(ctx);
    const ts = new Date;
    const country = ctx.state.connection.country;
    let failed = false;
    // defer storage update until downstream middlewares have assigned status or thrown
    try {
        await next();
    }
    catch (e) {
        failed = true;
        throw e;
    }
    finally {
        if (tracking) {
            // keep the counter update here so failures from downstream middlewares are counted with the final status
            const was = exports.ips.getSync(ctx.ip);
            void exports.ips.put(ctx.ip, {
                ts,
                country,
                served: (was?.served || 0) + (failed || ctx.status >= 400 ? 0 : 1),
                failed: (was?.failed || 0) + (failed || ctx.status >= 400 ? 1 : 0),
            }).catch(e => console.error("Couldn't track IP", ctx.ip, String(e)));
        }
    }
};
exports.trackIpsMw = trackIpsMw;
trackIps.sub(v => {
    if (v)
        exports.ips.open('ips.kv');
    else
        exports.ips.close();
});
