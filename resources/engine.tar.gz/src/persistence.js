"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.storedMap = void 0;
const kvstorage_1 = require("@rejetto/kvstorage");
const misc_1 = require("./misc");
const first_1 = require("./first");
const fast_glob_1 = __importDefault(require("fast-glob"));
const promises_1 = require("fs/promises");
exports.storedMap = new kvstorage_1.KvStorage({
    defaultPutDelay: 5000,
    maxPutDelay: misc_1.MINUTE,
    maxPutDelayCreate: 1000,
    rewriteLater: true,
    bucketThreshold: 10_000,
});
exports.storedMap.open('data.kv').catch(e => {
    console.error("Persistence won't work correctly", e);
}).finally(async () => {
    for (const x of await (0, fast_glob_1.default)('*.kv.lock')) // legacy pre 3.0.5
        (0, promises_1.unlink)(x).catch(() => { });
});
(0, first_1.onProcessExit)(() => exports.storedMap.close());
