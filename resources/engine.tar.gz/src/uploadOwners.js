"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.uploadOwners = exports.ownUploadDeleteHours = void 0;
exports.grantUploadOwnerDelete = grantUploadOwnerDelete;
exports.isUnfinishedUploadOwner = isUnfinishedUploadOwner;
exports.setUploadOwner = setUploadOwner;
exports.moveUploadOwner = moveUploadOwner;
exports.getNodeMatchingSource = getNodeMatchingSource;
exports.deleteUploadOwner = deleteUploadOwner;
exports.getSessionId = getSessionId;
const kvstorage_1 = require("@rejetto/kvstorage");
const misc_1 = require("./misc");
const first_1 = require("./first");
const config_1 = require("./config");
const auth_1 = require("./auth");
const events_1 = __importDefault(require("./events"));
const vfs_1 = require("./vfs");
exports.ownUploadDeleteHours = (0, config_1.defineConfig)(misc_1.CFG.own_upload_delete_hours, 24);
exports.uploadOwners = new kvstorage_1.KvStorage({
    rewriteLater: true,
});
exports.uploadOwners.open('upload-owners.kv').catch(e => console.error("Upload owners won't work correctly", e));
(0, first_1.onProcessExit)(() => exports.uploadOwners.close());
setInterval(() => {
    if (!exports.uploadOwners.isOpen())
        return;
    const keys = Array.from(exports.uploadOwners.keys());
    for (const k of keys) {
        const owner = exports.uploadOwners.getSync(k);
        if (owner && isRecordExpired(owner))
            void exports.uploadOwners.del(k);
    }
}, misc_1.MINUTE);
events_1.default.on('checkVfsPermission', grantUploadOwnerDelete);
function grantUploadOwnerDelete({ node, perm, ctx }) {
    if (perm !== 'can_delete' || !node.source)
        return;
    const { vfsPath } = node;
    if (!vfsPath || !exports.ownUploadDeleteHours.get() || !exports.uploadOwners.isOpen())
        return;
    const owner = exports.uploadOwners.getSync(cleanVfsPath(vfsPath));
    if (!owner)
        return;
    if (isExpired(owner)) {
        if (isRecordExpired(owner))
            void deleteUploadOwner(vfsPath);
        return;
    }
    if (matchesOwner(owner, ctx))
        return 0;
}
function matchesOwner(owner, ctx) {
    const username = (0, auth_1.getCurrentUsername)(ctx);
    const { sessionId } = owner;
    return Boolean(sessionId && sessionId === ctx.session?.sessionId || username && owner.username === username);
}
function isUnfinishedUploadOwner(node, ctx) {
    if (node.original || !node.vfsPath || !exports.uploadOwners.isOpen())
        return false;
    const owner = exports.uploadOwners.getSync(cleanVfsPath(node.vfsPath));
    return Boolean(owner && owner.unfinishedUntil !== undefined && !isRecordExpired(owner) && matchesOwner(owner, ctx));
}
async function setUploadOwner(vfsPath, ctx, expectedSource, unfinishedUntil) {
    if (!exports.uploadOwners.isOpen() || unfinishedUntil === undefined && !exports.ownUploadDeleteHours.get())
        return;
    if (expectedSource && !await getNodeMatchingSource(vfsPath, ctx, expectedSource))
        return;
    const username = (0, auth_1.getCurrentUsername)(ctx) || undefined;
    return exports.uploadOwners.put(cleanVfsPath(vfsPath), {
        username,
        sessionId: username ? undefined : getSessionId(ctx),
        ip: ctx.ip,
        created: new Date(),
        unfinishedUntil,
    })?.catch(e => {
        console.error("Couldn't store upload owner for", vfsPath, String(e.message || e));
    });
}
async function moveUploadOwner(fromPath, toPath, expectedSource) {
    if (!exports.uploadOwners.isOpen())
        return;
    const from = cleanVfsPath(fromPath);
    const to = cleanVfsPath(toPath);
    const affected = Array.from(exports.uploadOwners.keys()).filter(k => isSameOrInside(from, k));
    if (expectedSource && !await getNodeMatchingSource(toPath, undefined, expectedSource)) {
        await Promise.all(affected.map(k => exports.uploadOwners.del(k)));
        return;
    }
    if (to === from)
        return;
    deleteUploadOwner(to); // overwriting with a non-uploaded file must not preserve the previous destination's delete grant
    if (!affected.length)
        return;
    const owners = affected.map(k => ({ k, owner: exports.uploadOwners.getSync(k) }));
    // ownership is keyed by VFS path, so HFS moves must carry descendant upload records too
    // an ordinary move must not carry the right to continue an upload at another path
    await Promise.all(owners.map(({ k, owner }) => owner && exports.uploadOwners.put(to + k.slice(from.length), { ...owner, unfinishedUntil: undefined })));
    await Promise.all(affected.map(k => exports.uploadOwners.del(k)));
}
async function getNodeMatchingSource(vfsPath, ctx, source) {
    const node = await (0, vfs_1.urlToNode)(vfsPath, ctx, undefined, { includeHidden: true });
    if (node?.source && await (0, vfs_1.isSameFilePath)(node.source, source))
        return node;
}
function deleteUploadOwner(vfsPath) {
    if (!exports.uploadOwners.isOpen())
        return;
    const path = cleanVfsPath(vfsPath);
    for (const k of exports.uploadOwners.keys()) // deleting a folder must clear ownership for uploaded files below it too
        if (isSameOrInside(path, k))
            void exports.uploadOwners.del(k);
}
function isExpired(owner) {
    const hours = exports.ownUploadDeleteHours.get();
    return !hours || Number(owner.created) + hours * misc_1.HOUR <= Date.now();
}
function isRecordExpired(owner) {
    return owner.unfinishedUntil === undefined ? isExpired(owner)
        : owner.unfinishedUntil !== null && owner.unfinishedUntil <= Date.now();
}
function getSessionId(ctx) {
    return ctx.session.sessionId ||= (0, misc_1.randomId)(30);
}
function cleanVfsPath(path) {
    return (0, vfs_1.normalizeFilename)((0, misc_1.pathDecodeSegments)('/' + path.replace(/^\/+|\/+$/g, ''), misc_1.pathEncode));
}
function isSameOrInside(parent, path) {
    return path === parent || path.startsWith(parent + '/');
}
