"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AsapStream = void 0;
const stream_1 = require("stream");
const cross_1 = require("./cross");
// produces as promises resolve, not sequentially
class AsapStream extends stream_1.Readable {
    promises;
    readingStarted = false;
    constructor(promises) {
        super({ objectMode: true });
        this.promises = promises;
    }
    _read() {
        if (this.readingStarted)
            return;
        this.readingStarted = true;
        // local function below has its own this
        const stream = this;
        void (async () => {
            const pending = [];
            try {
                if (!(0, cross_1.isAsyncIterable)(this.promises))
                    for (const p of this.promises)
                        track(p);
                else {
                    const iterator = this.promises[Symbol.asyncIterator]();
                    while (true) {
                        const { value, done } = await iterator.next();
                        if (done)
                            break;
                        track(value);
                    }
                }
                await Promise.allSettled(pending);
                this.push(null);
            }
            catch (e) {
                this.emit('error', e);
                this.push(null);
            }
            function track(p) {
                const promise = Promise.resolve(p);
                pending.push(promise);
                promise.then(x => {
                    if (x !== undefined)
                        stream.push(x);
                }, e => stream.emit('error', e));
            }
        })();
    }
}
exports.AsapStream = AsapStream;
