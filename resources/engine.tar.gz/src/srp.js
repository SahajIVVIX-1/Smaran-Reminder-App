"use strict";
// This file is part of HFS - Copyright 2021-2023, Massimo Melina <a@rejetto.com> - License https://www.gnu.org/licenses/gpl-3.0.txt
Object.defineProperty(exports, "__esModule", { value: true });
exports.srpClientSequence = srpClientSequence;
exports.srpClientPart = srpClientPart;
async function srpClientSequence(srp, username, password, apiCall, extra) {
    const { pubKey, salt } = await apiCall('loginSrp1', { username });
    if (!salt)
        throw Error('salt');
    const client = await srpClientPart(srp, username, password, salt, pubKey);
    const res = await apiCall('loginSrp2', { pubKey: String(client.A), proof: String(client.M1), ...extra }); // bigint-s must be cast to string to be json-ed
    await client.step3(BigInt(res.proof)).catch(() => Promise.reject('trust'));
    return res;
}
async function srpClientPart(srp, username, password, salt, pubKey) {
    const srp6aNimbusRoutines = new srp.SRPRoutines(new srp.SRPParameters());
    const srpClient = new srp.SRPClientSession(srp6aNimbusRoutines);
    const res = await srpClient.step1(username, password);
    return await res.step2(BigInt(salt), BigInt(pubKey));
}
