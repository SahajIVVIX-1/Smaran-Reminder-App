"use strict";
// This file is part of HFS - Copyright 2021-2023, Massimo Melina <a@rejetto.com> - License https://www.gnu.org/licenses/gpl-3.0.txt
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.saveVfs = exports.vfs = void 0;
exports.permsFromParent = permsFromParent;
exports.isSameFilenameAs = isSameFilenameAs;
exports.normalizeFilename = normalizeFilename;
exports.isSameFilePath = isSameFilePath;
exports.getVirtualName = getVirtualName;
exports.getChildBySource = getChildBySource;
exports.getFreeVfsName = getFreeVfsName;
exports.applyParentToChild = applyParentToChild;
exports.urlToNode = urlToNode;
exports.nodeStats = nodeStats;
exports.getNodeByName = getNodeByName;
exports.isRoot = isRoot;
exports.getNodeName = getNodeName;
exports.nodeIsFolder = nodeIsFolder;
exports.getDefaultFile = getDefaultFile;
exports.nodeIsLink = nodeIsLink;
exports.hasPermission = hasPermission;
exports.statusCodeForMissingPerm = statusCodeForMissingPerm;
exports.simpleWhoToError = simpleWhoToError;
exports.walkNode = walkNode;
exports.masksCouldGivePermission = masksCouldGivePermission;
exports.parentMaskApplier = parentMaskApplier;
exports.renameUnderPath = renameUnderPath;
const promises_1 = __importDefault(require("fs/promises"));
const path_1 = require("path");
const misc_1 = require("./misc");
const lodash_1 = __importDefault(require("lodash"));
const config_1 = require("./config");
const const_1 = require("./const");
const events_1 = __importDefault(require("./events"));
const perm_1 = require("./perm");
const auth_1 = require("./auth");
const fswin_1 = __importDefault(require("fswin"));
const comments_1 = require("./comments");
const walkDir_1 = require("./walkDir");
const node_stream_1 = require("node:stream");
const adminApis_1 = require("./adminApis");
const showHiddenFiles = (0, config_1.defineConfig)(misc_1.CFG.show_hidden_files, false);
const sourceNames = new Map();
function setVfsPath(node, vfsPath, parent) {
    return (0, misc_1.setHidden)(node, {
        vfsPath: (0, misc_1.enforceFinal)('/', parent?.vfsPath) + (0, misc_1.pathEncode)(vfsPath)
    });
}
function permsFromParent(parent, child) {
    const ret = {};
    for (const k of misc_1.PERM_KEYS) {
        let p = parent;
        let inheritedPerm;
        while (p) {
            inheritedPerm = p[k];
            // in case of object without children, parent is skipped in favor of the parent's parent
            if (!(0, misc_1.isWhoObject)(inheritedPerm))
                break;
            inheritedPerm = inheritedPerm.children;
            if (inheritedPerm !== undefined)
                break;
            p = p.parent;
        }
        if (inheritedPerm !== undefined && child[k] === undefined) // small optimization: don't expand the object
            ret[k] = inheritedPerm;
    }
    return lodash_1.default.isEmpty(ret) ? undefined : ret;
}
function inheritFromParent(child) {
    const { parent } = child;
    if (!parent)
        return;
    Object.assign(child, permsFromParent(parent, child));
    if (typeof parent.mime === 'object' && typeof child.mime === 'object')
        lodash_1.default.defaults(child.mime, parent.mime);
    else if (parent.mime)
        child.mime ??= parent.mime;
    if (parent.accept)
        child.accept ??= parent.accept;
    if (parent.default)
        child.default ??= parent.default;
    child.gui_asset ??= parent.gui_asset;
    return child;
}
function isSameFilenameAs(name) {
    const normalized = normalizeFilename(name);
    return (other) => normalized === normalizeFilename(typeof other === 'string' ? other : getNodeName(other));
}
function normalizeFilename(x) {
    return (0, misc_1.normalizeFilenameForPlatform)(x, process.platform);
}
async function isSameFilePath(a, b) {
    if (normalizeFilename((0, path_1.resolve)(a)) === normalizeFilename((0, path_1.resolve)(b)))
        return true;
    try {
        if (const_1.IS_WINDOWS) { // pkg's realpath preserves 8.3 names; expanding them here also preserves junction identity
            const [longA, longB] = await Promise.all([convertWindowsPath(a, true), convertWindowsPath(b, true)]);
            if (longA && longB && normalizeFilename((0, path_1.resolve)(longA)) === normalizeFilename((0, path_1.resolve)(longB)))
                return true;
        }
        const stats = await Promise.all([promises_1.default.lstat(a), promises_1.default.lstat(b)]);
        if (stats.some(x => x.isSymbolicLink()))
            return false;
        const [realA, realB] = await Promise.all([promises_1.default.realpath(a), promises_1.default.realpath(b)]);
        return normalizeFilename(realA) === normalizeFilename(realB);
    }
    catch {
        return false;
    }
}
// security state follows the displayed VFS identity even when I/O uses its physical alias
function getVirtualName(name, parent, source) {
    if (source) {
        const child = getChildBySource(parent, source);
        if (child)
            return getNodeName(child);
    }
    const entries = Object.entries(parent.rename || {});
    const fromSource = source && entries.find(([from]) => isSameFilenameAs((0, path_1.basename)(source))(from));
    if (fromSource)
        return fromSource[1];
    const sameName = isSameFilenameAs(name);
    return entries.find(([, to]) => sameName(to))?.[1]
        || entries.find(([from]) => sameName(from))?.[1]
        || name;
}
function getChildBySource(parent, source) {
    const normalizedSource = normalizeFilename((0, path_1.resolve)(source));
    return parent.children?.find(x => x.source
        && normalizeFilename((0, path_1.resolve)(x.source)) === normalizedSource);
}
function getFreeVfsName(siblings, name) {
    const ext = (0, path_1.extname)(name);
    const noExt = ext ? name.slice(0, -ext.length) : name;
    let idx = 2;
    while (siblings?.find(isSameFilenameAs(name)))
        name = `${noExt} ${idx++}${ext}`;
    return name;
}
function applyParentToChild(child, parent, name) {
    name ||= child ? getNodeName(child) : '';
    const ret = setVfsPath({
        original: child, // this can be overridden by passing an 'original' in `child`
        ...child,
        isFolder: child?.isFolder ?? (child?.children?.length > 0 || undefined), // isFolder is hidden in original node, so we must copy it explicitly
        isTemp: true,
        parent,
    }, name, parent);
    inheritMasks(ret, parent, name);
    parentMaskApplier(parent)(ret, name);
    inheritFromParent(ret);
    return ret;
}
async function urlToNode(url, ctx, parent = exports.vfs.compiled(), options = {}) {
    let initialSlashes = 0;
    while (url[initialSlashes] === '/')
        initialSlashes++;
    let nextSlash = url.indexOf('/', initialSlashes);
    const slice = url.slice(initialSlashes, nextSlash < 0 ? undefined : nextSlash);
    if (!slice)
        return parent;
    const name = (0, misc_1.safeDecodeURIComponent)(slice, '');
    if (!name) // failed decoding
        return;
    const hasTrailingSlash = url.endsWith('/');
    const rest = nextSlash < 0 ? '' : url.slice(nextSlash + 1, hasTrailingSlash ? -1 : undefined);
    const assumeFolder = options.allowMissing && (rest > '' || hasTrailingSlash);
    const ret = await getNodeByName(name, parent, assumeFolder);
    if (!ret)
        return;
    if (!ret.original && ret.source && !options.includeHidden && !showHiddenFiles.get() && await isHiddenFile(ret.source))
        return;
    if (rest || ret?.original)
        return urlToNode(rest, ctx, ret, options);
    if (ret.source)
        if (!options.allowMissing && await setIsFolder(ret) === undefined) // undefined = not found on disk
            return;
    return ret;
}
async function nodeStats(node) {
    if (node.stats || !node.source)
        return node.stats;
    const stats = (0, misc_1.statWithTimeout)(node.source).catch(() => {
        (0, misc_1.setHidden)(node, { stats: null }); // don't cache rejected promises
    });
    (0, misc_1.setHidden)(node, { stats });
    return stats;
}
async function isHiddenFile(path) {
    return const_1.IS_WINDOWS ? new Promise(res => fswin_1.default.getAttributes(path, x => res(x?.IS_HIDDEN)))
        : path[path.lastIndexOf('/') + 1] === '.';
}
async function getNodeByName(name, parent, assumeMissingToBeFolder = false) {
    // does the tree node have a child that goes by this name, otherwise attempt disk
    let virtualName = name;
    let child = parent.children?.find(isSameFilenameAs(name));
    const sameName = isSameFilenameAs(name);
    const sourceName = Object.entries(parent.rename || {}).find(([, to]) => sameName(to))?.[0] || name;
    if (!child) {
        child = findSourceChild();
        // a shared alias may publish comment storage only through its explicit VFS name
        if (child?.source && isCommentsFileName((0, path_1.basename)(child.source)))
            return;
        if (!child && const_1.IS_WINDOWS && parent.source) {
            const aliases = await windowsPathNames((0, path_1.join)(parent.source, sourceName), parent.source);
            if (!aliases)
                return;
            child = findSourceChild(aliases);
            if (!child) {
                const normalized = new Set(aliases.map(normalizeFilename));
                const candidates = parent.children?.filter(candidate => candidate.source
                    && normalized.has(normalizeFilename((0, path_1.basename)(candidate.source)))) || [];
                if (candidates.length > 1)
                    return; // an unverified physical alias must identify one VFS child
                const [candidate] = candidates;
                if (candidate?.source && await isSameFilePath((0, path_1.dirname)(candidate.source), parent.source))
                    child = candidate;
            }
        }
    }
    if (child) { // found as vfs node
        virtualName = getNodeName(child);
        await setIsFolder(child); // in case it's pointing to a folder that didn't exist at loading time
    }
    else
        child = await childFromDisk();
    return child && applyParentToChild(child, parent, virtualName);
    async function childFromDisk() {
        if (!parent.source)
            return;
        const ret = {};
        let onDisk = name;
        if (parent.rename) { // reverse the mapping
            const entries = Object.entries(parent.rename);
            // search display names first: with { A: B, C: A }, A must resolve to C rather than be hidden
            const asDisplayName = entries.find(([, to]) => sameName(to));
            if (asDisplayName) {
                onDisk = asDisplayName[0];
                virtualName = asDisplayName[1];
            }
            else {
                if (!await canonicalizeWindowsAlias())
                    return;
                const sameSourceName = isSameFilenameAs(onDisk);
                const asPhysicalName = entries.find(([from]) => sameSourceName(from));
                if (asPhysicalName)
                    return; // a VFS rename replaces the original public name
            }
            ret.rename = renameUnderPath(parent.rename, onDisk);
        }
        else if (!await canonicalizeWindowsAlias())
            return;
        if (!(0, misc_1.isValidFileName)(onDisk))
            return;
        ret.source = (0, path_1.join)(parent.source, onDisk);
        ret.original = undefined; // this will overwrite the 'original' set in applyParentToChild, so we know this is not part of the vfs
        await setIsFolder(ret);
        if (ret.isFolder === false && isCommentsFileName(onDisk))
            return; // implicit comment storage contains metadata for files the requester may not be allowed to see
        if (assumeMissingToBeFolder)
            ret.isFolder ??= true;
        return ret;
        async function canonicalizeWindowsAlias() {
            if (!const_1.IS_WINDOWS || !name.includes('~'))
                return true;
            // Windows exposes 8.3 aliases that must keep the long name's VFS identity
            const longPath = await convertWindowsPath((0, path_1.join)(parent.source, name), true);
            if (!longPath)
                return true; // new names containing '~' are still valid
            if (!await isSameFilePath((0, path_1.dirname)(longPath), parent.source))
                return false;
            onDisk = virtualName = (0, path_1.basename)(longPath);
            return true;
        }
    }
    function findSourceChild(names = [sourceName]) {
        const normalized = new Set(names.map(normalizeFilename));
        return parent.children?.find(x => getSourceNames(x, parent).some(source => normalized.has(normalizeFilename(source))));
    }
}
function isCommentsFileName(name) {
    return (0, comments_1.usingDescriptIon)() && [comments_1.DESCRIPT_ION, comments_1.DESCRIPT_ION_ALT].some(isSameFilenameAs(name));
}
const smartUncFolderDetection = (0, config_1.defineConfig)(misc_1.CFG.smart_unc_folder_detection, false);
async function setIsFolder(node) {
    if (!node.source)
        return;
    const isFolder = (0, misc_1.hasFinalSlash)(node.source)
        || smartUncFolderDetection.get() && (0, misc_1.getUncHost)(node.source) && !(0, path_1.basename)(node.source).includes('.') // no dot = folder; not very reliable but fast for unreachable unc hosts, and it's an opt-in
        || await nodeStats(node).then(x => x?.isDirectory(), () => undefined);
    (0, misc_1.setHidden)(node, { isFolder });
    if (isFolder)
        persistFolderMarker(node);
    return isFolder;
}
// compiled is the stable mutable tree, while get() may return a fresh clone of the default
exports.vfs = (0, config_1.defineConfig)(misc_1.CFG.vfs, {}, x => setVfsPath(structuredClone(x && typeof x === 'object' ? x : {}), '')); // ensure the type is right
exports.vfs.sub(async () => {
    await reviewVfs();
    console.log('VFS ready');
});
async function reviewVfs() {
    await (async function recur(node) {
        if (node.source && !node.children?.length && node.isFolder === undefined)
            await setIsFolder(node);
        if (!node.children)
            return;
        // we rename your node in case you got 2 nodes with the same name
        const usedNames = new Set();
        for (const child of node.children) {
            const name = getNodeName(child);
            const normalized = normalizeFilename(name);
            if (usedNames.has(normalized))
                child.name = getFreeVfsName(node.children, name);
            usedNames.add(normalizeFilename(getNodeName(child)));
        }
        await Promise.allSettled(node.children.map(recur));
        await Promise.allSettled(node.children.map(child => setSourceNames(child, node)));
    })(exports.vfs.compiled());
}
async function setSourceNames(node, parent) {
    if (!node.source || !parent.source)
        return;
    const sameParent = normalizeFilename((0, path_1.dirname)((0, path_1.resolve)(node.source))) === normalizeFilename((0, path_1.resolve)(parent.source));
    if (!sameParent && (!const_1.IS_WINDOWS || !await isSameFilePath((0, path_1.dirname)(node.source), parent.source)))
        return;
    const names = [(0, path_1.basename)(node.source)];
    const key = sourceNamesKey(node, parent);
    if (const_1.IS_WINDOWS) {
        const converted = await Promise.all([convertWindowsPath(node.source), convertWindowsPath(node.source, true)]);
        names.push(...converted.map(x => x && (0, path_1.basename)(x)).filter(Boolean));
    }
    sourceNames.set(key, lodash_1.default.uniq(names));
}
function convertWindowsPath(path, isLong = false) {
    return new Promise(resolvePromise => {
        if (!fswin_1.default.convertPath(path, converted => resolvePromise(converted || undefined), isLong))
            resolvePromise(undefined);
    });
}
async function windowsPathNames(path, parent) {
    const converted = await Promise.all([convertWindowsPath(path), convertWindowsPath(path, true)]);
    const existing = converted.find(Boolean);
    if (existing && !await isSameFilePath((0, path_1.dirname)(existing), parent))
        return;
    return lodash_1.default.uniq([(0, path_1.basename)(path), ...converted.map(x => x && (0, path_1.basename)(x)).filter(Boolean)]);
}
function getSourceNames(node, parent) {
    return node.source && parent.source ? sourceNames.get(sourceNamesKey(node, parent)) || [] : [];
}
function sourceNamesKey(node, parent) {
    return normalizeFilename((0, path_1.resolve)(parent.source)) + '\0' + normalizeFilename((0, path_1.resolve)(node.source));
}
exports.saveVfs = (0, misc_1.debounceAsync)(async () => {
    await reviewVfs(); // refresh runtime-derived folder flags before saving mutated VFS state
    exports.vfs.set(exports.vfs.compiled()); // sync the mutable runtime tree back to config state before persisting it
    (0, config_1.saveConfigAsap)();
});
function isRoot(node) {
    return node === exports.vfs.compiled();
}
function getNodeName(node) {
    if (isRoot(node))
        return '';
    if (node.name)
        return node.name;
    const { source } = node;
    if (!source)
        return ''; // shoulnd't happen
    if (source === '/')
        return 'root'; // better name than
    if (/^[a-zA-Z]:\\?$/.test(source))
        return source.slice(0, 2); // exclude trailing slash
    const base = (0, path_1.basename)(source);
    if (/^[./\\]*$/.test(base)) // if empty or special-chars-only
        return (0, path_1.basename)((0, path_1.resolve)(source)); // resolve to try to get more
    if (base.includes('\\') && !source.includes('/')) // source was Windows but now we are running posix. This probably happens only debugging, so it's DX
        return source.slice(source.lastIndexOf('\\') + 1);
    return base;
}
// this is sync
function nodeIsFolder(node) {
    return node.isFolder ?? node.original?.isFolder
        ?? (nodeIsLink(node) ? false : (node.children?.length > 0 || !node.source || reconsider()));
    function reconsider() {
        // a networked source may be offline at startup, and become online later: recalculate in the background
        nodeStats(node).then(s => {
            if (s) {
                const isFolder = s.isDirectory();
                (0, misc_1.setHidden)(node.original || node, { isFolder });
                if (isFolder)
                    persistFolderMarker(node);
            }
        }, () => { });
        return undefined;
    }
}
// we mark folder paths with a final slash – the UI already does so, but the config may be modified
function persistFolderMarker(node) {
    if ('original' in node && !node.original)
        return; // disk-derived nodes are temporary and must not persist VFS changes
    const stored = node.original || node; // temporary VFS nodes must update their stored original for saveVfs to persist the marker
    if (!stored.source || (0, misc_1.hasFinalSlash)(stored.source))
        return;
    stored.source += path_1.sep;
    void (0, exports.saveVfs)();
}
async function getDefaultFile(node, ctx) {
    return node.default && nodeIsFolder(node) && await urlToNode(node.default, ctx, node) || undefined;
}
function nodeIsLink(node) {
    return node.url;
}
function hasPermission(node, perm, ctx) {
    return !statusCodeForMissingPerm(node, perm, ctx, false);
}
function statusCodeForMissingPerm(node, perm, ctx, assign = true, checkListeners = true) {
    const ret = getCode();
    if (ret && assign) {
        ctx.status = ret;
        ctx.body = ret === const_1.HTTP_UNAUTHORIZED ? "Unauthorized" : "Forbidden";
    }
    return ret;
    function getCode() {
        if ((isRoot(node) || node.original) && perm === 'can_delete' // we currently don't allow deleting of vfs nodes from frontend
            || !node.source && perm === 'can_upload') // Upload possible only if we know where to store. First check node.source because is supposedly faster.
            return const_1.HTTP_FORBIDDEN;
        // calculate value of permission resolving references to other permissions, avoiding infinite loop
        let who;
        let max = misc_1.PERM_KEYS.length;
        let cur = perm;
        do {
            who = node[cur];
            if ((0, misc_1.isWhoObject)(who))
                who = who.this;
            who ??= misc_1.defaultPerms[cur];
            if (typeof who !== 'string' || who === misc_1.WHO_ANY_ACCOUNT || who === misc_1.WHO_ADMIN)
                break;
            if (!max--) {
                console.error(`Endless loop in permission ${perm}=${node[perm] ?? misc_1.defaultPerms[perm]} for ${node.url || getNodeName(node)}`);
                return misc_1.HTTP_SERVER_ERROR;
            }
            cur = who;
        } while (1);
        if ((0, misc_1.isWhoObject)(who) || isWhoVfsPerms(who))
            throw Error(`permission type-guard: ${JSON.stringify(who)}`);
        const first = checkListeners ? lodash_1.default.max(events_1.default.emit('checkVfsPermission', { who, node, perm, ctx })) : undefined;
        if (first !== undefined)
            return first;
        return simpleWhoToError(who, ctx)
            ?? (0, misc_1.throw_)(Error(`invalid permission: ${perm}=${(0, misc_1.try_)(() => JSON.stringify(who))}`));
    }
}
function simpleWhoToError(who, ctx) {
    if (Array.isArray(who))
        return (0, perm_1.ctxBelongsTo)(ctx, who) ? 0 : const_1.HTTP_UNAUTHORIZED;
    return typeof who === 'boolean' ? (who ? 0 : const_1.HTTP_FORBIDDEN)
        : who === misc_1.WHO_ANY_ACCOUNT ? ((0, auth_1.getCurrentUsername)(ctx) ? 0 : const_1.HTTP_UNAUTHORIZED)
            : who === misc_1.WHO_ADMIN ? ((0, adminApis_1.ctxAdminAccess)(ctx) ? 0 : const_1.HTTP_UNAUTHORIZED)
                : undefined;
}
function isWhoVfsPerms(who) {
    return typeof who === 'string' && misc_1.PERM_KEYS.includes(who);
}
// it's the responsibility of the caller to verify you have list permission on parent, as callers have different needs.
async function* walkNode(parent, { ctx, depth = Infinity, prefixPath = '', requiredPerm, onlyFolders = false, onlyFiles = false, parallelizeRecursion = true, } = {}) {
    let started = false;
    const stream = new node_stream_1.Readable({
        objectMode: true,
        async read() {
            if (started)
                return; // for simplicity, we care about starting, and never suspend
            started = true;
            const { source } = parent;
            const taken = new Set();
            const takenSources = new Set();
            const visitLater = [];
            const childrenWorking = parent.children?.length && Promise.all(parent.children.map(async (child) => {
                if (ctx?.isAborted())
                    return;
                const nodeName = getNodeName(child);
                const name = prefixPath + nodeName;
                taken.add(normalizeFilename(name));
                for (const sourceName of getSourceNames(child, parent))
                    takenSources.add(normalizeFilename(prefixPath + sourceName));
                const item = setVfsPath({ ...child, original: child, name, parent }, name, parent);
                if (await cantSee(item, parent, nodeName))
                    return;
                if (item.source && !item.children?.length && !item.see_without_probing) // real items must be accessible, unless probing was explicitly disabled
                    try {
                        await promises_1.default.access(item.source);
                    }
                    catch {
                        return;
                    }
                const isFolder = nodeIsFolder(child);
                if (canEmit(item, isFolder))
                    stream.push(item);
                if (!depth || !isFolder || cantRecur(item))
                    return;
                visitLater.push([item, name]); // prioritize siblings
            }));
            try {
                if (!source)
                    return;
                if (requiredPerm && ctx // no permission, no reason to continue (at least for dynamic elements)
                    && !hasPermission(parent, requiredPerm, ctx)
                    && !masksCouldGivePermission(parent.masks, requiredPerm))
                    return;
                const diskFolders = new Map();
                diskFolders.set('', { node: parent, virtualPath: '' });
                const applyPathMask = parentMaskApplier(parent, true, true);
                const applyRootNameMask = parentMaskApplier(parent, false, true);
                try {
                    await (0, walkDir_1.walkDir)(source, { depth, ctx, hidden: showHiddenFiles.get(), parallelizeRecursion }, async (entry) => {
                        if (ctx?.isAborted())
                            return null;
                        const { path } = entry; // this path is not the original deprecated property: we are overwriting/reusing it
                        const isFolder = entry.isDirectory();
                        if (!isFolder && isCommentsFileName(entry.name))
                            return;
                        const parentPath = (0, path_1.dirname)(path) === '.' ? '' : (0, path_1.dirname)(path);
                        const evaluatedParent = diskFolders.get(parentPath);
                        if (!evaluatedParent)
                            return false;
                        const physicalName = (0, path_1.basename)(path);
                        const virtualName = evaluatedParent.node.rename?.[physicalName] || physicalName;
                        const virtualPath = evaluatedParent.virtualPath
                            ? evaluatedParent.virtualPath + '/' + virtualName
                            : virtualName;
                        const name = prefixPath + virtualPath;
                        if (taken.has(normalizeFilename(name))
                            || takenSources.has(normalizeFilename(prefixPath + path))) // taken by vfs node above
                            return false; // false just in case it's a folder
                        const item = setVfsPath({
                            name: virtualName,
                            isFolder,
                            source: (0, path_1.join)(source, path),
                            parent: evaluatedParent.node,
                            rename: renameUnderPath(evaluatedParent.node.rename, physicalName),
                            stats: entry.stats,
                        }, virtualName, evaluatedParent.node);
                        const rootMaskProperties = { isFolder };
                        const exceptions = applyPathMask(rootMaskProperties, virtualPath);
                        for (const key of applyRootNameMask(rootMaskProperties, virtualName))
                            exceptions.add(key);
                        for (const key of exceptions)
                            if (!(key in rootMaskProperties))
                                rootMaskProperties[key] = parent[key];
                        if (await cantSee(item, evaluatedParent.node, virtualName, rootMaskProperties)) // can't see: don't produce and don't recur
                            return false;
                        if (isFolder)
                            diskFolders.set(path, { node: item, virtualPath });
                        item.name = name;
                        if (canEmit(item, isFolder))
                            stream.push(item);
                        if (cantRecur(item))
                            return false;
                    });
                }
                catch (e) {
                    console.debug('walkNode', source, String(e)); // ENOTDIR, or lacking permissions
                }
            }
            finally {
                await childrenWorking;
                for (const [item, name] of visitLater)
                    for await (const x of walkNode(item, { depth: depth - 1, prefixPath: name + '/', ctx, requiredPerm, onlyFolders, onlyFiles, parallelizeRecursion })) {
                        if (ctx?.isAborted())
                            return stream.push(null);
                        stream.push(x);
                    }
                stream.push(null);
            }
            function cantRecur(item) {
                return ctx && !hasPermission(item, 'can_list', ctx);
            }
            function canEmit(item, isFolder) {
                return !(requiredPerm && ctx && !hasPermission(item, requiredPerm, ctx))
                    && (onlyFiles ? !isFolder : (!onlyFolders || isFolder));
            }
            // item will be changed, so be sure to pass a temp node
            async function cantSee(item, itemParent, virtualName, pathPermissions) {
                inheritMasks(item, itemParent, virtualName);
                await parentMaskApplier(itemParent)(item, virtualName);
                inheritFromParent(item);
                Object.assign(item, pathPermissions);
                if (ctx && !hasPermission(item, 'can_see', ctx))
                    return true;
                item.isTemp = true;
            }
        }
    });
    // must use a stream to be able to work with the callback-based mechanism of walkDir, but Readable is not typed so we wrap it with a generator
    for await (const item of stream) {
        if (ctx?.isAborted())
            return;
        yield item;
    }
}
function masksCouldGivePermission(masks, perm) {
    return masks !== undefined && Object.values(masks).some(props => props[perm] || masksCouldGivePermission(props.masks, perm));
}
function parentMaskApplier(parent, pathBased = false, trackExceptions = false) {
    // rules are met in the parent.masks object from nearest to farthest, but since we finally apply with _.defaults, the nearest has precedence in the final result
    const matchers = (0, misc_1.onlyTruthy)(lodash_1.default.map(parent.masks, (mods, mask) => {
        if (!mods)
            return;
        const mustBeFolder = (() => {
            if (mask.at(-1) !== '|')
                return; // parse special flag syntax as suffix |FLAG| inside the key. This allows specifying different flags with the same mask using separate keys. To avoid syntax conflicts with the rest of the file-mask, we look for an ending pipe, as it has no practical use. Ending-pipe was preferred over starting-pipe to leave the rest of the logic (inheritMasks) untouched.
            const i = mask.lastIndexOf('|', mask.length - 2);
            if (i < 0)
                return;
            const type = mask.slice(i + 1, -1);
            mask = mask.slice(0, i); // remove
            return type === 'folders';
        })();
        if (pathBased) {
            if (!mask.includes('/'))
                return;
        }
        else {
            const m = /^(!?)\*\*\//.exec(mask); // ** globstar matches also zero subfolders, so this mask must be applied here too
            mask = m ? m[1] + mask.slice(m[0].length) : !mask.includes('/') ? mask : '';
            if (!mask)
                return;
        }
        return mask && {
            matcher: (0, misc_1.makeMatcher)(mask),
            exceptionMatcher: trackExceptions && mask.startsWith('!') ? (0, misc_1.makeMatcher)(mask.slice(1)) : undefined,
            mods,
            mustBeFolder,
        };
    }));
    return (item, virtualName = (pathBased ? lodash_1.default.identity : path_1.basename)(getNodeName(item))) => {
        // depth traversal passes full relative paths, while node traversal still matches only basenames
        const exceptions = new Set();
        let isFolder = undefined;
        for (const { matcher, exceptionMatcher, mods, mustBeFolder } of matchers) {
            if (mustBeFolder !== undefined) {
                isFolder ??= nodeIsFolder(item);
                if (mustBeFolder !== isFolder)
                    continue;
            }
            if (!matcher(virtualName)) {
                if (exceptionMatcher?.(virtualName))
                    for (const key of misc_1.PERM_KEYS)
                        if (mods[key] !== undefined && !(key in item))
                            exceptions.add(key);
                continue;
            }
            item.masks &&= lodash_1.default.merge(lodash_1.default.cloneDeep(mods.masks), item.masks); // item.masks must take precedence
            lodash_1.default.defaults(item, mods);
        }
        return exceptions;
    };
}
// propagates masks, don't apply
function inheritMasks(item, parent, virtualBasename = getNodeName(item)) {
    const { masks } = parent;
    if (!masks)
        return;
    const o = {};
    for (const [k, v] of Object.entries(masks)) {
        if (/^!?\*\*/.test(k)) {
            o[k] = v;
            continue;
        }
        const i = k.indexOf('/');
        if (i < 0)
            continue;
        if (!(0, misc_1.matches)(virtualBasename, k.slice(0, i)))
            continue;
        o[k.slice(i + 1)] = v;
    }
    if (Object.keys(o).length)
        item.masks = Object.assign(o, item.masks); // don't change item.masks object as it is the same object of item.original
}
function renameUnderPath(rename, path) {
    if (!rename)
        return rename;
    const sameName = isSameFilenameAs(path);
    rename = Object.fromEntries(Object.entries(rename).map(([k, v]) => {
        const i = k.indexOf('/');
        return [i >= 0 && sameName(k.slice(0, i)) ? k.slice(i + 1) : '', v];
    }));
    delete rename[''];
    return lodash_1.default.isEmpty(rename) ? undefined : rename;
}
events_1.default.on('accountRenamed', ({ from, to }) => {
    ;
    (function renameInNode(n) {
        for (const k of misc_1.PERM_KEYS)
            renameInPerm(n[k]);
        if (n.masks)
            Object.values(n.masks).forEach(renameInNode);
        n.children?.forEach(renameInNode);
    })(exports.vfs.compiled());
    (0, exports.saveVfs)();
    function renameInPerm(a) {
        if ((0, misc_1.isWhoObject)(a)) {
            renameInPerm(a.this);
            renameInPerm(a.children);
            return;
        }
        if (Array.isArray(a))
            for (let i = 0; i < a.length; i++)
                if (a[i] === from)
                    a[i] = to;
    }
});
