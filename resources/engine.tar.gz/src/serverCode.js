"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SERVER_CODE_SPLIT = void 0;
exports.parseServerCode = parseServerCode;
const lodash_1 = __importDefault(require("lodash"));
const cross_1 = require("./cross");
exports.SERVER_CODE_SPLIT = '//---';
function parseServerCode(text) {
    const split = text.split(new RegExp('(?:^|\n)' + lodash_1.default.escapeRegExp(exports.SERVER_CODE_SPLIT), 'g'));
    const ret = [];
    let first = true;
    for (const part of split)
        if (first) { // first is special, no name
            first = false;
            const code = part.trim();
            if (code)
                ret.push({ name: '', code });
        }
        else {
            const [name, code] = (0, cross_1.splitAt)('\n', part);
            ret.push({ name, code });
        }
    return ret;
}
