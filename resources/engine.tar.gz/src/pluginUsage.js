"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const node_crypto_1 = require("node:crypto");
const misc_1 = require("./misc");
const config_1 = require("./config");
const plugins_1 = require("./plugins");
const persistence_1 = require("./persistence");
const util_http_1 = require("./util-http");
const debounceAsync_1 = require("./debounceAsync");
const shareUsageStats = (0, config_1.defineConfig)(misc_1.CFG.share_usage_stats, false);
const installationId = persistence_1.storedMap.singleSync('pluginUsageId', '');
const lastReport = persistence_1.storedMap.singleSync('lastPluginUsageReport', 0);
const ready = Promise.all([config_1.configReady, plugins_1.pluginsScanned, installationId.ready(), lastReport.ready()]);
const syncPluginUsage = (0, debounceAsync_1.debounceAsync)(async () => {
    await ready;
    let uuid = installationId.get();
    if (!shareUsageStats.get()) {
        if (!uuid)
            return;
        await send('DELETE', { uuid });
        installationId.set('');
        lastReport.set(0);
        return;
    }
    if (Date.now() < lastReport.get() + misc_1.DAY)
        return;
    if (!uuid) {
        uuid = (0, node_crypto_1.randomUUID)();
        installationId.set(uuid);
    }
    const enabled = plugins_1.enablePlugins.get();
    const plugins = selectReportedPlugins([
        ...(0, plugins_1.mapPlugins)((plugin, id) => ({ ...plugin.getData(), id, enabled: enabled.includes(id) }), false),
        ...(0, plugins_1.getInactivePlugins)().map(plugin => ({ ...plugin, enabled: enabled.includes(plugin.id) })),
    ]);
    await send('POST', { uuid, hfsVersion: String(config_1.currentVersion), plugins });
    lastReport.set(Date.now());
    function selectReportedPlugins(installed) {
        const selected = new Map();
        for (const plugin of installed) {
            const repo = typeof plugin.repo === 'string' ? plugin.repo : plugin.repo?.main;
            if (!repo)
                continue;
            const current = selected.get(repo);
            if (!current || better(plugin, current))
                selected.set(repo, plugin);
        }
        return Array.from(selected, ([repo, plugin]) => ({
            repo,
            version: plugin.version,
            enabled: plugin.enabled,
        })).sort((a, b) => a.repo.localeCompare(b.repo));
        function better(a, b) {
            return Number(a.enabled) > Number(b.enabled)
                || a.enabled === b.enabled && (a.id.length < b.id.length
                    || a.id.length === b.id.length && a.id.localeCompare(b.id) < 0);
        }
    }
});
shareUsageStats.sub(() => void syncPluginUsage().catch(() => { }));
(0, misc_1.repeat)(misc_1.HOUR, syncPluginUsage);
async function send(method, body) {
    await (0, util_http_1.httpWithBody)(misc_1.PLUGIN_USAGE_URL + '/report', { method, body, timeout: 5000 });
}
