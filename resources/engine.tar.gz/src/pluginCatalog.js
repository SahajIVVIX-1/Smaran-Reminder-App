"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPluginCatalog = getPluginCatalog;
exports.searchPluginCatalog = searchPluginCatalog;
const github_1 = require("./github");
const persistence_1 = require("./persistence");
const const_1 = require("./const");
const lodash_1 = __importDefault(require("lodash"));
const CACHE_KEY = 'pluginCatalog';
let refreshing;
async function* getPluginCatalog() {
    await persistence_1.storedMap.ready();
    const saved = await persistence_1.storedMap.get(CACHE_KEY);
    // compatibility is determined by this HFS version, including fallback api branches
    const previous = saved?.version === const_1.VERSION ? saved : undefined;
    const age = previous ? Date.now() - previous.updatedAt : Infinity;
    if (previous && age < 24 * 60 * 60_000)
        yield { ...previous, refreshing: age >= 5 * 60_000 };
    if (age < 5 * 60_000)
        return;
    // all searches share the same refresh, even if the initiating client disconnects
    refreshing ??= refresh().finally(() => { refreshing = undefined; });
    yield { ...await refreshing, refreshing: false };
    async function refresh() {
        const repositories = [];
        for await (const repo of (0, github_1.apiGithubPaginated)('search/repositories?q=topic:hfs-plugin', { requireComplete: true }))
            repositories.push(lodash_1.default.pick(repo, ['full_name', 'description', 'pushed_at', 'default_branch', 'stargazers_count', 'license']));
        const old = new Map(previous?.entries.map(entry => [entry.repository.full_name, entry]));
        const entries = await Promise.all(repositories.map(async (repository) => {
            const cached = old.get(repository.full_name);
            let plugin = cached?.plugin;
            if (!cached || cached.repository.pushed_at !== repository.pushed_at
                || cached.repository.default_branch !== repository.default_branch) {
                plugin = await (0, github_1.readOnlineCompatiblePlugin)(repository.full_name, repository.default_branch)
                    .catch((error) => {
                    // repositories can carry the topic without providing a plugin at the expected path
                    if (error.message !== '404')
                        throw error;
                }) ?? null;
            }
            return { repository, plugin: plugin ?? null };
        }));
        const next = { version: const_1.VERSION, updatedAt: Date.now(), entries };
        // never replace a complete catalog with the result of a failed refresh
        await persistence_1.storedMap.put(CACHE_KEY, next);
        return next;
    }
}
async function searchPluginCatalog(catalog, text = '', skipRepos = []) {
    const central = await (0, github_1.getProjectInfo)();
    const terms = text.toLowerCase().split(/\s+/).filter(Boolean);
    return catalog.entries.flatMap(({ repository, plugin }) => {
        const repo = repository.full_name;
        const searchable = `${repo} ${repository.description || ''} ${plugin?.description || ''}`.toLowerCase();
        if (!plugin || skipRepos.includes(repo) || central?.repo_blacklist?.[repo]?.message
            || !terms.every(term => searchable.includes(term)))
            return [];
        // API responses add live state and dependency errors; keep the persisted metadata untouched
        return [{ ...plugin, id: repo, repo, pushed_at: repository.pushed_at,
                stargazers_count: repository.stargazers_count, default_branch: repository.default_branch,
                license: repository.license?.spdx_id }];
    });
}
