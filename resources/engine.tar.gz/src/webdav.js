"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.webdav = void 0;
exports.releaseWebdavLock = releaseWebdavLock;
exports.isWebdavLocked = isWebdavLocked;
const util_http_1 = require("./util-http");
const vfs_1 = require("./vfs");
const cross_1 = require("./cross");
const stream_1 = require("stream");
const promises_1 = require("fs/promises");
const http_1 = require("http");
const misc_1 = require("./misc");
const path_1 = require("path");
const frontEndApis_1 = require("./frontEndApis");
const node_crypto_1 = require("node:crypto");
const const_1 = require("./const");
const fswin_1 = __importDefault(require("fswin"));
const child_process_1 = require("child_process");
const auth_1 = require("./auth");
const config_1 = require("./config");
const expiringCache_1 = require("./expiringCache");
const fast_xml_parser_1 = require("fast-xml-parser");
const lodash_1 = __importDefault(require("lodash"));
const fileAttr_1 = require("./fileAttr");
const uploadOwners_1 = require("./uploadOwners");
const forceWebdavLogin = (0, config_1.defineConfig)(cross_1.CFG.force_webdav_login, true, compileWebdavAgentRegex);
const webdavInitialAuth = (0, config_1.defineConfig)(cross_1.CFG.webdav_initial_auth, 'WebDAVFS', compileWebdavAgentRegex);
const webdavPrompted = (0, expiringCache_1.expiringCache)(cross_1.DAY);
const webdavDetectedAgents = (0, expiringCache_1.expiringCache)(cross_1.DAY);
const TOKEN_HEADER = 'lock-token';
const WEBDAV_METHODS = new Set(['PROPFIND', 'PROPPATCH', 'MKCOL', 'MOVE', 'LOCK', 'UNLOCK']);
const WEBDAV_HINT_HEADERS = ['depth', 'destination', 'overwrite', 'translate', 'if', TOKEN_HEADER, 'x-expected-entity-length'];
const KNOWN_UA = /webdav|miniredir|davclnt|microsoft office|ms-office/i;
const LOCK_DEFAULT_SECONDS = 3600;
const LOCK_MAX_SECONDS = cross_1.DAY / 1000;
const xmlParser = new fast_xml_parser_1.XMLParser({ ignoreAttributes: false, removeNSPrefix: true, trimValues: true, parseTagValue: false }); // don't parse values, to preserve leading zeros so Windows file attributes are recognized as hexadecimal
const PROPPATCH_PROTECTED_LIVE_PROPS = new Set([
    'creationdate', 'displayname', 'getcontentlanguage', 'getcontentlength', 'getcontenttype',
    'getetag', 'getlastmodified', 'lockdiscovery', 'resourcetype', 'supportedlock',
]);
const PROPPATCH_UTIME_PROPS = new Set(['win32lastmodifiedtime', 'win32lastaccesstime']);
const WINDOWS_FILE_ATTRIBUTE_FLAGS = {
    IS_READ_ONLY: 0x1,
    IS_HIDDEN: 0x2,
    IS_SYSTEM: 0x4,
    IS_ARCHIVED: 0x20,
    IS_TEMPORARY: 0x100,
    IS_OFFLINE: 0x1000,
    IS_NOT_CONTENT_INDEXED: 0x2000,
};
const canOverwrite = new Set();
// WebDAV and frontend mutations share files, so both must observe the same exclusive locks
const locks = new Map();
function webdavPathKey(path) {
    const key = (0, cross_1.pathEncode)((0, cross_1.safeDecodeURIComponent)(path, ''));
    return (0, misc_1.hasDirTraversal)(key) ? '' : key;
}
function webdavStateKey(path) {
    const key = (0, vfs_1.normalizeFilename)((0, cross_1.safeDecodeURIComponent)(path, ''));
    return (0, misc_1.hasDirTraversal)(key) ? '' : key;
}
function webdavOverwriteKey(path, ctx, ensureSession = false) {
    const identity = (0, auth_1.getCurrentUsername)(ctx) || ctx.session?.sessionId || ensureSession && (0, uploadOwners_1.getSessionId)(ctx);
    return identity ? webdavStateKey(path) + '|' + identity : undefined;
}
function getWebdavLock(path) {
    return locks.get(webdavStateKey(path));
}
function setWebdavLock(path, lock) {
    locks.set(webdavStateKey(path), lock);
}
function releaseWebdavLock(path) {
    const key = webdavStateKey(path);
    const lock = locks.get(key);
    if (!lock)
        return false;
    clearTimeout(lock.timeout);
    locks.delete(key);
    return true;
}
function isWebdavLocked(path, ctx) {
    const lock = getWebdavLock(path);
    if (!lock)
        return false;
    const validToken = lock.username === ((0, auth_1.getCurrentUsername)(ctx) || '')
        && [ctx.get('If'), ctx.get(TOKEN_HEADER)].some(header => header.includes(`<${lock.token}>`) || header.split(/[,;\s]+/).includes(lock.token));
    if (validToken)
        return false;
    ctx.status = cross_1.HTTP_LOCKED;
    return true;
}
async function resolveWebdavResource(path, ctx) {
    const pathKey = webdavPathKey(path);
    const node = await (0, vfs_1.urlToNode)(pathKey, ctx);
    if (node)
        return { key: node.vfsPath, node };
    const parent = await (0, vfs_1.urlToNode)((0, path_1.dirname)(pathKey), ctx);
    const name = (0, cross_1.safeDecodeURIComponent)((0, path_1.basename)(pathKey), '');
    const source = parent?.source && (0, path_1.join)(parent.source, name);
    return {
        key: parent && name ? (0, cross_1.join)(parent.vfsPath, (0, cross_1.pathEncode)((0, vfs_1.getVirtualName)(name, parent, source))) : pathKey,
    };
}
async function isLocked(path, ctx, resource) {
    resource ??= await resolveWebdavResource(path, ctx);
    const { key: resourceKey, node } = resource;
    const lock = getWebdavLock(resourceKey);
    if (!lock)
        return false;
    // if the resource is gone, keeping the lock only creates fake 423 responses
    // alias callers share the key, but only the path that created the lock proves it became stale
    if (!lock.lockNull && !node && !await (0, vfs_1.urlToNode)(lock.path, ctx)) {
        releaseWebdavLock(resourceKey);
        return false;
    }
    return isWebdavLocked(resourceKey, ctx);
}
function getWebdavUsername(ctx) {
    return (0, auth_1.getCurrentUsername)(ctx) || '';
}
function isSameLockUsername(lock, ctx) {
    return lock.username === getWebdavUsername(ctx);
}
const webdav = async (ctx, next) => {
    let { path } = ctx;
    path = path.replace(/^\/+/, '/'); // double-slash is causing empty listing in filezilla-pro
    const ua = ctx.get('user-agent');
    if (path.includes('/._') && ua?.startsWith('WebDAVFS')) { // too much spam from Finder for these files that can contain metas
        ctx.state.dontLog = true;
        ctx.state.webdavDetected = true;
        return ctx.status = cross_1.HTTP_FORBIDDEN;
    }
    // office starts document access with OPTIONS, then LOCK/GET; challenging OPTIONS keeps the whole exchange in the same WebDAV auth realm
    const isCorsPreflight = ctx.method === 'OPTIONS' && ctx.get('Access-Control-Request-Method');
    const isKnownWebdavAgent = KNOWN_UA.test(ua) || webdavDetectedAgents.has(webdavAgentKey(ctx, ua));
    const isWebdavAuthRequest = !isCorsPreflight && (ctx.method === 'OPTIONS' || WEBDAV_METHODS.has(ctx.method) || WEBDAV_HINT_HEADERS.some(h => ctx.get(h))
        || ctx.state.getOrHead && isKnownWebdavAgent);
    if (isWebdavAuthRequest)
        ctx.state.webdavDetected = true;
    if (isWebdavAuthRequest && ua && (0, auth_1.getCurrentUsername)(ctx))
        webdavDetectedAgents.try(webdavAgentKey(ctx, ua), () => true);
    if (isCorsPreflight)
        return next();
    const pathKey = webdavPathKey(path); // state must converge for equivalent encodings without changing client-visible paths
    if (!pathKey && (isWebdavAuthRequest || ctx.method === 'PUT' || ctx.method === 'DELETE'))
        return ctx.status = cross_1.HTTP_BAD_REQUEST;
    if (isWebdavAuthRequest && shouldChallengeWebdav())
        return;
    if (ctx.method === 'OPTIONS')
        return handleOptions();
    if (ctx.state.getOrHead && isWebdavAuthRequest)
        return handleGet();
    switch (ctx.method) {
        case 'PUT': return handlePut();
        case 'MKCOL': return handleMkcol();
        case 'MOVE': return handleMove();
        case 'DELETE': return handleDelete();
        case 'UNLOCK': return handleUnlock();
        case 'LOCK': return handleLock();
        case 'PROPFIND': return handlePropfind();
        case 'PROPPATCH': return handleProppatch();
    }
    return next();
    async function handleOptions() {
        setWebdavHeaders();
        ctx.body = '';
    }
    async function handleGet() {
        const node = await (0, vfs_1.urlToNode)(path, ctx);
        if (!node || (0, vfs_1.nodeIsFolder)(node))
            return next();
        // webdav file reads must not fall through to the browser frontend when auth rejects them
        if ((0, vfs_1.statusCodeForMissingPerm)(node, 'can_read', ctx)) {
            if (ctx.status === cross_1.HTTP_UNAUTHORIZED)
                setWebdavHeaders(true);
            return;
        }
        return next();
    }
    async function handlePut() {
        const resource = await resolveWebdavResource(pathKey, ctx);
        const resourceKey = resource.key;
        if (await isLocked(resourceKey, ctx, resource))
            return;
        const overwriteGraceKey = webdavOverwriteKey(resourceKey, ctx);
        // Finder first creates an empty file (a test?) then wants to overwrite it, which requires deletion permission, but the user may not have it, causing a renamed upload. To solve, so we give it special permission for a few seconds.
        const x = ctx.get('x-expected-entity-length'); // field used by Finder's webdav on actual upload, after
        if (isKnownWebdavAgent && overwriteGraceKey && canOverwrite.has(overwriteGraceKey)) {
            canOverwrite.delete(overwriteGraceKey);
            const node = await (0, vfs_1.urlToNode)(resourceKey, ctx);
            if (node?.source)
                await (0, promises_1.rm)(node.source)
                    .then(() => (0, fileAttr_1.deleteStoredFileAttrs)(node.source))
                    .then(() => (0, uploadOwners_1.deleteUploadOwner)(node.vfsPath))
                    .catch(() => { });
        }
        if (x && ctx.length === undefined) // missing length can make PUT fail
            ctx.req.headers['content-length'] = x;
        if (isKnownWebdavAgent)
            ctx.query.existing ??= 'overwrite'; // with webdav this is our default
        await next();
        // the upload response URI may differ from the file it actually created when VFS aliases collide
        if (isKnownWebdavAgent && ctx.body?.uri && ctx.state.uploadDestinationPath) {
            const node = await (0, uploadOwners_1.getNodeMatchingSource)(ctx.body.uri, ctx, ctx.state.uploadDestinationPath);
            if (node) {
                const key = webdavOverwriteKey(node.vfsPath, ctx, true);
                if (key)
                    allowWebdavOverwrite(key);
            }
        }
    }
    async function handleMkcol() {
        setWebdavHeaders();
        const resource = await resolveWebdavResource(pathKey, ctx);
        if (await isLocked(path, ctx, resource))
            return;
        const { node } = resource;
        if (node) {
            ctx.status = cross_1.HTTP_METHOD_NOT_ALLOWED;
            return;
        }
        const parentNode = await (0, vfs_1.urlToNode)((0, path_1.dirname)(pathKey), ctx);
        if (!parentNode) // this is a bit incoherent with the way we handle PUT, which doesn't stop in this case, but it's by RFC 4918 section 9.3
            return ctx.status = cross_1.HTTP_CONFLICT;
        const name = (0, cross_1.safeDecodeURIComponent)((0, path_1.basename)(pathKey), '');
        if (!(0, misc_1.isValidFileName)(name))
            return ctx.status = cross_1.HTTP_BAD_REQUEST;
        if ((0, vfs_1.statusCodeForMissingPerm)(parentNode, 'can_upload', ctx)) {
            if (ctx.status === cross_1.HTTP_UNAUTHORIZED)
                setWebdavHeaders(true);
            return;
        }
        try {
            await (0, promises_1.mkdir)((0, path_1.join)(parentNode.source, name));
            return ctx.status = cross_1.HTTP_CREATED;
        }
        catch (e) {
            return ctx.status = cross_1.HTTP_SERVER_ERROR;
        }
    }
    async function handleMove() {
        setWebdavHeaders();
        const resource = await resolveWebdavResource(pathKey, ctx);
        const { node } = resource;
        if (await isLocked(path, ctx, resource))
            return;
        if (!node)
            return next();
        let dest = ctx.get('destination');
        const i = dest.indexOf('//');
        if (i >= 0)
            dest = dest.slice(dest.indexOf('/', i + 2));
        dest = webdavPathKey((0, cross_1.join)(ctx.state.root || '', dest)); // on Windows, we must use / as the delimiter to compare URL paths
        if (!dest)
            return ctx.status = cross_1.HTTP_BAD_REQUEST;
        if (await isLocked(dest, ctx))
            return;
        const destParent = await (0, vfs_1.urlToNode)((0, path_1.dirname)(dest), ctx);
        if (node.parent && destParent
            && webdavStateKey(destParent.vfsPath) === webdavStateKey(node.parent.vfsPath))
            try {
                // decode the single path segment so reserved chars like %2C become their real name on rename
                await (0, frontEndApis_1.requestedRename)(node, (0, cross_1.safeDecodeURIComponent)((0, path_1.basename)(dest), ''), ctx);
                releaseWebdavLock(node.vfsPath); // RFC 4918 says MOVE must not carry locks to destination, so clear source lock on success
                return ctx.status = cross_1.HTTP_CREATED;
            }
            catch (e) {
                return ctx.status = e.status || cross_1.HTTP_SERVER_ERROR;
            }
        const actualDest = (0, cross_1.join)((0, path_1.dirname)(dest), (0, path_1.basename)(pathKey));
        // moveFiles keeps the source basename for cross-directory moves, so check the lock it will actually touch
        if (actualDest !== dest && await isLocked(actualDest, ctx))
            return;
        const moveRes = await (0, frontEndApis_1.moveFiles)([pathKey], (0, path_1.dirname)(dest), ctx);
        if (moveRes instanceof Error)
            return ctx.status = moveRes.status || cross_1.HTTP_SERVER_ERROR;
        const err = moveRes?.errors?.[0];
        if (!err)
            releaseWebdavLock(node.vfsPath); // successful MOVE leaves the old path invalid, therefore its lock must be dropped
        return ctx.status = !err ? cross_1.HTTP_CREATED : typeof err === 'number' ? err : cross_1.HTTP_SERVER_ERROR;
    }
    async function handleDelete() {
        setWebdavHeaders();
        const resource = await resolveWebdavResource(pathKey, ctx);
        const { node } = resource;
        if (await isLocked(path, ctx, resource))
            return;
        await next();
        if (ctx.status === cross_1.HTTP_OK)
            releaseWebdavLock(node?.vfsPath || path); // webdav clients may forget UNLOCK; successful delete must clear any lock
    }
    async function handleUnlock() {
        setWebdavHeaders();
        const x = ctx.get(TOKEN_HEADER).slice(1, -1);
        const lockKey = (await resolveWebdavResource(pathKey, ctx)).key;
        const lock = getWebdavLock(lockKey);
        if (x !== lock?.token)
            return ctx.status = cross_1.HTTP_BAD_REQUEST;
        // with force_webdav_login disabled a client may silently fall back to anonymous; keep lock ownership on the original username
        if (!isSameLockUsername(lock, ctx))
            return ctx.status = cross_1.HTTP_PRECONDITION_FAILED;
        releaseWebdavLock(lockKey);
        ctx.set(TOKEN_HEADER, x);
        if (const_1.IS_MAC)
            (0, vfs_1.urlToNode)(path, ctx).then(x => x?.source && dotClean((0, path_1.dirname)(x.source)));
        return ctx.status = cross_1.HTTP_NO_CONTENT;
    }
    async function handleLock() {
        setWebdavHeaders();
        // a lock reserves a future write, so authorize it against the existing resource or its parent
        const { key: lockKey, node } = await resolveWebdavResource(pathKey, ctx);
        const permissionNode = node || await (0, vfs_1.urlToNode)((0, path_1.dirname)(pathKey), ctx);
        if (!permissionNode)
            return ctx.status = cross_1.HTTP_CONFLICT;
        const overwriteGraceKey = webdavOverwriteKey(lockKey, ctx);
        const missingWritePerm = node && overwriteGraceKey && canOverwrite.has(overwriteGraceKey) ? 0
            : (0, vfs_1.statusCodeForMissingPerm)(permissionNode, node ? 'can_delete' : 'can_upload', ctx);
        if (missingWritePerm) {
            if (ctx.status === cross_1.HTTP_UNAUTHORIZED)
                setWebdavHeaders(true);
            return;
        }
        const body = await (0, util_http_1.readRequestBodyLimited)(ctx, 1024 * 1024);
        if (!body)
            return;
        const bodyText = body.text;
        const token = getProvidedLockToken();
        let seconds = Number(ctx.get('timeout').split(',').find(x => /^Second-\d+$/i.test(x.trim()))?.trim().split('-', 2)[1]);
        seconds = lodash_1.default.clamp(seconds || LOCK_DEFAULT_SECONDS, 1, LOCK_MAX_SECONDS);
        if (!bodyText) {
            // Finder and similar clients refresh an existing lock by sending LOCK without a body
            if (!token)
                return ctx.status = cross_1.HTTP_BAD_REQUEST;
            const lock = getWebdavLock(lockKey);
            if (token !== lock?.token)
                return ctx.status = cross_1.HTTP_PRECONDITION_FAILED;
            // same-token refresh from another username would make abandoned locks effectively persistent
            if (!isSameLockUsername(lock, ctx))
                return ctx.status = cross_1.HTTP_PRECONDITION_FAILED;
            // refresh lock - keep the same token on refresh so clients can continue using the lock they already hold
            clearTimeout(lock.timeout);
            lock.timeout = setTimeout(() => releaseWebdavLock(lockKey), seconds * 1000);
            lock.seconds = seconds;
            setWebdavLock(lockKey, lock);
            ctx.set(TOKEN_HEADER, lock.token);
            ctx.body = renderLockResponse(lock.token, lock.seconds);
            return;
        }
        const lockinfo = (0, cross_1.try_)(() => xmlParser.parse(bodyText).lockinfo);
        const scope = lodash_1.default.keys(lockinfo?.lockscope)[0];
        const type = lodash_1.default.keys(lockinfo?.locktype)[0];
        if (!scope || !type)
            return ctx.status = cross_1.HTTP_BAD_REQUEST;
        if (ctx.get('depth') && ctx.get('depth') !== '0')
            return ctx.status = cross_1.HTTP_CONFLICT;
        if (scope !== 'exclusive' || type !== 'write')
            return ctx.status = cross_1.HTTP_CONFLICT;
        if (getWebdavLock(lockKey))
            return ctx.status = cross_1.HTTP_LOCKED;
        const newToken = 'urn:uuid:' + (0, node_crypto_1.randomUUID)();
        const timeout = setTimeout(() => releaseWebdavLock(lockKey), seconds * 1000);
        setWebdavLock(lockKey, {
            token: newToken, timeout, seconds, username: getWebdavUsername(ctx), lockNull: !node, path: pathKey,
        });
        ctx.set(TOKEN_HEADER, newToken);
        ctx.body = renderLockResponse(newToken, seconds);
    }
    async function handlePropfind() {
        setWebdavHeaders();
        const node = await (0, vfs_1.urlToNode)(path, ctx);
        if (!node)
            return next();
        let depth = Number(ctx.get('depth'));
        depth = isNaN(depth) ? Infinity : depth;
        const isList = depth !== 0;
        if ((0, vfs_1.statusCodeForMissingPerm)(node, isList ? 'can_list' : 'can_see', ctx)) {
            if (ctx.status === cross_1.HTTP_UNAUTHORIZED)
                setWebdavHeaders(true);
            return;
        }
        ctx.type = 'xml';
        ctx.status = 207;
        const outPath = webdavHrefPath(path, node, ctx);
        const res = ctx.body = new stream_1.PassThrough({ encoding: 'utf8' });
        res.write(`<?xml version="1.0" encoding="utf-8" ?><D:multistatus xmlns:D="DAV:">`);
        await sendEntry(node);
        if (isList) {
            depth = Math.max(0, depth - 1);
            for await (const n of (0, vfs_1.walkNode)(node, { ctx, depth }))
                await sendEntry(n, true);
        }
        res.write(`</D:multistatus>`);
        res.end();
        async function sendEntry(node, append = false) {
            if ((0, vfs_1.nodeIsLink)(node))
                return;
            const name = (0, vfs_1.getNodeName)(node);
            const isDir = await (0, vfs_1.nodeIsFolder)(node);
            const st = append && node.see_without_probing ? undefined : await (0, vfs_1.nodeStats)(node);
            res.write(`<D:response>
              <D:href>${lodash_1.default.escape(outPath + (append ? (0, cross_1.pathEncode)(name, true) + (isDir ? '/' : '') : ''))}</D:href>
              <D:propstat>
                <D:prop>
                    ${(0, cross_1.prefix)('<D:getlastmodified>', st?.mtime?.toGMTString(), '</D:getlastmodified>')}
                    ${(0, cross_1.prefix)('<D:creationdate>', (st?.birthtime || st?.ctime)?.toISOString().replace(/\..*/, '-00:00'), '</D:creationdate>')}
                    ${isDir ? '<D:resourcetype><D:collection/></D:resourcetype>'
                : `<D:resourcetype/><D:getcontentlength>${st?.size}</D:getcontentlength>`}
                </D:prop>
                <D:status>HTTP/1.1 200 OK</D:status>
              </D:propstat>
              </D:response>
            `);
        }
    }
    async function handleProppatch() {
        setWebdavHeaders();
        if (await isLocked(path, ctx))
            return;
        const node = await (0, vfs_1.urlToNode)(pathKey, ctx);
        if (!node)
            return next();
        if ((0, vfs_1.statusCodeForMissingPerm)(node, 'can_see', ctx)) {
            if (ctx.status === cross_1.HTTP_UNAUTHORIZED)
                setWebdavHeaders(true);
            return;
        }
        const body = await (0, util_http_1.readRequestBodyLimited)(ctx, 1024 * 1024);
        if (!body)
            return;
        const bodyText = body.text;
        const props = (0, cross_1.try_)(() => parseProppatchProps(bodyText)) || [];
        if (!props.length)
            return ctx.status = cross_1.HTTP_BAD_REQUEST;
        const statuses = [];
        for (const prop of props)
            statuses.push({ prop: prop.name, status: await applyProppatchProp(prop, node, node.vfsPath, ctx) });
        const outPath = webdavHrefPath(path, node, ctx);
        ctx.type = 'xml';
        ctx.status = 207;
        ctx.body = renderProppatchResponse(outPath, statuses);
    }
    function setWebdavHeaders(authenticate = false) {
        ctx.set('DAV', '1,2');
        ctx.set('MS-Author-Via', 'DAV');
        ctx.set('Allow', 'PROPFIND,PROPPATCH,OPTIONS,DELETE,MOVE,LOCK,UNLOCK,MKCOL,PUT');
        if (authenticate)
            ctx.set('WWW-Authenticate', cross_1.BASIC_AUTHENTICATE_HEADER);
    }
    function shouldChallengeWebdav() {
        if ((0, auth_1.getCurrentUsername)(ctx))
            return false;
        if (forceWebdavLogin.compiled()?.test(ua))
            return challengeWebdav();
        if (!webdavInitialAuth.compiled()?.test(ua))
            return false;
        if (ctx.get('authorization'))
            return challengeWebdav();
        const key = `${ctx.ip}|${ctx.host}|${ua || ''}`;
        if (webdavPrompted.has(key))
            return false;
        webdavPrompted.try(key, () => true);
        return challengeWebdav();
        function challengeWebdav() {
            setWebdavHeaders(true);
            ctx.status = cross_1.HTTP_UNAUTHORIZED;
            ctx.body = '';
            return true;
        }
    }
    function getProvidedLockToken() {
        const direct = ctx.get(TOKEN_HEADER).replace(/[<>]/g, '');
        if (direct)
            return direct;
        const ifHeader = ctx.get('If');
        return /<([^>]+)>/.exec(ifHeader)?.[1] || '';
    }
    function renderLockResponse(token, seconds) {
        return `<?xml version="1.0" encoding="utf-8"?><D:prop xmlns:D="DAV:"><D:lockdiscovery><D:activelock>
            <D:locktype><D:write/></D:locktype>
            <D:lockscope><D:exclusive/></D:lockscope>
            <D:locktoken><D:href>${lodash_1.default.escape(token)}</D:href></D:locktoken>
            <D:lockroot><D:href>${lodash_1.default.escape(path)}</D:href></D:lockroot>
            <D:depth>0</D:depth>
            <D:timeout>Second-${seconds}</D:timeout>
        </D:activelock></D:lockdiscovery></D:prop>`;
    }
};
exports.webdav = webdav;
function compileWebdavAgentRegex(v) {
    return !v ? null : v === true ? /.*/ : new RegExp(v.trim(), 'i');
}
function webdavAgentKey(ctx, ua) {
    // tying detection to source IP avoids promoting one spoofed UA to global WebDAV behavior
    return `${ctx.ip}|${ua}`;
}
function allowWebdavOverwrite(key) {
    canOverwrite.add(key);
    setTimeout(() => canOverwrite.delete(key), 10_000); // grace period
}
function webdavHrefPath(path, node, ctx) {
    const href = path.slice(Math.max(0, (ctx.state.root?.length ?? 0) - 1));
    // WebDAV clients use href shape to infer resource type, so file hrefs must not look like collections
    return (0, vfs_1.nodeIsFolder)(node) ? (0, cross_1.enforceFinal)('/', href) : (0, cross_1.removeFinal)('/', href);
}
function parseProppatchProps(body) {
    const doc = xmlParser.parse(body);
    const update = getXmlChildren(doc, 'propertyupdate')[0];
    if (!update)
        return [];
    const ret = [];
    for (const opName of ['set', 'remove'])
        for (const op of getXmlChildren(update, opName))
            for (const prop of getXmlChildren(op, 'prop'))
                for (const k of Object.keys(prop))
                    if (!k.startsWith('@_') && k !== '#text')
                        ret.push({ name: localXmlName(k), value: prop[k] });
    return lodash_1.default.uniqBy(ret, 'name');
}
async function applyProppatchProp(prop, node, path, ctx) {
    const k = prop.name.toLowerCase();
    if (PROPPATCH_PROTECTED_LIVE_PROPS.has(k))
        return cross_1.HTTP_FORBIDDEN;
    if (!PROPPATCH_UTIME_PROPS.has(k)
        && !(const_1.IS_WINDOWS && k === 'win32fileattributes'))
        return cross_1.HTTP_OK; // PROPPATCH is only persisted when HFS gets real dead-property storage; no-op success keeps Windows and macOS clients from aborting writes
    const { source } = node;
    if (!source)
        return cross_1.HTTP_FORBIDDEN;
    // WebDAV clients patch metadata right after upload; outside that short same-uploader grace, metadata writes are file modifications
    const overwriteGraceKey = webdavOverwriteKey(path, ctx);
    const missingWritePerm = overwriteGraceKey && canOverwrite.has(overwriteGraceKey) ? 0
        : (0, vfs_1.statusCodeForMissingPerm)(node, 'can_delete', ctx, false);
    if (missingWritePerm)
        return missingWritePerm;
    if (PROPPATCH_UTIME_PROPS.has(k)) {
        const date = new Date(String(prop.value));
        if (isNaN(Number(date)))
            return cross_1.HTTP_BAD_REQUEST;
        const stats = await (0, vfs_1.nodeStats)(node);
        const atime = k === 'win32lastaccesstime' ? date : stats?.atime ?? new Date();
        const mtime = k === 'win32lastmodifiedtime' ? date : stats?.mtime ?? new Date();
        // WebDAV clients often use dead properties for file times; apply the portable subset instead of only pretending success
        await (0, promises_1.utimes)(source, atime, mtime);
    }
    else {
        const attributes = parseWindowsFileAttributes(prop.value);
        if (attributes === undefined)
            return cross_1.HTTP_BAD_REQUEST;
        // fswin is already our Windows attribute bridge; this keeps PROPPATCH metadata aligned with the actual filesystem
        const ok = await new Promise(resolve => fswin_1.default.setAttributes(source, lodash_1.default.mapValues(WINDOWS_FILE_ATTRIBUTE_FLAGS, flag => Boolean(attributes & flag)), ok => resolve(Boolean(ok))));
        if (!ok)
            return cross_1.HTTP_SERVER_ERROR;
    }
    return cross_1.HTTP_OK;
}
function parseWindowsFileAttributes(v) {
    const s = String(v).trim();
    if (!s)
        return;
    const n = Number(/^0x/i.test(s) || /^[0-9a-f]{8}$/i.test(s) ? '0x' + s.replace(/^0x/i, '') : s);
    if (!Number.isInteger(n) || n < 0)
        return;
    return n;
}
function renderProppatchResponse(path, statuses) {
    const byStatus = lodash_1.default.groupBy(statuses, 'status');
    return `<?xml version="1.0" encoding="utf-8" ?><D:multistatus xmlns:D="DAV:"><D:response>
        <D:href>${lodash_1.default.escape(path)}</D:href>
        ${lodash_1.default.map(byStatus, (items, status) => `<D:propstat>
            <D:prop>${items.map(({ prop }) => `<D:${prop}/>`).join('')}</D:prop>
            <D:status>HTTP/1.1 ${status} ${lodash_1.default.escape(cross_1.HTTP_MESSAGES[Number(status)] || http_1.STATUS_CODES[Number(status)] || '')}</D:status>
        </D:propstat>`).join('')}
    </D:response></D:multistatus>`;
}
function getXmlChildren(obj, name) {
    if (!obj || typeof obj !== 'object')
        return [];
    return Object.entries(obj).flatMap(([k, v]) => localXmlName(k) === name ? (0, cross_1.wantArray)(v) : []);
}
function localXmlName(name) {
    return name.split(':').at(-1) || name;
}
// Finder will upload special attributes as files with name ._* that can be merged using system utility "dot_clean"
const cleaners = {};
function dotClean(path) {
    (0, cross_1.getOrSet)(cleaners, path, () => setTimeout(() => {
        try {
            (0, child_process_1.exec)('dot_clean .', { cwd: path }, (err, out) => done(err || out));
        }
        catch (e) {
            done(e);
        }
        function done(log) {
            console.debug('dot_clean', path, log);
            delete cleaners[path];
        }
    }, 10_000));
}
