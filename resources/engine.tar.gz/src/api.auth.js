"use strict";
// This file is part of HFS - Copyright 2021-2023, Massimo Melina <a@rejetto.com> - License https://www.gnu.org/licenses/gpl-3.0.txt
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authApis = void 0;
const perm_1 = require("./perm");
const apiMiddleware_1 = require("./apiMiddleware");
const const_1 = require("./const");
const adminApis_1 = require("./adminApis");
const middlewares_1 = require("./middlewares");
const auth_1 = require("./auth");
const config_1 = require("./config");
const events_1 = __importDefault(require("./events"));
const misc_1 = require("./misc");
const uploadOwners_1 = require("./uploadOwners");
const node_crypto_1 = require("node:crypto");
const sessionStamp_1 = require("./sessionStamp");
const ongoingLogins = {}; // store data that doesn't fit session object
const keepSessionAlive = (0, config_1.defineConfig)(misc_1.CFG.keep_session_alive, true);
const fakeSrpSecret = (0, node_crypto_1.randomBytes)(32);
const refresh_session = async ({}, ctx) => {
    if (!ctx.session)
        return new apiMiddleware_1.ApiError(const_1.HTTP_SERVER_ERROR);
    (0, uploadOwners_1.getSessionId)(ctx); // anonymous upload ownership must be bound before any abortible upload request
    const username = (0, auth_1.getCurrentUsername)(ctx);
    const isAdmin = (0, adminApis_1.ctxAdminAccess)(ctx) || undefined;
    return {
        username,
        expandedUsername: Array.from((0, perm_1.expandUsername)(username)),
        isAdmin,
        adminUrl: isAdmin && ctx.state.revProxyPath + const_1.ADMIN_URI,
        canChangePassword: (0, perm_1.accountCanChangePassword)(ctx.state.account),
        requireChangePassword: ctx.state.account?.require_password_change,
        exp: username && keepSessionAlive.get() ? new Date(Date.now() + middlewares_1.sessionDuration.compiled()) : undefined,
        accountExp: ctx.state.account?.expire,
    };
};
exports.authApis = {
    async login({ username, password }, ctx) {
        if (!username)
            return new apiMiddleware_1.ApiError(const_1.HTTP_BAD_REQUEST);
        if (!ctx.session)
            return new apiMiddleware_1.ApiError(const_1.HTTP_SERVER_ERROR);
        try {
            const account = await (0, auth_1.clearTextLogin)(ctx, username, password, 'api');
            if (!account)
                return new apiMiddleware_1.ApiError(const_1.HTTP_UNAUTHORIZED);
            await (0, auth_1.setLoggedIn)(ctx, account.username, ctx.state.params ? 'body' : 'url');
        }
        catch (e) {
            events_1.default.emit('failedLogin', { ctx, username, via: 'api' });
            return new apiMiddleware_1.ApiError(const_1.HTTP_UNAUTHORIZED, e);
        }
        return {
            redirect: ctx.state.account?.redirect,
            ...await refresh_session({}, ctx)
        };
    },
    async loginSrp1({ username }, ctx) {
        (0, misc_1.apiAssertTypes)({ string: { username } });
        if (!username)
            return new apiMiddleware_1.ApiError(const_1.HTTP_BAD_REQUEST);
        const account = (0, perm_1.getAccount)(username);
        if (!ctx.session)
            return new apiMiddleware_1.ApiError(const_1.HTTP_SERVER_ERROR);
        if (account?.plugin?.auth) // tell client to do clear-text login, before firing attemptingLogin, before triggering anti-brute
            return new apiMiddleware_1.ApiError(const_1.HTTP_METHOD_NOT_ALLOWED);
        if ((await events_1.default.emitAsync('attemptingLogin', { ctx, username, via: 'srp' }))?.isDefaultPrevented())
            return;
        if (account && !(0, perm_1.accountCanLogin)(account)) {
            ctx.logExtra({ u: username });
            ctx.state.dontLog = false; // log even if log_api is false
            return unauthorized((0, perm_1.accountIsDisabled)(account) ? 'Account disabled' : undefined);
        }
        if (account && (0, middlewares_1.failAllowNet)(ctx, account))
            return unauthorized();
        try { // unknown users complete step 1 so only a full failed login can reveal and penalize the attempt
            const stamp = account && (0, sessionStamp_1.getSessionStamp)(account.username);
            const { srpServer, ...rest } = await (0, auth_1.srpServerStep1)(account || fakeSrpAccount(username));
            // keep the public handshake identifier independent of predictable application PRNG state
            const sid = (0, node_crypto_1.randomUUID)();
            ongoingLogins[sid] = srpServer;
            setTimeout(() => delete ongoingLogins[sid], 60_000); // client must complete api sequence (loginSrp2) within 1 minute or will be discarded to avoid memory leaks
            // 60-second expiry bounded 5k challenges to ~37 MB in a local saturation test, so an additional cap isn't justified
            ctx.session.loggingIn = { username, sid, stamp }; // temporarily store until process is complete
            return rest;
        }
        catch (code) {
            return new apiMiddleware_1.ApiError(code);
        }
        function unauthorized(message) {
            events_1.default.emit('failedLogin', { ctx, username });
            return new apiMiddleware_1.ApiError(const_1.HTTP_UNAUTHORIZED, message);
        }
        function fakeSrpAccount(username) {
            username = (0, perm_1.normalizeUsername)(username);
            return {
                username,
                // process-secret derivation keeps fake credentials stable per username without storing attacker-controlled names
                srp: `${derive('salt')}|${derive('verifier')}`,
            };
            function derive(field) {
                return BigInt('0x' + (0, node_crypto_1.createHmac)('sha256', fakeSrpSecret).update(field).update(username).digest('hex')).toString();
            }
        }
    },
    async loginSrp2({ pubKey, proof }, ctx) {
        if (!ctx.session)
            return new apiMiddleware_1.ApiError(const_1.HTTP_SERVER_ERROR);
        if (!ctx.session.loggingIn)
            return new apiMiddleware_1.ApiError(const_1.HTTP_CONFLICT);
        const { username, sid, stamp } = ctx.session.loggingIn;
        delete ctx.session.loggingIn;
        const step1 = ongoingLogins[sid];
        if (!step1)
            return new apiMiddleware_1.ApiError(const_1.HTTP_NOT_FOUND);
        try {
            const M2 = await step1.step2(BigInt(pubKey), BigInt(proof))
                .catch(() => { throw ''; }); // falsy value for later
            // an old-password handshake must not mint a session after credentials have been revoked
            const account = (0, perm_1.getAccount)(username);
            if (!account || !stamp || stamp !== (0, sessionStamp_1.getSessionStamp)(account.username))
                throw '';
            await (0, auth_1.setLoggedIn)(ctx, username, 'srp');
            return {
                proof: String(M2),
                redirect: ctx.state.account?.redirect,
                ...await refresh_session({}, ctx)
            };
        }
        catch (e) {
            ctx.logExtra({ u: username });
            ctx.state.dontLog = false; // log even if log_api is false
            events_1.default.emit('failedLogin', { ctx, username });
            return new apiMiddleware_1.ApiError(const_1.HTTP_UNAUTHORIZED, e);
        }
        finally {
            delete ongoingLogins[sid];
        }
    },
    async logout({}, ctx) {
        if (!ctx.session)
            return new apiMiddleware_1.ApiError(const_1.HTTP_SERVER_ERROR);
        await (0, auth_1.setLoggedIn)(ctx, false);
        // 401 is a convenient code for OK: the browser clears a possible http authentication (hopefully), and Admin automatically triggers login dialog
        return new apiMiddleware_1.ApiError(const_1.HTTP_UNAUTHORIZED);
    },
    refresh_session,
    async change_srp({ username, salt, verifier }, ctx) {
        const a = username && (0, perm_1.getAccount)(username);
        const can = a && ((0, adminApis_1.ctxAdminAccess)(ctx) || username === (0, auth_1.getCurrentUsername)(ctx) && (0, perm_1.accountCanChangePassword)(a));
        if (!can)
            return new apiMiddleware_1.ApiError(const_1.HTTP_UNAUTHORIZED);
        if (!salt || !verifier)
            return new apiMiddleware_1.ApiError(const_1.HTTP_BAD_REQUEST, 'missing parameters');
        await (0, perm_1.updateAccount)(a, a => (0, perm_1.saveSrpInfo)(a, salt, verifier));
        if (ctx.session?.username === a.username)
            ctx.session.stamp = (0, sessionStamp_1.getSessionStamp)(a.username);
        delete a.require_password_change;
        return {};
    }
};
