"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.argv = void 0;
const minimist_1 = __importDefault(require("minimist"));
exports.argv = (0, minimist_1.default)(process.argv.slice(2));
// Node's internal flag is read-only when enabled via its CLI, but remains configurable
Object.defineProperty(process, 'traceProcessWarnings', {
    value: exports.argv['trace-warnings'] !== false, writable: true, configurable: true,
});
