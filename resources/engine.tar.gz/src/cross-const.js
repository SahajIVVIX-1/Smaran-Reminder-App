"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HTTP_MESSAGES = exports.HTTP_INSUFFICIENT_STORAGE = exports.HTTP_SERVICE_UNAVAILABLE = exports.HTTP_SERVER_ERROR = exports.HTTP_TOO_MANY_REQUESTS = exports.HTTP_FAILED_DEPENDENCY = exports.HTTP_LOCKED = exports.HTTP_FOOL = exports.HTTP_RANGE_NOT_SATISFIABLE = exports.HTTP_PAYLOAD_TOO_LARGE = exports.HTTP_PRECONDITION_FAILED = exports.HTTP_LENGTH_REQUIRED = exports.HTTP_CONFLICT = exports.HTTP_NOT_ACCEPTABLE = exports.HTTP_METHOD_NOT_ALLOWED = exports.HTTP_NOT_FOUND = exports.HTTP_FORBIDDEN = exports.HTTP_UNAUTHORIZED = exports.HTTP_BAD_REQUEST = exports.HTTP_TEMPORARY_REDIRECT_KEEP_METHOD = exports.HTTP_NOT_MODIFIED = exports.HTTP_TEMPORARY_REDIRECT = exports.HTTP_MOVED_PERMANENTLY = exports.HTTP_PARTIAL_CONTENT = exports.HTTP_NO_CONTENT = exports.HTTP_CREATED = exports.HTTP_OK = exports.CFG = exports.MB = exports.KB = exports.BASIC_AUTHENTICATE_HEADER = exports.EMBEDDED_LANGUAGE = exports.MASK_IN_TESTS = exports.HIDE_IN_TESTS = exports.ALLOW_SESSION_IP_CHANGE = exports.PREVIOUS_TAG = exports.MTIME_CHECK = exports.UPLOAD_TEMP_HASH = exports.UPLOAD_TEMP_PREFIX = exports.PLUGIN_USAGE_URL = exports.HFS_REPO = exports.PLUGIN_CUSTOM_REST_PREFIX = exports.NBSP = exports.PORT_DISABLED = exports.ICONS_URI = exports.PLUGINS_PUB_URI = exports.API_URI = exports.ADMIN_URI = exports.FRONTEND_URI = exports.SPECIAL_URI = void 0;
exports.SPECIAL_URI = '/~/';
exports.FRONTEND_URI = exports.SPECIAL_URI + 'frontend/';
exports.ADMIN_URI = exports.SPECIAL_URI + 'admin/';
exports.API_URI = exports.SPECIAL_URI + 'api/';
exports.PLUGINS_PUB_URI = exports.SPECIAL_URI + 'plugins/';
exports.ICONS_URI = exports.SPECIAL_URI + 'icons/';
exports.PORT_DISABLED = -1;
exports.NBSP = '\xA0';
exports.PLUGIN_CUSTOM_REST_PREFIX = '_';
exports.HFS_REPO = 'rejetto/hfs';
exports.PLUGIN_USAGE_URL = 'https://hfs-api.rejetto.com/plugin-usage';
exports.UPLOAD_TEMP_PREFIX = 'hfs$upload-';
exports.UPLOAD_TEMP_HASH = 'upload-temp-hash';
exports.MTIME_CHECK = 'x-mtime-check';
exports.PREVIOUS_TAG = 'previous';
exports.ALLOW_SESSION_IP_CHANGE = 'allow_session_ip_change';
exports.HIDE_IN_TESTS = 'hideInTests'; // elements that have variable size, where masking would produce changes, must be hidden
exports.MASK_IN_TESTS = 'maskInTests';
exports.EMBEDDED_LANGUAGE = 'en';
exports.BASIC_AUTHENTICATE_HEADER = 'Basic realm="HFS"';
exports.KB = 1024;
exports.MB = exports.KB * exports.KB;
exports.CFG = constMap([
    'accounts', 'acme_domain', 'acme_renew', 'acme_challenge', 'acme_dns', 'admin_lang', 'admin_net', 'allowed_referer',
    'authorization_header', 'auto_basic', 'auto_check_update', 'auto_play_seconds',
    'base_url', 'block', 'cache_control_disk_files', 'cert', 'comments_storage',
    'create-admin', 'debug', 'delete_unfinished_uploads_after',
    'descript_ion_encoding', 'disable_custom_html', 'disableTranslation', 'dont_log_net',
    'dont_overwrite_uploading', 'dynamic_dns_url', 'enable_plugins', 'error_log',
    'favicon', 'file_menu_on_link', 'file_timeout', 'folders_first', 'force_address',
    'force_https', 'force_lang', 'force_webdav_login',
    'geo_allow', 'geo_allow_unknown', 'geo_enable', 'geo_ignore_net', 'geo_list',
    'ignore_proxies', 'invert_order', 'keep_session_alive', 'listen_interface',
    'localhost_admin', 'log', 'log_api', 'log_gui', 'log_host', 'log_rotation', 'log_spam', 'log_spam_regex',
    'log_ua', 'mapped_port', 'max_downloads', 'max_downloads_per_account',
    'max_downloads_per_ip', 'max_kbps', 'max_kbps_per_ip', 'menu_at_top', 'mime',
    'min_available_mb', 'open_browser_at_start', 'outbound_interface', 'outbound_proxy', 'own_upload_delete_hours',
    'page_size', 'plugins_config', 'port', 'private_key', 'proxies', 'roots', 'server_code',
    'session_duration', 'share_usage_stats', 'show_hidden_files', 'show_uploader', 'size_1024',
    'smart_unc_folder_detection', 'sort_by', 'sort_numerics', 'split_uploads',
    'suspend_plugins', 'theme', 'tile_size', 'title', 'title_with_path', 'track_ips',
    'update_to_beta', 'upnp_enabled', 'version', 'vfs', 'webdav_initial_auth',
    'zip_calculate_size_for_seconds', 'https_port', 'require_upload_approval_for_active_content',
]);
function constMap(a) {
    return Object.fromEntries(a.map(x => [x, x]));
}
exports.HTTP_OK = 200;
exports.HTTP_CREATED = 201;
exports.HTTP_NO_CONTENT = 204;
exports.HTTP_PARTIAL_CONTENT = 206;
exports.HTTP_MOVED_PERMANENTLY = 301;
exports.HTTP_TEMPORARY_REDIRECT = 302;
exports.HTTP_NOT_MODIFIED = 304;
exports.HTTP_TEMPORARY_REDIRECT_KEEP_METHOD = 307;
exports.HTTP_BAD_REQUEST = 400;
exports.HTTP_UNAUTHORIZED = 401;
exports.HTTP_FORBIDDEN = 403;
exports.HTTP_NOT_FOUND = 404;
exports.HTTP_METHOD_NOT_ALLOWED = 405;
exports.HTTP_NOT_ACCEPTABLE = 406;
exports.HTTP_CONFLICT = 409;
exports.HTTP_LENGTH_REQUIRED = 411;
exports.HTTP_PRECONDITION_FAILED = 412;
exports.HTTP_PAYLOAD_TOO_LARGE = 413;
exports.HTTP_RANGE_NOT_SATISFIABLE = 416;
exports.HTTP_FOOL = 418;
exports.HTTP_LOCKED = 423;
exports.HTTP_FAILED_DEPENDENCY = 424;
exports.HTTP_TOO_MANY_REQUESTS = 429;
exports.HTTP_SERVER_ERROR = 500;
exports.HTTP_SERVICE_UNAVAILABLE = 503;
exports.HTTP_INSUFFICIENT_STORAGE = 507;
exports.HTTP_MESSAGES = {
    [exports.HTTP_UNAUTHORIZED]: "Unauthorized",
    [exports.HTTP_FORBIDDEN]: "Forbidden",
    [exports.HTTP_NOT_FOUND]: "Not found",
    [exports.HTTP_SERVER_ERROR]: "Server error",
    [exports.HTTP_TOO_MANY_REQUESTS]: "Too many requests",
};
