"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.customizedIcons = exports.ICONS_FOLDER = void 0;
exports.watchIconsFolder = watchIconsFolder;
const path_1 = require("path");
const util_files_1 = require("./util-files");
const debounceAsync_1 = require("./debounceAsync");
const promises_1 = require("fs/promises");
const config_1 = require("./config");
exports.ICONS_FOLDER = 'icons';
config_1.configReady.then(() => {
    watchIconsFolder('.', v => exports.customizedIcons = v);
});
function watchIconsFolder(parentFolder, cb) {
    const iconsFolder = (0, path_1.join)(parentFolder, exports.ICONS_FOLDER);
    const watcher = (0, util_files_1.watchDir)(iconsFolder, (0, debounceAsync_1.debounceAsync)(async () => {
        let res = {}; // reset
        try {
            for (const f of await (0, promises_1.readdir)(iconsFolder, { withFileTypes: true })) {
                if (!f.isFile())
                    continue;
                const k = (0, path_1.basename)(f.name, (0, path_1.extname)(f.name));
                res[k] = f.name;
            }
            cb(res);
        }
        catch {
            cb(undefined);
        } // no such dir
    }), true);
    return () => watcher.stop();
}
