"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getErrorSections = getErrorSections;
exports.sendErrorPage = sendErrorPage;
const lang_1 = require("./lang");
const customHtml_1 = require("./customHtml");
const cross_1 = require("./cross");
const declaredErrorPages = [cross_1.HTTP_NOT_FOUND, cross_1.HTTP_FORBIDDEN, cross_1.HTTP_TOO_MANY_REQUESTS].map(String);
function getErrorSections() {
    return declaredErrorPages;
}
// to be used with errors whose recipient is possibly human
async function sendErrorPage(ctx, code = ctx.status) {
    ctx.type = 'text';
    ctx.set('content-disposition', ''); // reset ctx.attachment (or forceDownload)
    ctx.status = code;
    let msg = cross_1.HTTP_MESSAGES[ctx.status] || '';
    if (!msg)
        return;
    const lang = await (0, lang_1.getLangData)(ctx);
    const trans = lang ? Object.values(lang)[0]?.translate : undefined;
    msg = trans?.[msg] ?? msg;
    const page = (0, customHtml_1.getSection)(ctx.status === cross_1.HTTP_UNAUTHORIZED ? 'unauthorized' : String(ctx.status))
        || SIMPLE_PAGE || '';
    if (page.includes('<'))
        ctx.type = 'html';
    ctx.body = (0, cross_1.replace)(page, { MESSAGE: msg, HOME: trans?.home ?? 'home', URL: ctx.state.revProxyPath || '/' }, '$');
}
const SIMPLE_PAGE = `<!DOCTYPE html>
<html><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>$MESSAGE</title>
<style>
body{margin-top:30vh; text-align:center; font-family:sans-serif;}
a{color:#68a}
@media (prefers-color-scheme:dark){body{background:#111; color:#999;}}
</style>
</head><body>
<h1>$MESSAGE</h1>
<h2><a href="$URL">$HOME</a></h2>
</body></html>`;
