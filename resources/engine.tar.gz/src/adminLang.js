"use strict";
// This file is part of HFS - Copyright 2026, Massimo Melina <a@rejetto.com> - License https://www.gnu.org/licenses/gpl-3.0.txt
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.adminLang = void 0;
exports.getAdminLangs = getAdminLangs;
exports.getAdminLangData = getAdminLangData;
exports.invalidateAdminLang = invalidateAdminLang;
const promises_1 = require("fs/promises");
const misc_1 = require("./misc");
const config_1 = require("./config");
const expiringCache_1 = require("./expiringCache");
const embedded_1 = __importDefault(require("./admin-langs/embedded"));
const const_1 = require("./const");
const lang_1 = require("./lang");
const fast_glob_1 = __importDefault(require("fast-glob"));
const lodash_1 = __importDefault(require("lodash"));
async function getAdminLangs() {
    const files = await (0, fast_glob_1.default)((0, lang_1.code2file)('*', true));
    return lodash_1.default.uniq([...Object.keys(embedded_1.default), ...files.map(name => (0, lang_1.file2code)(name, true))
            .filter(code => (0, lang_1.normalizeLangCode)(code) === code)]);
}
exports.adminLang = (0, config_1.defineConfig)(misc_1.CFG.admin_lang, '', v => (0, lang_1.langCodeForLookup)((0, lang_1.normalizeLangCode)(v)));
const cache = (0, expiringCache_1.expiringCache)(3_000);
function getAdminLangData(ctx, langs) {
    const configured = exports.adminLang.compiled();
    const code = langs.includes(configured) ? configured : browserAdminLang(ctx, langs);
    return cache.try(code, async () => ({
        [code]: (0, misc_1.tryJson)(await (0, promises_1.readFile)((0, lang_1.code2file)(code, true), 'utf8').catch(() => ''))
            || embedded_1.default[code] || embedded_1.default.en,
        ...code === const_1.EMBEDDED_LANGUAGE ? {} : { [const_1.EMBEDDED_LANGUAGE]: embedded_1.default.en },
    }));
}
function invalidateAdminLang(code) {
    cache.delete(code); // uploads and deletions must be visible immediately after the Admin reloads
}
function browserAdminLang(ctx, langs) {
    const accepted = ctx?.get('Accept-Language') || '';
    for (const raw of accepted.split(',')) {
        let code = (0, lang_1.normalizeLangCode)(raw);
        while (code) {
            const candidate = (0, lang_1.langCodeForLookup)(code);
            if (langs.includes(candidate))
                return candidate;
            code = code.substring(0, code.lastIndexOf('-'));
        }
    }
    return const_1.EMBEDDED_LANGUAGE;
}
