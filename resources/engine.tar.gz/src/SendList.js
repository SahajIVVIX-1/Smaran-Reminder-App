"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SendListReadable = void 0;
const stream_1 = require("stream");
const lodash_1 = __importDefault(require("lodash"));
const cross_1 = require("./cross");
const events_1 = __importDefault(require("./events"));
// offer an api for a generic dynamic list. Suitable to be the result of an api.
class SendListReadable extends stream_1.Readable {
    lastError;
    buffer = [];
    processBuffer;
    sent;
    constructor({ addAtStart, doAtStart, bufferTime = 200, onEnd, diff } = {}) {
        super({ objectMode: true, read() { } });
        if (diff)
            this.sent = [];
        this.processBuffer = lodash_1.default.debounce(() => {
            const { sent } = this;
            if (sent)
                this.buffer = this.buffer.filter(([cmd, a, b]) => {
                    if (cmd === cross_1.LIST.add) {
                        sent.push(...(0, cross_1.wantArray)(a));
                        return true;
                    }
                    if (cmd === cross_1.LIST.remove) {
                        lodash_1.default.remove(sent, a);
                        return true;
                    }
                    if (cmd !== cross_1.LIST.update)
                        return true;
                    const found = lodash_1.default.find(sent, a);
                    if (!found)
                        return;
                    for (const k in b)
                        if (b[k] === found[k])
                            delete b[k];
                        else {
                            found[k] = b[k];
                            b[k] ??= null; // undefined is omitted by JSON, so replace it with null; null tells the client to delete the property
                        }
                    return !lodash_1.default.isEmpty(b);
                });
            if (!this.buffer.length)
                return;
            this.push(this.buffer);
            this.buffer = [];
        }, bufferTime, { maxWait: bufferTime });
        this.on('close', () => {
            onEnd?.(this);
            this.destroy();
        });
        setTimeout(() => doAtStart?.(this)); // work later, when list object has been received by Koa
        if (addAtStart) {
            for (const x of addAtStart)
                this.add(x);
            this.ready();
        }
    }
    queue(rec) {
        this.buffer.push(rec);
        if (this.buffer.length > 10_000) // hard limit
            this.processBuffer.flush();
        else
            this.processBuffer();
    }
    add(rec) {
        this.queue([cross_1.LIST.add, rec]);
    }
    remove(search) {
        const match = lodash_1.default.matches(search);
        const idx = lodash_1.default.findIndex(this.buffer, x => match(x[1]));
        const found = this.buffer[idx];
        const op = found?.[0];
        if (op === cross_1.LIST.remove)
            return;
        if (found) {
            this.buffer.splice(idx, 1);
            if (op === cross_1.LIST.add)
                return; // assuming this never reached the client
        }
        this.queue([cross_1.LIST.remove, search]);
    }
    update(search, change) {
        if (lodash_1.default.isEmpty(change))
            return;
        const match = lodash_1.default.matches(search);
        const found = lodash_1.default.find(this.buffer, x => match(x[1]));
        const op = found?.[0];
        if (op === cross_1.LIST.remove)
            return;
        if (op === cross_1.LIST.add || op === cross_1.LIST.update)
            return Object.assign(found[op === cross_1.LIST.add ? 1 : 2], change);
        this.queue([cross_1.LIST.update, search, change]);
    }
    ready() {
        this.queue([cross_1.LIST.ready]);
    }
    custom(name, data) {
        this.queue(data === undefined ? [name] : [name, data]);
    }
    props(props) {
        this.queue([cross_1.LIST.props, props]);
    }
    error(msg, close = false, props) {
        this.queue([cross_1.LIST.error, msg, props]);
        this.lastError = msg;
        if (close)
            this.close();
    }
    getLastError() {
        return this.lastError;
    }
    close() {
        this.processBuffer.flush();
        this.push(null);
    }
    events(ctx, eventMap, options) {
        ctx.res.once('close', events_1.default.multi(eventMap, options));
        return this;
    }
    async collectInitial() {
        const list = [];
        let props = {};
        let error;
        for await (const messages of this)
            for (const [op, a, b] of messages) {
                if (op === cross_1.LIST.add)
                    list.push(...(0, cross_1.wantArray)(a));
                else if (op === cross_1.LIST.remove)
                    lodash_1.default.remove(list, a);
                else if (op === cross_1.LIST.update)
                    Object.assign(lodash_1.default.find(list, a) || {}, b);
                else if (op === cross_1.LIST.props)
                    Object.assign(props, a);
                else if (op === cross_1.LIST.error)
                    error = a;
                else if (op === cross_1.LIST.ready) // ready ends the initial snapshot; live updates require SSE
                    return result();
            }
        return result();
        function result() {
            return { ...props, list, ...(error === undefined ? {} : { error }) };
        }
    }
    isClosed() {
        return this.destroyed;
    }
}
exports.SendListReadable = SendListReadable;
