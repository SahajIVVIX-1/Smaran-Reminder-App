"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.serveSharedFiles = exports.guiFilesMiddleware = void 0;
const deletePermission_1 = require("./deletePermission");
const path_1 = require("path");
const vfs_1 = require("./vfs");
const errorPages_1 = require("./errorPages");
const events_1 = __importDefault(require("./events"));
const cross_const_1 = require("./cross-const");
const upload_1 = require("./upload");
const multipartUpload_1 = require("./multipartUpload");
const promises_1 = require("stream/promises");
const stream_1 = require("stream");
const serveFile_1 = require("./serveFile");
const const_1 = require("./const");
const zip_1 = require("./zip");
const adminApis_1 = require("./adminApis");
const adminReset_1 = require("./adminReset");
const serveGuiFiles_1 = require("./serveGuiFiles");
const koa_mount_1 = __importDefault(require("koa-mount"));
const listen_1 = require("./listen");
const misc_1 = require("./misc");
const roots_1 = require("./roots");
const xxhashjs_1 = __importDefault(require("xxhashjs"));
const fs_1 = __importDefault(require("fs"));
const promises_2 = require("fs/promises");
const comments_1 = require("./comments");
const basicWeb_1 = require("./basicWeb");
const icons_1 = require("./icons");
const plugins_1 = require("./plugins");
const uploadOwners_1 = require("./uploadOwners");
const serveFrontendFiles = (0, serveGuiFiles_1.serveGuiFiles)(process.env.FRONTEND_PROXY, cross_const_1.FRONTEND_URI);
const serveFrontendPrefixed = (0, koa_mount_1.default)(cross_const_1.FRONTEND_URI.slice(0, -1), serveFrontendFiles);
const serveAdminFiles = (0, serveGuiFiles_1.serveGuiFiles)(process.env.ADMIN_PROXY, cross_const_1.ADMIN_URI);
const serveAdminPrefixed = (0, koa_mount_1.default)(cross_const_1.ADMIN_URI.slice(0, -1), serveAdminFiles);
const guiFilesMiddleware = async (ctx, next) => {
    const { path } = ctx;
    // dynamic import on frontend|admin (used for non-https login) while developing (vite4) is not producing a relative path
    if (const_1.DEV && path.startsWith('/node_modules/')) {
        const { referer: r } = ctx.headers;
        return (0, misc_1.try_)(() => r && new URL(r).pathname?.startsWith(cross_const_1.ADMIN_URI)) ? serveAdminFiles(ctx, next)
            : serveFrontendFiles(ctx, next);
    }
    if (path.startsWith(cross_const_1.FRONTEND_URI) && !path.endsWith('/'))
        return serveFrontendPrefixed(ctx, next);
    if (path === cross_const_1.ADMIN_URI + 'reset' || path === cross_const_1.ADMIN_URI + 'reset/' || path === '/~/admin/reset' || path === '/~/admin/reset/')
        return (0, adminReset_1.handleAdminReset)(ctx);
    if (path === '/~/webdav/mount.bat' || path === '/~/mount.bat') {
        const hostHeader = ctx.host || '127.0.0.1';
        const hostParts = hostHeader.split(':');
        const hostName = hostParts[0] || '127.0.0.1';
        const portNumber = hostParts[1] || (ctx.protocol === 'https' ? '443' : '80');
        const batContent = `@echo off\r\nsetlocal EnableDelayedExpansion\r\ntitle Smaran HFS - Windows WebDAV Drive Setup\r\n\r\n:: Check and request Administrator privileges if WebClient service is not running\r\nnet session >nul 2>&1\r\nif %errorlevel% neq 0 (\r\n    echo [Smaran HFS] Requesting Administrator privileges to configure Windows WebClient service...\r\n    powershell -NoProfile -Command "Start-Process cmd -ArgumentList '/c \\"\\"%~f0\\"\\"' -Verb RunAs"\r\n    exit /b\r\n)\r\n\r\necho ========================================================\r\necho       Smaran HFS - Windows WebDAV Drive Setup\r\necho ========================================================\r\necho.\r\necho [1/3] Configuring Windows WebClient service...\r\nsc config WebClient start= auto >nul 2>&1\r\nnet start WebClient >nul 2>&1\r\n\r\necho [2/3] Enabling WebDAV Basic Authentication for HTTP in Registry...\r\nreg add "HKLM\\SYSTEM\\CurrentControlSet\\Services\\WebClient\\Parameters" /v BasicAuthLevel /t REG_DWORD /d 2 /f >nul 2>&1\r\nreg add "HKLM\\SYSTEM\\CurrentControlSet\\Services\\WebClient\\Parameters" /v FileSizeLimitInBytes /t REG_DWORD /d 4294967295 /f >nul 2>&1\r\n\r\necho Restarting WebClient service to apply registry settings...\r\nnet stop WebClient /y >nul 2>&1\r\nnet start WebClient >nul 2>&1\r\n\r\necho.\r\necho [3/3] Mounting WebDAV Network Drive Z: to http://${hostName}:${portNumber}/ ...\r\nnet use Z: /delete /yes >nul 2>&1\r\nnet use Z: "http://${hostName}:${portNumber}/" /persistent:yes\r\n\r\nif exist Z:\\ (\r\n    echo.\r\n    echo ========================================================\r\n    echo SUCCESS: Smaran HFS mounted successfully as Drive Z:!\r\n    echo ========================================================\r\n    explorer Z:\\\r\n) else (\r\n    echo.\r\n    echo Notice: Drive mapping command completed.\r\n    echo If prompted by Windows, enter your Smaran HFS username and password.\r\n    explorer "http://${hostName}:${portNumber}/"\r\n)\r\necho.\r\npause\r\n`;
        ctx.status = 200;
        ctx.set('Content-Type', 'application/x-bat');
        ctx.set('Content-Disposition', 'attachment; filename="mount-smaran-drive.bat"');
        ctx.body = batContent;
        return;
    }
    if (path.length === cross_const_1.ADMIN_URI.length - 1 && cross_const_1.ADMIN_URI.startsWith(path))
        return ctx.redirect(ctx.state.revProxyPath + cross_const_1.ADMIN_URI);
    if (path.startsWith(cross_const_1.ADMIN_URI))
        return (0, adminApis_1.preventAdminAccess)(ctx) ? (0, errorPages_1.sendErrorPage)(ctx, cross_const_1.HTTP_FORBIDDEN) : serveAdminPrefixed(ctx, next);
    if (path.startsWith(cross_const_1.ICONS_URI)) {
        const a = path.substring(cross_const_1.ICONS_URI.length).split('/');
        const iconName = a.at(-1);
        if (!iconName)
            return;
        const plugin = a.length > 1 && (0, plugins_1.getPluginInfo)(a[0]); // an extra level in the path indicates a plugin
        const file = plugin ? plugin.icons?.[iconName] : icons_1.customizedIcons?.[iconName];
        if (!file)
            return;
        ctx.state.considerAsGui = true;
        return (0, serveFile_1.serveFile)(ctx, (0, path_1.join)(plugin?.folder || '', icons_1.ICONS_FOLDER, file), const_1.MIME_AUTO);
    }
    return next();
};
exports.guiFilesMiddleware = guiFilesMiddleware;
const serveSharedFiles = async (ctx, next) => {
    const { path } = ctx;
    const { get } = ctx.query;
    const getUploadTempHash = get === cross_const_1.UPLOAD_TEMP_HASH;
    if (ctx.method === 'PUT' || getUploadTempHash) { // PUT is what you get with `curl -T file url/`
        const decPath = (0, misc_1.safeDecodeURIComponent)(path, '');
        const fn = (0, path_1.basename)(decPath);
        const folderUri = (0, misc_1.pathEncode)((0, path_1.dirname)(decPath)); // re-encode to get readable urls
        const folder = await (0, vfs_1.urlToNode)(folderUri, ctx, vfs_1.vfs.compiled(), { allowMissing: true }); // we don't require the folder to already exist, but to be mapped on disk AND to have proper permissions
        if (!folder)
            return (0, errorPages_1.sendErrorPage)(ctx, cross_const_1.HTTP_NOT_FOUND);
        ctx.state.uploadPath = decPath;
        if (getUploadTempHash)
            return !folder.source || !(0, misc_1.isValidFileName)(fn) ? (0, errorPages_1.sendErrorPage)(ctx, cross_const_1.HTTP_NOT_FOUND)
                : (0, vfs_1.statusCodeForMissingPerm)(folder, 'can_upload', ctx) ? null
                    : (0, misc_1.loadFileCached)((0, upload_1.getUploadTempFor)((0, path_1.join)(folder.source, fn)), calcHash) // negligible memory leak
                        .then(x => ctx.body = x.content, e => ctx.status = e?.code === 'ENOENT' ? cross_const_1.HTTP_NOT_FOUND : cross_const_1.HTTP_SERVER_ERROR);
        const dest = (0, upload_1.uploadWriter)(folder, folderUri, fn, ctx);
        if (dest) {
            ctx.req.pipe(dest).on('error', err => {
                ctx.status = cross_const_1.HTTP_SERVER_ERROR;
                ctx.body = err.message || String(err);
            });
            ctx.req.on('close', () => dest.end());
            const uri = await dest.lockMiddleware; // we need to wait more than just the stream
            if (uri) // falsy = aborted
                ctx.body = { uri };
            else if (ctx.status === 404) // nodejs already sent 400, but koa ignores it (ctx.headersSent is false and ctx.status is 404), so we adjust koa state to have correct data in the log
                ctx.status = 400;
        }
        return;
    }
    if (ctx.state.getOrHead && /^\/favicon.ico(\??.*)/.test(ctx.originalUrl)) {
        if (adminApis_1.favicon.get() && fs_1.default.existsSync(adminApis_1.favicon.get()))
            return (0, serveFile_1.serveFile)(ctx, adminApis_1.favicon.get());
        const icoCandidates = [
            (0, path_1.join)(__dirname, '..', 'frontend', 'favicon.ico'),
            (0, path_1.join)(__dirname, '..', 'dist', 'frontend', 'favicon.ico'),
            (0, path_1.join)(__dirname, '..', 'frontend', 'public', 'favicon.ico'),
        ];
        for (const cand of icoCandidates) {
            if (fs_1.default.existsSync(cand))
                return (0, serveFile_1.serveFile)(ctx, cand, 'image/x-icon');
        }
    }
    if (ctx.state.getOrHead && /(?:^|\/)hfs-logo(-icon)?\.svg(?:\?.*)?$/.test(ctx.path || ctx.originalUrl)) {
        const isIcon = (ctx.path || ctx.originalUrl).includes('logo-icon');
        const fileName = isIcon ? 'hfs-logo-icon.svg' : 'hfs-logo.svg';
        const svgCandidates = [
            (0, path_1.join)(__dirname, '..', 'frontend', fileName),
            (0, path_1.join)(__dirname, '..', 'dist', 'frontend', fileName),
            (0, path_1.join)(__dirname, '..', 'frontend', 'public', fileName),
            (0, path_1.join)(__dirname, '..', 'admin', fileName),
            (0, path_1.join)(__dirname, '..', 'dist', 'admin', fileName),
        ];
        for (const cand of svgCandidates) {
            if (fs_1.default.existsSync(cand))
                return (0, serveFile_1.serveFile)(ctx, cand, 'image/svg+xml');
        }
    }
    let node = await (0, vfs_1.urlToNode)(path, ctx);
    if (!node)
        return (0, errorPages_1.sendErrorPage)(ctx, cross_const_1.HTTP_NOT_FOUND);
    if (ctx.method === 'POST') // curl -F upload=@file url/
        return (0, multipartUpload_1.handleMultipartUpload)(ctx, node);
    if (ctx.method === 'DELETE') {
        const { source } = node;
        if (!source)
            return ctx.status = cross_const_1.HTTP_METHOD_NOT_ALLOWED;
        try {
            if (!await (0, deletePermission_1.checkDeletePermission)(node, ctx))
                return;
            if ((await events_1.default.emitAsync('deleting', { node, ctx }))?.isDefaultPrevented())
                return ctx.status = cross_const_1.HTTP_FAILED_DEPENDENCY;
            await (0, promises_2.rm)(source, { recursive: true });
            await (0, misc_1.deleteStoredFileAttrs)(source);
            (0, uploadOwners_1.deleteUploadOwner)(node.vfsPath);
            void (0, comments_1.setCommentFor)(source, ''); // necessary only to clean a possible descript.ion or kvstorage
            return ctx.status = cross_const_1.HTTP_OK;
        }
        catch (e) {
            ctx.body = String(e);
            return ctx.status = cross_const_1.HTTP_SERVER_ERROR;
        }
    }
    if (path.endsWith('/') && !get) // final slash needed on browsers to make resource urls working with html pages
        node = await (0, vfs_1.getDefaultFile)(node, ctx) || node;
    // classify the resolved default so a file can override its folder's GUI status
    if (node.gui_asset)
        ctx.state.considerAsGui = true;
    if (get === 'icon')
        return (0, serveFile_1.serveFile)(ctx, node.icon || '|'); // pipe to cause not-found
    if (!(0, vfs_1.nodeIsFolder)(node))
        return node.url ? ctx.redirect(node.url)
            : !node.source ? (0, errorPages_1.sendErrorPage)(ctx, cross_const_1.HTTP_METHOD_NOT_ALLOWED) // !dir && !source is not supported at this moment
                : !(0, vfs_1.statusCodeForMissingPerm)(node, 'can_read', ctx) ? (0, serveFile_1.serveFileNode)(ctx, node) // all good
                    : ctx.status !== cross_const_1.HTTP_UNAUTHORIZED ? null // all errors don't need extra handling, except unauthorized
                        : (0, basicWeb_1.shouldBeBasic)(ctx) ? (ctx.set('WWW-Authenticate', cross_const_1.BASIC_AUTHENTICATE_HEADER), (0, errorPages_1.sendErrorPage)(ctx))
                            : ctx.query.dl === undefined && (ctx.state.serveApp = true) && serveFrontendFiles(ctx, next);
    if (!path.endsWith('/'))
        return ctx.redirect(ctx.state.revProxyPath + ctx.originalUrl.replace(/(\?|$)/, '/$1')); // keep query-string, if any
    if ((0, vfs_1.statusCodeForMissingPerm)(node, 'can_list', ctx)) {
        if (ctx.status === cross_const_1.HTTP_FORBIDDEN)
            return (0, errorPages_1.sendErrorPage)(ctx, cross_const_1.HTTP_FORBIDDEN);
        // basic mode and download managers need HTTP authentication instead of the frontend login
        const { authenticate } = ctx.query;
        const downloadManagerDetected = /DAP|FDM|[Mm]anager/.test(ctx.get('user-agent'));
        if (downloadManagerDetected || authenticate || (0, basicWeb_1.shouldBeBasic)(ctx))
            return ctx.set('WWW-Authenticate', authenticate || cross_const_1.BASIC_AUTHENTICATE_HEADER);
        ctx.state.serveApp = true;
        return serveFrontendFiles(ctx, next);
    }
    ctx.set({ server: `HFS ${const_1.VERSION} ${const_1.BUILD_TIMESTAMP}` });
    return get === 'zip' ? (0, zip_1.zipStreamFromFolder)(node, ctx)
        : get === 'list' ? sendFolderList(node, ctx)
            : ((0, basicWeb_1.basicWeb)(ctx, node) || serveFrontendFiles(ctx, next));
};
exports.serveSharedFiles = serveSharedFiles;
async function sendFolderList(node, ctx) {
    if ((await events_1.default.emitAsync('getList', { node, ctx }))?.isDefaultPrevented())
        return;
    let { depth = 0, folders, prepend } = ctx.query;
    ctx.type = 'text';
    if (prepend === undefined || prepend === '*') { // * = force auto-detection even if we have baseUrl set
        const { URL } = ctx;
        const requestBase = URL.protocol + '//' + URL.host + ctx.state.revProxyPath;
        const configuredBaseUrl = prepend === undefined && listen_1.baseUrl.get();
        const configuredRoot = configuredBaseUrl && roots_1.roots.compiled()(listen_1.baseUrl.compiled() || '');
        const pathInConfiguredRoot = configuredRoot && (configuredRoot === '/' ? ctx.path
            : ctx.path.startsWith(configuredRoot) ? ctx.path.slice(configuredRoot.length - 1)
                : ctx.path === configuredRoot.slice(0, -1) ? '/'
                    : false);
        // base_url may expose a host-rooted home; use it only for VFS paths inside that host root
        const [base, path] = !configuredBaseUrl ? [requestBase, ctx.path]
            : pathInConfiguredRoot === false ? [requestBase, ctx.path]
                : [configuredBaseUrl, pathInConfiguredRoot || ctx.path];
        // redo the encoding our way, keeping unicode chars unchanged. decode each segment separately because decodeURI preserves reserved escapes like %3A, which pathEncode would double-encode
        prepend = base + (0, misc_1.pathDecodeSegments)(path, misc_1.pathEncode);
    }
    const walker = (0, vfs_1.walkNode)(node, { ctx, depth: depth === '*' ? Infinity : Number(depth), parallelizeRecursion: false }); // parallelization produces out-of-order results, and we don't want it like that here
    ctx.body = (0, misc_1.asyncGeneratorToReadable)((0, misc_1.filterMapGenerator)(walker, async (el) => {
        const isFolder = (0, vfs_1.nodeIsFolder)(el);
        return !folders && isFolder ? undefined
            : prepend + (0, misc_1.pathEncode)((0, vfs_1.getNodeName)(el)) + (isFolder ? '/' : '') + '\n';
    }));
}
async function calcHash(fn, limit = Infinity) {
    const hash = xxhashjs_1.default.h32();
    const stream = new stream_1.Transform({
        transform(chunk, enc, done) {
            hash.update(chunk);
            done();
        }
    });
    console.debug('Hashing', fn);
    await (0, promises_1.pipeline)(fs_1.default.createReadStream(fn, { end: limit - 1 }), stream);
    console.debug('Hashed', fn);
    return hash.digest().toString(16);
}
