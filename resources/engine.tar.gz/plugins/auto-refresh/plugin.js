exports.description = "Automatically refresh the current file list"
exports.version = 2
exports.apiRequired = 8.23 // HFS.watchState
exports.repo = "rejetto/hfs-auto-refresh"
exports.frontend_js = "main.js"
exports.changelog = [
    { "version": 2, "message": "Reset the refresh timer after every file list load" }
]

exports.config = {
    seconds: {
        frontend: true,
        type: 'number',
        defaultValue: 60,
        min: 1,
        unit: "seconds",
        label: "Refresh every",
    },
}
