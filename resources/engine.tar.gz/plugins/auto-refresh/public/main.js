'use strict';{
    let timer
    HFS.watchState('loading', resetTimer, true)

    function resetTimer() {
        clearTimeout(timer)
        timer = setTimeout(HFS.reloadList, HFS.getPluginConfig().seconds * 1000)
    }
}
