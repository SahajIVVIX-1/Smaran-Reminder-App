exports.version = 3.3
exports.description = "Introduce increasing delays between login attempts."
exports.apiRequired = 13.7 // loginAttemptFinished

exports.config = {
    increment: { type: 'number', min: 1, defaultValue: 5, unit: "seconds", helperText: "How longer user must wait for each login attempt" },
    max: { type: 'number', min: 1, defaultValue: 60, label: "Max delay", unit: "seconds", helperText: "Max seconds to delay before next login is allowed" },
    blockAfter: { type: 'number', xs: 6, min: 1, max: 9999, defaultValue: 100, label: "Block IP after", unit: "attempts", helperText: "localhost excluded" },
    blockForHours: { type: 'number', xs: 6, min: 0, defaultValue: 24, label: "Block for", unit: "hours" },
    exclude: { type: 'string', defaultValue: '', label: "Exclude IPs", helperText: "Net mask syntax" },
    maxQueuePerIp: { type: 'number', min: 1, max: 9999, defaultValue: 32, label: "Max queued per IP" },
    maxQueuePerAccount: { type: 'number', min: 1, max: 9999, defaultValue: 16, label: "Max queued per account" },
    maxQueueGlobal: { type: 'number', min: 1, max: 999999, defaultValue: 512, label: "Max queued globally" },
}
exports.configDialog = {
    maxWidth: 'xs',
}

const byIp = new Map()
const byAccount = new Map()
const laneByIp = new Map()
const laneByAccount = new Map()
const activeAttempts = new WeakMap()
const UNKNOWN_ACCOUNT = 'unknown\t'

exports.init = api => {
    const { isLocalHost, HOUR, netMatches } = api.misc
    const { makeQ } = api.require('./makeQ')
    const gateQ = makeQ(1)
    let waitingGlobal = 0
    const QUEUE_FULL = Symbol('queue_full')
    api.events.multi({
        async attemptingLogin({ ctx, username, via }) {
            const { ip } = ctx
            const account = getAccountKey(username)
            const ipRec = getRecord(byIp, ip)
            const accountRec = getRecord(byAccount, account)
            let admitted = false
            try {
                await runGate(() => {
                    if (ipRec.waiting >= api.getConfig('maxQueuePerIp')
                    || accountRec.waiting >= api.getConfig('maxQueuePerAccount')
                    || waitingGlobal >= api.getConfig('maxQueueGlobal'))
                        throw QUEUE_FULL
                    // reserve all buckets atomically so we never exceed limits due to parallel requests
                    ipRec.waiting++
                    accountRec.waiting++
                    waitingGlobal++
                    admitted = true
                })
                const lanes = [getLane(laneByIp, ip), getLane(laneByAccount, account)]
                if (via === 'srp')
                    await runInLanes(lanes, () => waitForPenalty(ctx, ipRec, accountRec))
                else {
                    // hold the lanes through credential verification so a parallel burst observes each preceding result
                    await enterAttempt(ctx, lanes, { ip, account, ipRec, accountRec })
                    admitted = false
                }
            }
            catch (e) {
                if (e === QUEUE_FULL) {
                    ctx.status = 429
                        return api.events.stop
                }
                throw e
            }
            finally {
                if (admitted) {
                    ipRec.waiting--
                    accountRec.waiting--
                    waitingGlobal--
                }
                armCleanup(byIp, ip, ipRec)
                armCleanup(byAccount, account, accountRec)
                dropLaneIfIdle(laneByIp, ip)
                dropLaneIfIdle(laneByAccount, account)
            }
        },
        loginAttemptFinished({ ctx, success }) {
            const attempt = activeAttempts.get(ctx)
            if (!attempt) return
            activeAttempts.delete(ctx)
            if (success)
                resetRecord(byAccount, attempt.account)
            finishAdmission(attempt)
            attempt.release()
        },
        failedLogin({ ctx, username }) {
            const { ip } = ctx
            const account = getAccountKey(username)
            const now = Date.now()
            const ipRec = getRecord(byIp, ip)
            const accountRec = getRecord(byAccount, account)
            const ipAttempts = increasePenalty(ipRec, now)
            increasePenalty(accountRec, now)
            if (ipAttempts > api.getConfig('blockAfter') && !isLocalHost(ctx) && !isExcluded(ip)) {
                const hours = api.getConfig('blockForHours')
                api.addBlock({ ip, comment: "From antibrute plugin", expire: hours ? new Date(now + hours * HOUR) : undefined })
            }
            armCleanup(byIp, ip, ipRec)
            armCleanup(byAccount, account, accountRec)
            dropLaneIfIdle(laneByIp, ip)
            dropLaneIfIdle(laneByAccount, account)
        },
        login(ctx) {
            if (ctx.state.account) {
                const account = getAccountKey(ctx.state.account.username)
                resetRecord(byAccount, account)
                dropLaneIfIdle(laneByAccount, account)
            }
        }
    })

    function getRecord(container, key) {
        let rec = container.get(key)
        if (!rec) {
            rec = { failures: 0, next: 0, expires: 0, waiting: 0 }
            container.set(key, rec)
        }
        // successful attempts may keep the record alive, but must not extend its penalties
        if (rec.expires <= Date.now()) {
            rec.failures = 0
            rec.next = 0
        }
        return rec
    }

    function increasePenalty(rec, now) {
        const attempts = ++rec.failures
        const max = api.getConfig('max') * 1000
        const delay = Math.min(max, attempts * api.getConfig('increment') * 1000)
        rec.next = Math.max(now, rec.next) + delay
        rec.expires = now + 24 * HOUR
        return attempts
    }

    function armCleanup(records, key, rec) {
        clearTimeout(rec.timer)
        rec.timer = setTimeout(() => {
            // keep records while there are in-flight admissions, otherwise later releases may touch deleted state
            if (rec.waiting)
                return armCleanup(records, key, rec)
            records.delete(key)
        }, 24 * HOUR) // idle memory cleanup, independent of penalty expiry
    }

    function runGate(job) {
        return new Promise((resolve, reject) => {
            gateQ.add(async () => {
                try { resolve(await job()) }
                catch (e) { reject(e) }
            })
        })
    }

    function getLane(container, key) {
        let lane = container.get(key)
        if (!lane) {
            lane = makeQ(1)
            container.set(key, lane)
        }
        return lane
    }

    function runInLane(q, job) {
        return new Promise((resolve, reject) => {
            q.add(async () => {
                try { resolve(await job()) }
                catch (e) { reject(e) }
            })
        })
    }

    function runInLanes([lane, ...rest], job) {
        return lane ? runInLane(lane, () => runInLanes(rest, job)) : job()
    }

    function enterAttempt(ctx, lanes, attempt) {
        return new Promise((resolve, reject) => {
            let release
            const held = runInLanes(lanes, async () => {
                await waitForPenalty(ctx, attempt.ipRec, attempt.accountRec)
                await new Promise(done => {
                    release = done
                    activeAttempts.set(ctx, { ...attempt, release })
                    resolve()
                })
            })
            held.catch(reject).finally(() => {
                dropLaneIfIdle(laneByIp, attempt.ip)
                dropLaneIfIdle(laneByAccount, attempt.account)
            })
        })
    }

    async function waitForPenalty(ctx, ipRec, accountRec) {
        const now = Date.now()
        // accumulated delays must not outlive the failures that caused them
        const wait = Math.max(0, Math.min(ipRec.next, ipRec.expires) - now,
            Math.min(accountRec.next, accountRec.expires) - now)
        if (wait <= 0) return
        api.log('delaying', ctx.ip, 'for', Math.round(wait / 1000))
        ctx.set('x-anti-brute-force', wait)
        await new Promise(resolve => setTimeout(resolve, wait))
    }

    function finishAdmission({ ip, account, ipRec, accountRec }) {
        ipRec.waiting--
        accountRec.waiting--
        waitingGlobal--
        armCleanup(byIp, ip, ipRec)
        armCleanup(byAccount, account, accountRec)
    }

    function dropLaneIfIdle(container, key) {
        const q = container.get(key)
        if (q?.isWorking() || q?.queueSize()) return
        container.delete(key)
    }

    function resetRecord(container, key) {
        const rec = container.get(key)
        if (!rec) return
        if (rec.waiting) {
            // successful login must clear penalties without dropping admission counters still needed by concurrent requests
            rec.failures = 0
            rec.next = 0
            rec.expires = 0
            return
        }
        clearTimeout(rec.timer) // an old timer must not delete a replacement record for the same account
        container.delete(key)
    }

    function getAccountKey(username) {
        // fold unknown usernames together to avoid unbounded memory growth from random names
        const account = username && api.getAccount(String(username))
        return account ? account.username : UNKNOWN_ACCOUNT
    }

    function isExcluded(ip) {
        const mask = api.getConfig('exclude')
        if (!mask) return false
        try { return netMatches(ip, mask) }
        catch (e) {
            api.log("bad exclude mask:", String(e))
            return false
        }
    }
}
