exports.version = 3.4;
exports.description = "Smaran security monitor — monitors login events, failed authentication attempts, and user activity for desktop notifications.";
exports.apiRequired = 1;

exports.init = (api) => {
  function emit(type, data) {
    try {
      const payload = {
        type,
        ...data,
        timestamp: new Date().toISOString(),
      };
      // Format as single-line JSON with marker prefix
      console.log(`[SMARAN_SECURITY_EVENT] ${JSON.stringify(payload)}`);
    } catch (err) {
      // Do not allow logging errors to disrupt HFS
    }
  }

  api.events.multi({
    login(ctx) {
      const username = ctx.state?.account?.username || ctx.session?.username || 'unknown';
      const rawIp = ctx.ip || '127.0.0.1';
      const userAgent = (ctx.get && ctx.get('user-agent')) || 'Unknown Client';
      emit('login', {
        username,
        clientIp: rawIp,
        userAgent,
      });
    },
    failedLogin({ ctx, username, via }) {
      const rawIp = ctx?.ip || '127.0.0.1';
      const userAgent = (ctx?.get && ctx.get('user-agent')) || 'Unknown Client';
      emit('failedLogin', {
        username,
        clientIp: rawIp,
        userAgent,
        reason: 'Invalid credentials',
        via: via || 'api',
      });
    },
    logout(ctx) {
      const username = ctx.state?.account?.username || ctx.session?.username || 'unknown';
      const rawIp = ctx.ip || '127.0.0.1';
      emit('logout', {
        username,
        clientIp: rawIp,
      });
    },
  });
};
