exports.version = 1.4
exports.description = "Thumbnails engine. Install this and then the thumbnails plugin."
exports.apiRequired = 8.23 // customApiCall
exports.repo = "rejetto/sharp"
exports.changelog = [
    { "version": 1.4, "message": "Allow depending plugins to start when the native Sharp library cannot load" },
    { "version": 1.3, "message": "Fix: Stop timed-out Sharp work and isolate worker restarts" }
]

let sharp
try {
    sharp = require('sharp')
}
catch (e) { // keep dependent plugins running so they can use their own fallback
    console.warn("Sharp native library unavailable:", e.message || e)
}

exports.init = api => {
    if (!sharp)
        api.log("Sharp library couldn't start")
}
exports.customApi = {
    sharp,
    level: () => require('level'),
    runSharpCommands: require('./sharp-runner').runSharpCommands,
    disposeSharpWorker: require('./sharp-runner').disposeSharpWorker,
}
