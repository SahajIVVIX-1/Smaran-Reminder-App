exports.description = "Configurable password rules for the user frontend: length, uppercase and lowercase letters, digits, regular expression and special characters. Passwords stay in the browser. Reload the file browser after changing rules."
exports.version = 1
exports.apiRequired = 13.3
exports.repo = "rejetto/hfs-password-rules"
exports.preview = ["https://raw.githubusercontent.com/rejetto/hfs-password-rules/main/screenshots/options.png"]
exports.frontend_js = 'main.js'
exports.configDialog = { maxWidth: '800px' }

exports.config = {
    minLength: {
        sm: 6,
        type: 'number',
        frontend: true,
        label: "Minimum length",
        defaultValue: 8,
        min: 0,
        getError: value => !Number.isInteger(value) && "Use a whole number",
    },
    maxLength: {
        sm: 6,
        type: 'number',
        frontend: true,
        label: "Maximum length",
        defaultValue: 0,
        min: 0,
        helperText: "0 means no maximum.",
        getError: (value, { values }) => !Number.isInteger(value) ? "Use a whole number"
            : value > 0 && value < values.minLength && "Maximum length must be at least the minimum length",
    },
    uppercase: {
        sm: 6,
        type: 'boolean',
        frontend: true,
        label: "Require an uppercase letter",
        defaultValue: false,
    },
    lowercase: {
        sm: 6,
        type: 'boolean',
        frontend: true,
        label: "Require a lowercase letter",
        defaultValue: false,
    },
    numbers: {
        sm: 6,
        type: 'boolean',
        frontend: true,
        label: "Require a digit",
        defaultValue: false,
        helperText: "Unicode decimal digits are accepted, including 0–9.",
    },
    specialChars: {
        sm: 6,
        type: 'boolean',
        frontend: true,
        label: "Require a special character",
        defaultValue: false,
        helperText: "Require at least one punctuation mark or symbol. Spaces do not count.",
    },
    regexp: {
        type: 'string',
        frontend: true,
        label: "Regular expression",
        defaultValue: '',
        helperText: "Optional JavaScript pattern, without / delimiters or flags. Use ^ and $ to match the whole password.",
        getError: value => {
            try { new RegExp(value, 'u') }
            catch { return "Invalid regular expression" }
        },
    },
    regexpMessage: {
        type: 'string',
        frontend: true,
        label: "Regular expression error message",
        defaultValue: '',
        helperText: "Explain the required format. Empty uses the translated default message; custom text is shown as written in every language.",
    },
}
