HFS.onEvent('validatePassword', ({ password }) => {
    const { minLength, maxLength, regexp, regexpMessage, uppercase, lowercase, numbers, specialChars } = HFS.getPluginConfig()
    const { t } = HFS
    const length = [...password].length
    if (length < minLength)
        return t('passwordRules_minLength', { n: minLength }, "Use at least {n} characters")
    if (maxLength && length > maxLength)
        return t('passwordRules_maxLength', { n: maxLength }, "Use at most {n} characters")
    if (uppercase && !/\p{Lu}/u.test(password))
        return t('passwordRules_uppercase', "Include at least one uppercase letter")
    if (lowercase && !/\p{Ll}/u.test(password))
        return t('passwordRules_lowercase', "Include at least one lowercase letter")
    if (numbers && !/\p{Nd}/u.test(password))
        return t('passwordRules_numbers', "Include at least one digit")
    if (specialChars && !/[\p{P}\p{S}]/u.test(password))
        return t('passwordRules_specialChars', "Include at least one punctuation mark or symbol")
    if (regexp) {
        let pattern
        try { pattern = new RegExp(regexp, 'u') }
        catch { return t('passwordRules_invalidRegexp', "The password rule is misconfigured. Contact the administrator.") }
        if (!pattern.test(password))
            return regexpMessage || t('passwordRules_regexp', "The password does not match the required pattern")
    }
})
